import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  DatabaseSchema,
  AuthSession,
  Role,
  Student,
  Transaction,
  Loan,
  Ledger,
  Period,
  AuditLog,
  Settings,
  AccessCode,
  Reconciliation,
} from '../types';
import { initialDatabase } from '../initialData';

interface ToastInfo {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}

interface AppContextType {
  db: DatabaseSchema;
  session: AuthSession | null;
  loading: boolean;
  syncing: boolean;
  lastSynced: Date | null;
  login: (code: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  refreshDb: () => Promise<void>;
  toasts: ToastInfo[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
  receiptTx: Transaction | null;
  setReceiptTx: (tx: Transaction | null) => void;

  // Actions
  addStudent: (nis: string, name: string, classNum: number) => Promise<{ success: boolean; error?: string }>;
  editStudent: (id: string, name: string, status: string) => Promise<{ success: boolean; error?: string }>;
  addTransaction: (data: {
    module: 'TARIAN' | 'SIDYASA' | 'SIDATAN' | 'SIDANUM';
    type: string;
    student_id?: string;
    class_id?: number;
    ledger_id?: string;
    amount: number;
    date: string;
    description: string;
  }) => Promise<{ success: boolean; error?: string; transaction?: Transaction }>;
  verifyTeacherSetoran: (id: string, action: 'ACCEPT' | 'REJECT', rejection_reason?: string) => Promise<{ success: boolean; error?: string }>;
  correctTransaction: (id: string, newAmount: number, newDescription: string, reason: string) => Promise<{ success: boolean; error?: string }>;
  createLoan: (data: {
    date?: string;
    borrow_date?: string;
    expected_return_date?: string;
    source_module: 'TARIAN' | 'SIDANUM';
    borrower: string;
    approver?: string;
    amount: number;
    purpose: string;
  }) => Promise<{ success: boolean; error?: string }>;
  addLoan: (data: {
    source_module: 'TARIAN' | 'SIDANUM';
    amount: number;
    borrow_date?: string;
    expected_return_date?: string;
    purpose: string;
    borrower: string;
    approver?: string;
  }) => Promise<{ success: boolean; error?: string }>;
  repayLoan: (id: string, amount: number, date?: string, note?: string) => Promise<{ success: boolean; error?: string }>;
  createLedger: (name: string, source: string) => Promise<{ success: boolean; error?: string }>;
  addLedger: (name: string, source: string, description?: string) => Promise<{ success: boolean; error?: string }>;
  updateLedger: (id: string, name: string, source?: string, status?: 'AKTIF' | 'NONAKTIF', description?: string) => Promise<{ success: boolean; error?: string }>;
  editLedger: (id: string, name: string, status: 'AKTIF' | 'NONAKTIF', source?: string, description?: string) => Promise<{ success: boolean; error?: string }>;
  addReconciliation: (data: {
    date?: string;
    physical_balance: number;
    system_balance: number;
    class_id?: number;
    context?: string;
    denominations?: any;
    notes: string;
  }) => Promise<{ success: boolean; error?: string }>;
  closePeriod: (month: string, name: string) => Promise<{ success: boolean; error?: string }>;
  openPeriod: (month: string, reason: string) => Promise<{ success: boolean; error?: string }>;
  updateSettings: (settings: Partial<Settings>, accessCodes?: AccessCode[]) => Promise<{ success: boolean; error?: string }>;
  updateAccessCodes: (accessCodes: AccessCode[]) => Promise<{ success: boolean; error?: string }>;
  resetAccessCode: (role: Role, newCode?: string) => Promise<{ success: boolean; error?: string; code?: string }>;
  resetDemoData: () => Promise<{ success: boolean; error?: string }>;
  cleanDemoData: () => Promise<{ success: boolean; error?: string }>;
  restoreDatabase: (backupData: DatabaseSchema) => Promise<{ success: boolean; error?: string }>;
  restoreDb: (backupData: DatabaseSchema) => Promise<{ success: boolean; error?: string }>;
  promoteStudents: (newPeriod: string, retainedStudentIds?: string[]) => Promise<{ success: boolean; error?: string }>;

  // Balance calculation helpers
  getStudentTarianBalance: (studentId: string) => number;
  getStudentSidyasaBalance: (studentId: string) => number;
  getTeacherCash: (classId: number) => number;
  getTarianBendaharaBalance: () => number;
  getTotalTarianBalance: () => number;
  getTotalSidyasaBalance: () => number;
  getClassSidatanBalance: (classId: number) => number;
  getTotalSidatanBalance: () => number;
  getLedgerBalance: (ledgerId: string) => number;
  getTotalSidanumBalance: () => number;
}

const AppContext = createContext<AppContextType | null>(null);

const SESSION_KEY = 'simtasis_session';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [db, setDb] = useState<DatabaseSchema>(initialDatabase);
  const [session, setSession] = useState<AuthSession | null>(() => {
    try {
      const saved = localStorage.getItem(SESSION_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [lastSynced, setLastSynced] = useState<Date | null>(null);
  const [toasts, setToasts] = useState<ToastInfo[]>([]);
  const [receiptTx, setReceiptTx] = useState<Transaction | null>(null);

  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`;
    setToasts(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4500);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // Fetch full DB from server
  const refreshDb = useCallback(async () => {
    try {
      setSyncing(true);
      const res = await fetch('/api/db');
      if (res.ok) {
        const data = await res.json();
        setDb(data);
        setLastSynced(new Date());
      }
    } catch (err) {
      console.warn('Sync with server failed, using cached state:', err);
    } finally {
      setSyncing(false);
      setLoading(false);
    }
  }, []);

  // Polling for multi-device live sync every 5 seconds
  useEffect(() => {
    refreshDb();
    const interval = setInterval(refreshDb, 5000);
    return () => clearInterval(interval);
  }, [refreshDb]);

  // Auth
  const login = async (code: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Gagal masuk' };
      }

      const userSession: AuthSession = {
        role: data.role,
        name: data.name,
        classAccess: data.classAccess,
        studentData: data.studentData,
      };

      setSession(userSession);
      localStorage.setItem(SESSION_KEY, JSON.stringify(userSession));
      showToast(`Selamat datang, ${data.name}!`, 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Koneksi bermasalah' };
    }
  };

  const logout = () => {
    setSession(null);
    localStorage.removeItem(SESSION_KEY);
    showToast('Anda telah keluar dari aplikasi', 'info');
  };

  // Actions
  const addStudent = async (nis: string, name: string, classNum: number) => {
    try {
      const res = await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nis,
          name,
          classNumber: classNum,
          userRole: session?.role,
          userName: session?.name,
        }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      showToast(`Siswa ${name} (NIS: ${nis}) berhasil ditambahkan`, 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const editStudent = async (id: string, name: string, status: string) => {
    try {
      const res = await fetch(`/api/students/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          status,
          userRole: session?.role,
          userName: session?.name,
        }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      showToast('Data siswa berhasil diperbarui', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const addTransaction = async (data: {
    module: 'TARIAN' | 'SIDYASA' | 'SIDATAN' | 'SIDANUM';
    type: string;
    student_id?: string;
    class_id?: number;
    ledger_id?: string;
    amount: number;
    date: string;
    description: string;
  }) => {
    try {
      const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          userRole: session?.role,
          userName: session?.name,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };

      if (data.type === 'SETORAN_GURU_KE_BENDAHARA') {
        showToast('Setoran ke Bendahara berhasil diajukan (Menunggu Verifikasi)', 'info');
      } else {
        showToast('Transaksi berhasil disimpan', 'success');
        if (resData.transaction) {
          setReceiptTx(resData.transaction);
        }
      }
      await refreshDb();
      return { success: true, transaction: resData.transaction };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const verifyTeacherSetoran = async (id: string, action: 'ACCEPT' | 'REJECT', rejection_reason?: string) => {
    try {
      const res = await fetch(`/api/transactions/${id}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          rejection_reason,
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      showToast(
        action === 'ACCEPT' ? 'Setoran guru berhasil diverifikasi dan masuk ke kas Bendahara' : 'Setoran guru ditolak',
        action === 'ACCEPT' ? 'success' : 'info'
      );
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const correctTransaction = async (id: string, newAmount: number, newDescription: string, reason: string) => {
    try {
      const res = await fetch(`/api/transactions/${id}/correct`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          newAmount,
          newDescription,
          reason,
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const data = await res.json();
      if (!res.ok) return { success: false, error: data.error };
      showToast('Transaksi berhasil dikoreksi dengan audit trail', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const createLoan = async (data: {
    date?: string;
    borrow_date?: string;
    expected_return_date?: string;
    source_module: 'TARIAN' | 'SIDANUM';
    borrower: string;
    approver?: string;
    amount: number;
    purpose: string;
  }) => {
    try {
      const res = await fetch('/api/loans', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          date: data.borrow_date || data.date || new Date().toISOString().split('T')[0],
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast('Pinjaman kepada Bendahara BOS berhasil dicatat', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const addLoan = createLoan;

  const repayLoan = async (id: string, amount: number, date?: string, note?: string) => {
    try {
      const res = await fetch(`/api/loans/${id}/repay`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          amount,
          date: date || new Date().toISOString().split('T')[0],
          note: note || 'Pelunasan pinjaman',
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast('Pengembalian pinjaman berhasil disimpan', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const createLedger = async (name: string, source: string, description?: string) => {
    try {
      const res = await fetch('/api/ledgers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          source: source || description || '-',
          description,
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast(`Buku dana ${name} berhasil dibuat`, 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const addLedger = (name: string, source: string, description?: string) => createLedger(name, source, description);

  const updateLedger = async (
    id: string,
    name: string,
    source?: string,
    status?: 'AKTIF' | 'NONAKTIF',
    description?: string
  ) => {
    try {
      const res = await fetch(`/api/ledgers/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          source: source || description || '-',
          status: status || 'AKTIF',
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast('Buku dana berhasil diperbarui', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const editLedger = (id: string, name: string, status: 'AKTIF' | 'NONAKTIF', source?: string, description?: string) =>
    updateLedger(id, name, source, status, description);

  const addReconciliation = async (data: {
    date?: string;
    physical_balance: number;
    system_balance: number;
    class_id?: number;
    context?: string;
    denominations?: any;
    notes: string;
  }) => {
    try {
      const res = await fetch('/api/reconciliations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          date: data.date || new Date().toISOString().split('T')[0],
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast('Rekonsiliasi saldo fisik berhasil disimpan', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const promoteStudents = async (newPeriod: string, retainedStudentIds: string[] = []) => {
    try {
      const res = await fetch('/api/admin/promote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          newPeriod,
          retainedStudentIds,
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast(`Kenaikan kelas berhasil diproses untuk periode ${newPeriod}`, 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const closePeriod = async (month: string, name: string) => {
    try {
      const res = await fetch('/api/periods/close', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          month,
          name,
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast(`Periode ${month} berhasil DITUTUP.`, 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const openPeriod = async (month: string, reason: string) => {
    try {
      const res = await fetch('/api/periods/open', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          month,
          reason,
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast(`Periode ${month} berhasil DIBUKA KEMBALI.`, 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const updateSettings = async (settings: Partial<Settings>, accessCodes?: AccessCode[]) => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings,
          accessCodes,
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast('Pengaturan aplikasi berhasil disimpan', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const updateAccessCodes = async (accessCodes: AccessCode[]) => {
    try {
      const res = await fetch('/api/admin/access-codes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          accessCodes,
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast('Seluruh kode akses peran berhasil disimpan', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const resetAccessCode = async (role: Role, newCode?: string) => {
    try {
      const res = await fetch('/api/admin/reset-access-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          role,
          newCode,
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast(`Kode akses peran ${role} berhasil diperbarui`, 'success');
      await refreshDb();
      return { success: true, code: resData.code };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const resetDemoData = async () => {
    try {
      const res = await fetch('/api/admin/reset-demo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast('Data demo berhasil direset ke kondisi awal', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const cleanDemoData = async () => {
    try {
      const res = await fetch('/api/admin/clean-demo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast('Data demo berhasil dibersihkan untuk penggunaan riil', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const restoreDatabase = async (backupData: DatabaseSchema) => {
    try {
      const res = await fetch('/api/admin/restore', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          backupData,
          userName: session?.name,
          userRole: session?.role,
        }),
      });
      const resData = await res.json();
      if (!res.ok) return { success: false, error: resData.error };
      showToast('Database berhasil dipulihkan dari file backup', 'success');
      await refreshDb();
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  // Balance Calculation Functions
  const getStudentTarianBalance = useCallback((studentId: string) => {
    return db.transactions
      .filter(t => t.student_id === studentId && t.module === 'TARIAN' && t.status === 'VALID')
      .reduce((s, t) => (t.type === 'SETORAN' ? s + t.amount : t.type === 'PENARIKAN' ? s - t.amount : s), 0);
  }, [db.transactions]);

  const getStudentSidyasaBalance = useCallback((studentId: string) => {
    return db.transactions
      .filter(t => t.student_id === studentId && t.module === 'SIDYASA' && t.status === 'VALID')
      .reduce((s, t) => (t.type === 'SETORAN' ? s + t.amount : t.type === 'PENARIKAN' ? s - t.amount : s), 0);
  }, [db.transactions]);

  const getTeacherCash = useCallback((classId: number) => {
    const classTxs = db.transactions.filter(t => t.class_id === classId && t.module === 'TARIAN');
    const setoran = classTxs.filter(t => t.type === 'SETORAN' && t.status === 'VALID').reduce((s, t) => s + t.amount, 0);
    const penarikan = classTxs.filter(t => t.type === 'PENARIKAN' && t.status === 'VALID').reduce((s, t) => s + t.amount, 0);
    const handedOrPending = classTxs
      .filter(t => t.type === 'SETORAN_GURU_KE_BENDAHARA' && (t.status === 'VALID' || t.status === 'PENDING'))
      .reduce((s, t) => s + t.amount, 0);

    return Math.max(0, setoran - penarikan - handedOrPending);
  }, [db.transactions]);

  const getTarianBendaharaBalance = useCallback(() => {
    const verifiedSetoran = db.transactions
      .filter(t => t.module === 'TARIAN' && t.type === 'SETORAN_GURU_KE_BENDAHARA' && t.status === 'VALID')
      .reduce((s, t) => s + t.amount, 0);
    const loansFromTarian = db.loans
      .filter(l => l.source_module === 'TARIAN' && l.status !== 'LUNAS')
      .reduce((s, l) => s + l.remaining, 0);
    return Math.max(0, verifiedSetoran - loansFromTarian);
  }, [db.transactions, db.loans]);

  const getTotalTarianBalance = useCallback(() => {
    // Total students TARIAN balance = all valid setoran - all valid penarikan
    return db.transactions
      .filter(t => t.module === 'TARIAN' && t.status === 'VALID')
      .reduce((s, t) => {
        if (t.type === 'SETORAN') return s + t.amount;
        if (t.type === 'PENARIKAN') return s - t.amount;
        return s;
      }, 0);
  }, [db.transactions]);

  const getTotalSidyasaBalance = useCallback(() => {
    return db.transactions
      .filter(t => t.module === 'SIDYASA' && t.status === 'VALID')
      .reduce((s, t) => {
        if (t.type === 'SETORAN') return s + t.amount;
        if (t.type === 'PENARIKAN' || t.type === 'PENGELUARAN_WIDYAWISATA') return s - t.amount;
        return s;
      }, 0);
  }, [db.transactions]);

  const getClassSidatanBalance = useCallback((classId: number) => {
    return db.transactions
      .filter(t => t.module === 'SIDATAN' && t.class_id === classId && t.status === 'VALID')
      .reduce((s, t) => {
        if (t.type === 'SETORAN_KELAS') return s + t.amount;
        if (t.type === 'PENGELUARAN_KEGIATAN') return s - t.amount;
        return s;
      }, 0);
  }, [db.transactions]);

  const getTotalSidatanBalance = useCallback(() => {
    return db.transactions
      .filter(t => t.module === 'SIDATAN' && t.status === 'VALID')
      .reduce((s, t) => {
        if (t.type === 'SETORAN_KELAS') return s + t.amount;
        if (t.type === 'PENGELUARAN_KEGIATAN') return s - t.amount;
        return s;
      }, 0);
  }, [db.transactions]);

  const getLedgerBalance = useCallback((ledgerId: string) => {
    return db.transactions
      .filter(t => t.module === 'SIDANUM' && t.ledger_id === ledgerId && t.status === 'VALID')
      .reduce((s, t) => {
        if (t.type === 'PEMASUKAN_BUKU') return s + t.amount;
        if (t.type === 'PENGELUARAN_BUKU') return s - t.amount;
        return s;
      }, 0);
  }, [db.transactions]);

  const getTotalSidanumBalance = useCallback(() => {
    const totalTx = db.transactions
      .filter(t => t.module === 'SIDANUM' && t.status === 'VALID')
      .reduce((s, t) => {
        if (t.type === 'PEMASUKAN_BUKU') return s + t.amount;
        if (t.type === 'PENGELUARAN_BUKU') return s - t.amount;
        return s;
      }, 0);
    const activeLoans = db.loans
      .filter(l => l.source_module === 'SIDANUM' && l.status !== 'LUNAS')
      .reduce((s, l) => s + l.remaining, 0);
    return Math.max(0, totalTx - activeLoans);
  }, [db.transactions, db.loans]);

  return (
    <AppContext.Provider
      value={{
        db,
        session,
        loading,
        syncing,
        lastSynced,
        login,
        logout,
        refreshDb,
        toasts,
        showToast,
        removeToast,
        receiptTx,
        setReceiptTx,
        addStudent,
        editStudent,
        addTransaction,
        verifyTeacherSetoran,
        correctTransaction,
        createLoan,
        addLoan,
        repayLoan,
        createLedger,
        addLedger,
        updateLedger,
        editLedger,
        addReconciliation,
        closePeriod,
        openPeriod,
        updateSettings,
        updateAccessCodes,
        resetAccessCode,
        resetDemoData,
        cleanDemoData,
        restoreDatabase,
        restoreDb: restoreDatabase,
        promoteStudents,
        getStudentTarianBalance,
        getStudentSidyasaBalance,
        getTeacherCash,
        getTarianBendaharaBalance,
        getTotalTarianBalance,
        getTotalSidyasaBalance,
        getClassSidatanBalance,
        getTotalSidatanBalance,
        getLedgerBalance,
        getTotalSidanumBalance,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
