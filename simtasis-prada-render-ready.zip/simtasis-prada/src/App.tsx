import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { LoginView } from './views/LoginView';
import { Navbar } from './components/Navbar';
import { Sidebar, NavTab } from './components/Sidebar';
import { ToastContainer } from './components/Toast';
import { ReceiptModal } from './components/ReceiptModal';

import { DashboardView } from './views/DashboardView';
import { TarianView } from './views/TarianView';
import { VerifikasiView } from './views/VerifikasiView';
import { SidyasaView } from './views/SidyasaView';
import { SidatanView } from './views/SidatanView';
import { SidanumView } from './views/SidanumView';
import { BosView } from './views/BosView';
import { RekonsiliasiView } from './views/RekonsiliasiView';
import { LaporanView } from './views/LaporanView';
import { KenaikanView } from './views/KenaikanView';
import { PengaturanView } from './views/PengaturanView';
import { ParentPortalView } from './views/ParentPortalView';

const MainApp: React.FC = () => {
  const { session, toasts, removeToast, receiptTx, setReceiptTx } = useApp();
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);

  // If no active session, display role-based login portal
  if (!session) {
    return (
      <>
        <LoginView />
        <ToastContainer />
      </>
    );
  }

  // Strict constraint: Orang tua ONLY accesses 'parent-portal'
  const isOrtu = session.role === 'ortu';
  const effectiveTab: NavTab = isOrtu ? 'parent-portal' : currentTab;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex font-sans antialiased selection:bg-emerald-500 selection:text-white">
      {/* Persistent / Responsive Sidebar */}
      <Sidebar
        currentTab={effectiveTab}
        onSelectTab={tab => {
          if (!isOrtu) {
            setCurrentTab(tab);
          }
          setIsMobileSidebarOpen(false);
        }}
        isMobileOpen={isMobileSidebarOpen}
        onCloseMobile={() => setIsMobileSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen lg:ml-64">
        {/* Top Navbar */}
        <Navbar
          currentTab={effectiveTab}
          onToggleMobileSidebar={() => setIsMobileSidebarOpen(prev => !prev)}
        />

        {/* Dynamic Main Body Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto pb-16">
          {/* ORANG TUA: STRICTLY ParentPortalView ONLY */}
          {isOrtu ? (
            <ParentPortalView />
          ) : (
            <>
              {effectiveTab === 'dashboard' && <DashboardView onNavigate={setCurrentTab} />}
              {effectiveTab === 'tarian' && <TarianView />}
              {effectiveTab === 'verifikasi' && <VerifikasiView />}
              {effectiveTab === 'sidyasa' && <SidyasaView />}
              {effectiveTab === 'sidatan' && <SidatanView />}
              {effectiveTab === 'sidanum' && <SidanumView />}
              {effectiveTab === 'bos' && <BosView />}
              {effectiveTab === 'rekonsiliasi' && <RekonsiliasiView />}
              {effectiveTab === 'laporan' && <LaporanView />}
              {effectiveTab === 'kenaikan' && <KenaikanView />}
              {effectiveTab === 'pengaturan' && <PengaturanView />}
            </>
          )}
        </main>
      </div>

      {/* Global Modals & Notifications */}
      <ToastContainer />
      <ReceiptModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
