import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { ConfirmModal } from '../components/ConfirmModal';
import { AccessCode, Role } from '../types';
import {
  Settings as SettingsIcon,
  Download,
  Upload,
  Database,
  Building2,
  KeyRound,
  RotateCcw,
  CheckCircle2,
  Smartphone,
  ShieldCheck,
  Eye,
  EyeOff,
  Sparkles,
  Copy,
  Search,
  Check,
  AlertTriangle,
  Lock,
  Layers,
  Info,
  User,
  Printer,
} from 'lucide-react';

const ROLE_METADATA: Record<
  string,
  {
    label: string;
    defaultCode: string;
    category: 'GURU' | 'BENDAHARA' | 'PIMPINAN';
    description: string;
    badgeColor: string;
  }
> = {
  guru1: {
    label: 'Guru Kelas 1',
    defaultCode: 'guru1',
    category: 'GURU',
    description: 'Pencatatan tabungan harian siswa Kelas 1 & penyerahan kas fisik ke bendahara',
    badgeColor: 'bg-sky-100 text-sky-800 border-sky-200',
  },
  guru2: {
    label: 'Guru Kelas 2',
    defaultCode: 'guru2',
    category: 'GURU',
    description: 'Pencatatan tabungan harian siswa Kelas 2 & penyerahan kas fisik ke bendahara',
    badgeColor: 'bg-sky-100 text-sky-800 border-sky-200',
  },
  guru3: {
    label: 'Guru Kelas 3',
    defaultCode: 'guru3',
    category: 'GURU',
    description: 'Pencatatan tabungan harian siswa Kelas 3 & penyerahan kas fisik ke bendahara',
    badgeColor: 'bg-sky-100 text-sky-800 border-sky-200',
  },
  guru4: {
    label: 'Guru Kelas 4',
    defaultCode: 'guru4',
    category: 'GURU',
    description: 'Pencatatan tabungan harian siswa Kelas 4 & penyerahan kas fisik ke bendahara',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
  },
  guru5: {
    label: 'Guru Kelas 5',
    defaultCode: 'guru5',
    category: 'GURU',
    description: 'Pencatatan tabungan harian siswa Kelas 5 & penyerahan kas fisik ke bendahara',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
  },
  guru6: {
    label: 'Guru Kelas 6',
    defaultCode: 'guru6',
    category: 'GURU',
    description: 'Pencatatan tabungan harian siswa Kelas 6 & penyerahan kas fisik ke bendahara',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
  },
  bendhar: {
    label: 'Bendahara TARIAN',
    defaultCode: 'bendhar',
    category: 'BENDAHARA',
    description: 'Penyimpanan kas induk tabungan harian, verifikasi setoran guru, & rekonsiliasi kas',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
  },
  bendww: {
    label: 'Bendahara SIDYASA',
    defaultCode: 'bendww',
    category: 'BENDAHARA',
    description: 'Pengelolaan tabungan widyawisata siswa Kelas 1 s.d. 6 & pembayaran rekreasi',
    badgeColor: 'bg-teal-100 text-teal-800 border-teal-200',
  },
  benddk: {
    label: 'Bendahara SIDATAN',
    defaultCode: 'benddk',
    category: 'BENDAHARA',
    description: 'Pencatatan iuran kas kegiatan, pentas kelas, dan acara perpisahan',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
  },
  bendum: {
    label: 'Bendahara SIDANUM',
    defaultCode: 'bendum',
    category: 'BENDAHARA',
    description: 'Pengelolaan buku kas umum, infak, kalender, seragam, & dana titipan sekolah',
    badgeColor: 'bg-violet-100 text-violet-800 border-violet-200',
  },
  kepsek: {
    label: 'Kepala Sekolah',
    defaultCode: 'kepsek',
    category: 'PIMPINAN',
    description: 'Monitoring eksekutif, pengawasan seluruh buku kas, & persetujuan pinjaman BOS',
    badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
  },
  admin: {
    label: 'Administrator',
    defaultCode: 'admin',
    category: 'PIMPINAN',
    description: 'Super user: kontrol penuh seluruh fitur peran, reset password, & backup database',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-200',
  },
};

export const PengaturanView: React.FC = () => {
  const {
    session,
    db,
    updateSettings,
    updateAccessCodes,
    resetAccessCode,
    restoreDb,
    resetDemoData,
    cleanDemoData,
    showToast,
  } = useApp();

  const userRole = session?.role;
  const isAdmin = userRole === 'admin';

  // Active Tab: 'kode-akses' | 'identitas' | 'backup' | 'pengembang'
  const [activeTab, setActiveTab] = useState<'kode-akses' | 'identitas' | 'backup' | 'pengembang'>('kode-akses');

  // School Identity State
  const [schoolName, setSchoolName] = useState(db.settings.school_name);
  const [npsn, setNpsn] = useState(db.settings.npsn);
  const [address, setAddress] = useState(db.settings.address);
  const [kepsekName, setKepsekName] = useState(db.settings.kepsek_name);
  const [kepsekNip, setKepsekNip] = useState(db.settings.kepsek_nip);
  const [activePeriod, setActivePeriod] = useState(db.settings.active_period);

  // Access Codes Management State
  const [localAccessCodes, setLocalAccessCodes] = useState<AccessCode[]>(db.accessCodes || []);
  const [showPasswordMap, setShowPasswordMap] = useState<Record<string, boolean>>({});
  const [roleCategoryFilter, setRoleCategoryFilter] = useState<'ALL' | 'GURU' | 'BENDAHARA' | 'PIMPINAN'>('ALL');
  const [searchRole, setSearchRole] = useState('');
  const [isSavingAllCodes, setIsSavingAllCodes] = useState(false);

  // Sync local access codes with db when updated from server
  useEffect(() => {
    if (db.accessCodes) {
      setLocalAccessCodes(db.accessCodes);
    }
  }, [db.accessCodes]);

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
    variant?: 'danger' | 'warning' | 'primary';
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  // Save Settings Form
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await updateSettings({
      school_name: schoolName,
      npsn,
      address,
      kepsek_name: kepsekName,
      kepsek_nip: kepsekNip,
      active_period: activePeriod,
    });
    if (res.success) {
      showToast('Profil sekolah dan periode aktif berhasil disimpan', 'success');
    } else {
      showToast(res.error || 'Gagal menyimpan pengaturan', 'error');
    }
  };

  // Toggle Password Visibility
  const toggleShowPassword = (role: string) => {
    setShowPasswordMap(prev => ({
      ...prev,
      [role]: !prev[role],
    }));
  };

  // Toggle All Passwords
  const handleToggleAllPasswords = () => {
    const anyHidden = localAccessCodes.some(a => !showPasswordMap[a.role]);
    const nextMap: Record<string, boolean> = {};
    localAccessCodes.forEach(a => {
      nextMap[a.role] = anyHidden;
    });
    setShowPasswordMap(nextMap);
  };

  // Handle Edit Single Code in Local State
  const handleCodeChange = (role: Role, newCode: string) => {
    setLocalAccessCodes(prev =>
      prev.map(item => (item.role === role ? { ...item, code: newCode } : item))
    );
  };

  // Handle Edit Single Label in Local State
  const handleLabelChange = (role: Role, newLabel: string) => {
    setLocalAccessCodes(prev =>
      prev.map(item => (item.role === role ? { ...item, label: newLabel } : item))
    );
  };

  // Generate 6-Digit Random PIN
  const handleGenerateRandomPin = (role: Role) => {
    const randomPin = Math.floor(100000 + Math.random() * 900000).toString();
    handleCodeChange(role, randomPin);
    setShowPasswordMap(prev => ({ ...prev, [role]: true }));
    showToast(`PIN acak 6-digit dibuat untuk ${role}: ${randomPin}`, 'info');
  };

  // Reset Single Role to Default Code
  const handleResetSingleDefault = (role: Role) => {
    const meta = ROLE_METADATA[role];
    const defaultCode = meta?.defaultCode || role;
    const defaultLabel = meta?.label || role;

    setConfirmModal({
      isOpen: true,
      title: `Reset Password Peran: ${defaultLabel}`,
      message: `Apakah Anda yakin ingin mereset kode akses peran "${defaultLabel}" kembali ke default pabrik ("${defaultCode}")?`,
      variant: 'warning',
      action: async () => {
        const res = await resetAccessCode(role, defaultCode);
        if (res.success) {
          handleCodeChange(role, defaultCode);
          handleLabelChange(role, defaultLabel);
        } else {
          showToast(res.error || 'Gagal mereset kode akses', 'error');
        }
      },
    });
  };

  // Save Single Role Code
  const handleSaveSingleRole = async (item: AccessCode) => {
    if (!item.code.trim()) {
      showToast('Kode akses tidak boleh kosong', 'error');
      return;
    }

    if (item.role === 'admin') {
      setConfirmModal({
        isOpen: true,
        title: 'Konfirmasi Ubah Kode Akses Administrator',
        message: `PERHATIAN: Anda mengubah kode akses Administrator menjadi "${item.code}". Pastikan Anda mencatat atau mengingat kode ini agar tidak terkunci dari sistem! Lanjutkan?`,
        variant: 'danger',
        action: async () => {
          const res = await resetAccessCode(item.role, item.code.trim());
          if (res.success) {
            // Also update label if changed
            await updateAccessCodes(localAccessCodes);
          }
        },
      });
      return;
    }

    const res = await resetAccessCode(item.role, item.code.trim());
    if (res.success) {
      // Also sync label if changed
      await updateAccessCodes(localAccessCodes);
    }
  };

  // Save All Access Codes
  const handleSaveAllCodes = async () => {
    // Check for empty codes
    const hasEmpty = localAccessCodes.some(a => !a.code.trim());
    if (hasEmpty) {
      showToast('Semua peran wajib memiliki kode akses (tidak boleh kosong)', 'error');
      return;
    }

    setIsSavingAllCodes(true);
    const res = await updateAccessCodes(localAccessCodes);
    setIsSavingAllCodes(false);
    if (!res.success) {
      showToast(res.error || 'Gagal menyimpan seluruh kode akses', 'error');
    }
  };

  // Reset ALL Roles to Default
  const handleResetAllToDefault = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Reset Seluruh Kode Akses ke Default Pabrik',
      message:
        'TINDAKAN INI AKAN MERESET KODE AKSES SEMUA 12 PERAN (Guru 1-6, 4 Bendahara, Kepala Sekolah, dan Administrator) kembali ke kode default bawaan. Lanjutkan?',
      variant: 'danger',
      action: async () => {
        const restoredCodes: AccessCode[] = localAccessCodes.map(item => {
          const meta = ROLE_METADATA[item.role];
          return {
            ...item,
            label: meta?.label || item.label,
            code: meta?.defaultCode || item.role,
          };
        });
        const res = await updateAccessCodes(restoredCodes);
        if (res.success) {
          setLocalAccessCodes(restoredCodes);
          showToast('Seluruh kode akses peran berhasil direset ke default pabrik', 'success');
        }
      },
    });
  };

  // Copy All Credentials to Clipboard (For print slips)
  const handleCopyCredentials = () => {
    const lines = [
      '=========================================================',
      `DAFTAR KODE AKSES PENGGUNA - ${db.settings.school_name || 'SDN Pruwatan 02'}`,
      `Tahun Ajaran: ${db.settings.active_period} | Tanggal Cetak: ${new Date().toLocaleDateString('id-ID')}`,
      '=========================================================',
      '',
    ];

    localAccessCodes.forEach(item => {
      const meta = ROLE_METADATA[item.role];
      lines.push(`• PERAN       : ${item.label} (${item.role})`);
      lines.push(`  KODE AKSES  : ${item.code}`);
      lines.push(`  TUGAS       : ${meta?.description || '-'}`);
      lines.push('---------------------------------------------------------');
    });

    lines.push('');
    lines.push('* Catatan: Untuk Orang Tua, login menggunakan NIS masing-masing siswa.');

    navigator.clipboard.writeText(lines.join('\n'));
    showToast('Daftar kode akses berhasil disalin ke papan klip (clipboard)', 'success');
  };

  // Download Backup JSON
  const handleBackupDownload = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(db, null, 2));
    const downloadAnchor = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0].replace(/-/g, '');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `simtasis_backup_${dateStr}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Cadangan database berhasil diunduh', 'success');
  };

  // Handle Restore File
  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async event => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (!json.students || !json.transactions) {
          throw new Error('Format file backup tidak valid');
        }

        setConfirmModal({
          isOpen: true,
          title: 'Konfirmasi Pemulihan (Restore) Database',
          message: `Anda akan memulihkan data dari berkas backup "${file.name}". Seluruh data saat ini akan ditimpa dengan data backup. Lanjutkan?`,
          variant: 'danger',
          action: async () => {
            const res = await restoreDb(json);
            if (res.success) {
              showToast('Database berhasil dipulihkan', 'success');
            } else {
              showToast(res.error || 'Gagal memulihkan database', 'error');
            }
          },
        });
      } catch (err: any) {
        showToast('Berkas JSON rusak atau bukan cadangan SIMTASIS PRADA', 'error');
      }
    };
    reader.readAsText(file);
  };

  // Filtered Access Codes
  const filteredAccessCodes = useMemo(() => {
    return localAccessCodes.filter(item => {
      const meta = ROLE_METADATA[item.role];
      if (roleCategoryFilter !== 'ALL' && meta?.category !== roleCategoryFilter) {
        return false;
      }
      if (searchRole) {
        const q = searchRole.toLowerCase();
        return (
          item.label.toLowerCase().includes(q) ||
          item.role.toLowerCase().includes(q) ||
          item.code.toLowerCase().includes(q) ||
          (meta?.description && meta.description.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [localAccessCodes, roleCategoryFilter, searchRole]);

  // Check if any codes have unsaved changes
  const hasUnsavedChanges = useMemo(() => {
    if (!db.accessCodes) return false;
    return localAccessCodes.some(localItem => {
      const dbItem = db.accessCodes.find(d => d.role === localItem.role);
      return !dbItem || dbItem.code !== localItem.code || dbItem.label !== localItem.label;
    });
  }, [localAccessCodes, db.accessCodes]);

  // Non-Admin Gate
  if (!isAdmin) {
    return (
      <div className="p-8 bg-white rounded-2xl border border-slate-200 shadow-xs text-center space-y-4 max-w-lg mx-auto my-12">
        <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center mx-auto">
          <Lock className="w-6 h-6" />
        </div>
        <h3 className="text-lg font-black text-slate-900">Akses Dibatasi Khusus Administrator</h3>
        <p className="text-xs text-slate-600 leading-relaxed">
          Menu Pengaturan Sistem, Manajemen Kode Akses / Password Peran, dan Cadangan Database hanya dapat diakses oleh akun dengan peran <strong>Administrator</strong>.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-indigo-50 text-indigo-700 border border-indigo-100 flex items-center justify-center shadow-2xs">
            <SettingsIcon className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-slate-900 tracking-tight">
                Pengaturan Sistem & Kode Akses
              </h2>
              <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
                Super Admin
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Kelola kode akses seluruh peran, profil sekolah, backup berkas JSON, dan pemeliharaan data.
            </p>
          </div>
        </div>

        {/* Global Tab Navigation */}
        <div className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200 overflow-x-auto">
          <button
            type="button"
            id="tab-kode-akses"
            onClick={() => setActiveTab('kode-akses')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition whitespace-nowrap ${
              activeTab === 'kode-akses'
                ? 'bg-white text-indigo-900 shadow-2xs font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <KeyRound className="w-4 h-4 text-indigo-600" />
            <span>Kode Akses Peran</span>
            {hasUnsavedChanges && (
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" title="Ada perubahan belum disimpan" />
            )}
          </button>

          <button
            type="button"
            id="tab-identitas"
            onClick={() => setActiveTab('identitas')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition whitespace-nowrap ${
              activeTab === 'identitas'
                ? 'bg-white text-slate-900 shadow-2xs font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-4 h-4 text-slate-600" />
            <span>Profil Sekolah</span>
          </button>

          <button
            type="button"
            id="tab-backup"
            onClick={() => setActiveTab('backup')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition whitespace-nowrap ${
              activeTab === 'backup'
                ? 'bg-white text-slate-900 shadow-2xs font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database className="w-4 h-4 text-emerald-600" />
            <span>Backup & Restore</span>
          </button>

          <button
            type="button"
            id="tab-pengembang"
            onClick={() => setActiveTab('pengembang')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-bold transition whitespace-nowrap ${
              activeTab === 'pengembang'
                ? 'bg-white text-slate-900 shadow-2xs font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-sky-600" />
            <span>Tentang & Bantuan</span>
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* TAB 1: MANAJEMEN KODE AKSES SEMUA PERAN (RESET PASSWORD) */}
      {/* ========================================================= */}
      {activeTab === 'kode-akses' && (
        <div className="space-y-6">
          {/* Top Action Toolbar */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div>
                <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                  <KeyRound className="w-5 h-5 text-indigo-600" />
                  Manajemen Kode Akses & Reset Password Peran
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Administrator dapat melihat, mengubah, membuat PIN acak, atau mereset kode akses seluruh 12 peran sistem.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  id="btn-toggle-all-passwords"
                  onClick={handleToggleAllPasswords}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Lihat / Tutup Semua Password</span>
                </button>

                <button
                  type="button"
                  id="btn-copy-credentials"
                  onClick={handleCopyCredentials}
                  className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition flex items-center gap-1.5"
                  title="Salin seluruh data login untuk dicetak / dibagikan"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>Salin Rekap Akses</span>
                </button>

                <button
                  type="button"
                  id="btn-reset-all-default"
                  onClick={handleResetAllToDefault}
                  className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-bold rounded-xl transition flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Semua ke Default</span>
                </button>

                <button
                  type="button"
                  id="btn-save-all-codes"
                  onClick={handleSaveAllCodes}
                  disabled={isSavingAllCodes}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition shadow-xs flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4" />
                  <span>{isSavingAllCodes ? 'Menyimpan...' : 'Simpan Seluruh Perubahan'}</span>
                </button>
              </div>
            </div>

            {/* Filter & Search Bar */}
            <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              {/* Category Pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                <button
                  type="button"
                  onClick={() => setRoleCategoryFilter('ALL')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                    roleCategoryFilter === 'ALL'
                      ? 'bg-slate-900 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Semua Peran ({localAccessCodes.length})
                </button>
                <button
                  type="button"
                  onClick={() => setRoleCategoryFilter('GURU')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                    roleCategoryFilter === 'GURU'
                      ? 'bg-sky-600 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Guru Kelas (6)
                </button>
                <button
                  type="button"
                  onClick={() => setRoleCategoryFilter('BENDAHARA')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                    roleCategoryFilter === 'BENDAHARA'
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Bendahara (4)
                </button>
                <button
                  type="button"
                  onClick={() => setRoleCategoryFilter('PIMPINAN')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                    roleCategoryFilter === 'PIMPINAN'
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Pimpinan & Admin (2)
                </button>
              </div>

              {/* Search Box */}
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={searchRole}
                  onChange={e => setSearchRole(e.target.value)}
                  placeholder="Cari peran, nama, kode..."
                  className="w-full pl-9 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Security & Instruction Banner */}
          <div className="p-4 rounded-2xl bg-indigo-50/80 border border-indigo-200/80 text-indigo-950 flex items-start gap-3 text-xs leading-relaxed">
            <Info className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="font-bold">Informasi Keamanan Akses Sistem:</p>
              <p className="text-indigo-900">
                Kode akses bersifat sensitif. Kode akses baru akan langsung aktif pada sesi login berikutnya.
                Untuk peran <strong>Orang Tua Siswa</strong>, sistem menggunakan autentikasi mandiri berbasis <strong>NIS (Nomor Induk Siswa)</strong> dan hanya dapat mengakses mutasi tabungan milik anaknya sendiri.
              </p>
            </div>
          </div>

          {/* Roles Grid Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredAccessCodes.map(item => {
              const meta = ROLE_METADATA[item.role];
              const isVisible = !!showPasswordMap[item.role];
              const dbItem = db.accessCodes?.find(d => d.role === item.role);
              const isModified = dbItem ? dbItem.code !== item.code || dbItem.label !== item.label : false;
              const isDefault = meta ? item.code === meta.defaultCode : false;

              return (
                <div
                  key={item.role}
                  className={`bg-white p-5 rounded-2xl border transition-all duration-200 shadow-xs flex flex-col justify-between gap-4 ${
                    isModified
                      ? 'border-amber-400 bg-amber-50/20 ring-1 ring-amber-400'
                      : 'border-slate-200/90 hover:border-slate-300'
                  }`}
                >
                  {/* Card Header */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[11px] font-black border uppercase tracking-wider ${
                          meta?.badgeColor || 'bg-slate-100 text-slate-800 border-slate-200'
                        }`}
                      >
                        {item.role}
                      </span>

                      {isModified ? (
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                          Belum Disimpan
                        </span>
                      ) : isDefault ? (
                        <span className="text-[10px] font-semibold text-slate-400">Kode Default</span>
                      ) : (
                        <span className="text-[10px] font-semibold text-emerald-600 flex items-center gap-0.5">
                          <Check className="w-3 h-3" /> Tersimpan
                        </span>
                      )}
                    </div>

                    {/* Editable Label Name */}
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                        Nama Tampilan Peran
                      </label>
                      <input
                        type="text"
                        value={item.label}
                        onChange={e => handleLabelChange(item.role, e.target.value)}
                        className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                        placeholder={meta?.label || item.role}
                      />
                    </div>

                    {/* Role Description */}
                    <p className="text-[11px] text-slate-500 leading-snug">
                      {meta?.description || 'Hak akses operasional modul sekolah'}
                    </p>
                  </div>

                  {/* Password / Access Code Input Section */}
                  <div className="space-y-3 pt-2 border-t border-slate-100">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-[10px] font-bold text-slate-700 uppercase tracking-wider">
                          Kode Akses (Password)
                        </label>
                        <span className="text-[10px] font-mono text-slate-400">
                          Default: {meta?.defaultCode || item.role}
                        </span>
                      </div>

                      <div className="relative flex items-center">
                        <input
                          type={isVisible ? 'text' : 'password'}
                          value={item.code}
                          onChange={e => handleCodeChange(item.role, e.target.value)}
                          className="w-full pr-20 pl-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          placeholder="Masukkan kode akses baru..."
                          required
                        />
                        <div className="absolute right-1.5 flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => toggleShowPassword(item.role)}
                            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition"
                            title={isVisible ? 'Sembunyikan Password' : 'Lihat Password'}
                          >
                            {isVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleGenerateRandomPin(item.role)}
                            className="p-1.5 text-indigo-600 hover:text-indigo-800 rounded-lg hover:bg-indigo-50 transition"
                            title="Buat PIN 6-Digit Acak"
                          >
                            <Sparkles className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => handleResetSingleDefault(item.role)}
                        className="flex-1 py-2 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold rounded-xl transition flex items-center justify-center gap-1"
                        title="Kembalikan ke kode default"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                        <span>Default</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleSaveSingleRole(item)}
                        className={`flex-1 py-2 px-3 text-[11px] font-bold rounded-xl transition flex items-center justify-center gap-1.5 shadow-2xs ${
                          isModified
                            ? 'bg-indigo-600 hover:bg-indigo-700 text-white font-black'
                            : 'bg-slate-900 hover:bg-slate-800 text-white'
                        }`}
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Simpan</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 2: PROFIL SATUAN PENDIDIKAN & PEJABAT */}
      {/* ========================================================= */}
      {activeTab === 'identitas' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Building2 className="w-4 h-4 text-slate-600" />
              Identitas Sekolah & Pejabat Penandatangan
            </h3>
            <p className="text-xs text-slate-500">
              Identitas ini tercetak otomatis pada struk bukti setor, kwitansi, rekapitulasi, dan laporan resmi kepala sekolah.
            </p>

            <form onSubmit={handleSaveSettings} className="space-y-4 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Nama Satuan Pendidikan
                  </label>
                  <input
                    type="text"
                    value={schoolName}
                    onChange={e => setSchoolName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-slate-900 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    NPSN
                  </label>
                  <input
                    type="text"
                    value={npsn}
                    onChange={e => setNpsn(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:ring-2 focus:ring-slate-900 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Alamat Sekolah Lengkap
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-slate-900 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Nama Kepala Sekolah
                  </label>
                  <input
                    type="text"
                    value={kepsekName}
                    onChange={e => setKepsekName(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:ring-2 focus:ring-slate-900 focus:outline-none"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    NIP Kepala Sekolah
                  </label>
                  <input
                    type="text"
                    value={kepsekNip}
                    onChange={e => setKepsekNip(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono focus:ring-2 focus:ring-slate-900 focus:outline-none"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Tahun Ajaran / Periode Aktif
                </label>
                <input
                  type="text"
                  value={activePeriod}
                  onChange={e => setActivePeriod(e.target.value)}
                  placeholder="2024/2025"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:ring-2 focus:ring-slate-900 focus:outline-none"
                  required
                />
              </div>

              <button
                type="submit"
                className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition"
              >
                Simpan Profil Sekolah
              </button>
            </form>
          </div>

          <div className="lg:col-span-4 space-y-4">
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 text-xs text-slate-600 space-y-3">
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <Info className="w-4 h-4 text-indigo-600" />
                Catatan Pejabat Sekolah
              </h4>
              <p className="leading-relaxed">
                Kepala Sekolah terdaftar memiliki hak akses untuk memonitor seluruh neraca kas di modul TARIAN, SIDYASA, SIDATAN, dan SIDANUM, serta menandatangani persetujuan pinjaman talangan dana BOS.
              </p>
              <p className="leading-relaxed">
                Tahun ajaran aktif mempengaruhi pengelompokan buku kas pada kenaikan kelas dan kelulusan siswa.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 3: BACKUP & RESTORE */}
      {/* ========================================================= */}
      {activeTab === 'backup' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Backup Box */}
          <div className="lg:col-span-6 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Download className="w-5 h-5 text-emerald-600" />
              Unduh Cadangan Database (Backup)
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Unduh seluruh database (master siswa, transaksi, kode akses, kas umum, pinjaman, rekonsiliasi) dalam format berkas JSON mandiri yang aman.
            </p>

            <div className="pt-2">
              <button
                type="button"
                id="btn-download-backup"
                onClick={handleBackupDownload}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl transition shadow-xs flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                Unduh Cadangan Database Lengkap (.json)
              </button>
            </div>

            <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-900">
              Disarankan untuk mengunduh cadangan setiap akhir bulan atau sebelum melakukan pembersihan data demo.
            </div>
          </div>

          {/* Restore Box */}
          <div className="lg:col-span-6 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Upload className="w-5 h-5 text-indigo-600" />
              Pemulihan Database (Restore)
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Pulihkan database SIMTASIS PRADA dari berkas .json cadangan sebelumnya. Perhatian: Seluruh data terkini akan digantikan dengan isi berkas cadangan.
            </p>

            <div className="pt-2">
              <input
                type="file"
                accept=".json"
                onChange={handleFileRestore}
                id="restore-file-input"
                className="hidden"
              />
              <label
                htmlFor="restore-file-input"
                className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                Pilih Berkas Cadangan (.json) untuk Dipulihkan
              </label>
            </div>

            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900">
              Tindakan restore bersifat permanen. Pastikan berkas cadangan valid dan berasal dari SIMTASIS PRADA.
            </div>
          </div>

          {/* Clean / Reset Demo Data Box */}
          <div className="lg:col-span-12 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2 text-rose-700">
              <AlertTriangle className="w-5 h-5 text-rose-600" />
              Pemeliharaan Data & Pembersihan Lingkungan
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              Opsi khusus Administrator untuk mereset data contoh kembali ke awal, atau membersihkan seluruh transaksi demo untuk siap dipakai secara riil oleh sekolah.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setConfirmModal({
                    isOpen: true,
                    title: 'Reset ke Data Demo Awal',
                    message: 'Seluruh transaksi dan data siswa akan dikembalikan ke kondisi demo awal SDN Pruwatan 02. Lanjutkan?',
                    variant: 'warning',
                    action: resetDemoData,
                  });
                }}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition flex items-center gap-2 border border-slate-200"
              >
                <RotateCcw className="w-4 h-4 text-slate-500" />
                Kembalikan ke Data Demo Awal
              </button>

              <button
                type="button"
                onClick={() => {
                  setConfirmModal({
                    isOpen: true,
                    title: 'Bersihkan Data Demo (Siap Pakai Riil)',
                    message: 'Seluruh riwayat transaksi demo akan dihapus, saldo direset 0, dan sistem siap digunakan untuk pencatatan riil SDN Pruwatan 02. Lanjutkan?',
                    variant: 'danger',
                    action: cleanDemoData,
                  });
                }}
                className="px-4 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold text-xs rounded-xl transition flex items-center gap-2"
              >
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                Bersihkan Data Demo untuk Penggunaan Riil
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* TAB 4: TENTANG SISTEM & PENGEMBANG */}
      {/* ========================================================= */}
      {activeTab === 'pengembang' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-indigo-600" />
              Tentang Aplikasi SIMTASIS PRADA
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              <strong>SIMTASIS PRADA</strong> (Sistem Informasi & Manajemen Tabungan Siswa) SDN Pruwatan 02, Kecamatan Bumiayu, Kabupaten Brebes dirancang khusus untuk memfasilitasi pencatatan keuangan sekolah yang akuntabel, transparan, dan terintegrasi multi-peran.
            </p>

            <div className="space-y-3 pt-2 text-xs text-slate-700">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1">
                <span className="font-bold text-slate-900">4 Modul Keuangan Utama:</span>
                <ul className="list-disc pl-4 space-y-1 text-slate-600 mt-1">
                  <li><strong>TARIAN:</strong> Tabungan Harian Siswa berbasis Guru Kelas dengan verifikasi fisik Bendahara.</li>
                  <li><strong>SIDYASA:</strong> Simpanan Tabungan Widyawisata & Rekreasi Siswa.</li>
                  <li><strong>SIDATAN:</strong> Simpanan Dana Kegiatan & Pentas Kelas Siswa.</li>
                  <li><strong>SIDANUM:</strong> Simpanan Dana Umum, Infak, Kalender, Seragam, & Kas Umum.</li>
                </ul>
              </div>

              <div className="p-3 bg-indigo-50/60 rounded-xl border border-indigo-100 text-indigo-950 space-y-1">
                <span className="font-bold">Fitur Super Administrator:</span>
                <p className="text-[11px] text-indigo-900 leading-relaxed">
                  Administrator memiliki wewenang eksekutif untuk menjalankan seluruh modul, merekam setoran untuk kelas manapun, menyetujui verifikasi, mereset kode akses semua peran, serta mengunduh berkas cadangan database.
                </p>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 space-y-4">
            {/* Developer Card */}
            <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-6 rounded-2xl shadow-sm space-y-4">
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4" />
                Profil Pengembang Aplikasi
              </div>
              <div>
                <p className="text-lg font-black text-white">Arif Setiawan, M.Pd.</p>
                <p className="text-xs text-slate-300">NIP. 199301242024211008</p>
                <p className="text-xs text-slate-400 mt-0.5">Guru SDN Pruwatan 02, Kec. Bumiayu, Kab. Brebes</p>
              </div>
              <div className="pt-3 border-t border-white/10 flex items-center gap-2 text-xs text-slate-300">
                <Smartphone className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp: 082221845858</span>
              </div>
              <div className="p-3 bg-white/5 rounded-xl border border-white/10 text-[11px] text-slate-300">
                SIMTASIS PRADA v2.4 • Dirancang sesuai regulasi perbankan mini & akuntansi sekolah dasar.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Global Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
        onConfirm={confirmModal.action}
        onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
