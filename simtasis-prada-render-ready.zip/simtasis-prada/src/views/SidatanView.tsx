import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ConfirmModal } from '../components/ConfirmModal';
import {
  CalendarDays,
  ArrowDownRight,
  ArrowUpRight,
  PlusCircle,
  History,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

export const SidatanView: React.FC = () => {
  const {
    db,
    addTransaction,
    getTotalSidatanBalance,
    getClassSidatanBalance,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'setoran-kelas' | 'pengeluaran-kegiatan' | 'rekap-kelas' | 'riwayat'>('setoran-kelas');

  // Setoran Kelas Form
  const [selectedClass, setSelectedClass] = useState<number>(1);
  const [setorAmount, setSetorAmount] = useState<number | ''>('');
  const [setorDate, setSetorDate] = useState(new Date().toISOString().split('T')[0]);
  const [setorDesc, setSetorDesc] = useState('');

  // Pengeluaran Kegiatan Form
  const [expenseAmount, setExpenseAmount] = useState<number | ''>('');
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split('T')[0]);
  const [expenseCategory, setExpenseCategory] = useState('PRAMUKA');
  const [expenseDesc, setExpenseDesc] = useState('');

  // Confirmation Modal
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
    variant?: 'danger' | 'warning' | 'primary';
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const totalSidatan = getTotalSidatanBalance();
  const sidatanTxs = db.transactions.filter(t => t.module === 'SIDATAN');

  // Handle Setoran Kelas
  const handleSaveSetoranKelas = (e: React.FormEvent) => {
    e.preventDefault();
    const num = Number(setorAmount);
    if (!num || num <= 0) {
      showToast('Nominal setoran harus lebih dari 0', 'error');
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: `Konfirmasi Setoran Kelas ${selectedClass}`,
      message: `Catat setoran dana kegiatan akumulatif Kelas ${selectedClass} sebesar Rp ${num.toLocaleString('id-ID')}?`,
      variant: 'primary',
      action: async () => {
        const res = await addTransaction({
          module: 'SIDATAN',
          type: 'SETORAN_KELAS',
          class_id: selectedClass,
          amount: num,
          date: setorDate,
          description: setorDesc || `Setoran dana kegiatan Kelas ${selectedClass}`,
        });
        if (res.success) {
          setSetorAmount('');
          setSetorDesc('');
        }
      },
    });
  };

  // Handle Pengeluaran Kegiatan
  const handleSavePengeluaranKegiatan = (e: React.FormEvent) => {
    e.preventDefault();
    const num = Number(expenseAmount);
    if (!num || num <= 0) {
      showToast('Nominal pengeluaran harus lebih dari 0', 'error');
      return;
    }

    if (num > totalSidatan) {
      showToast(`Pengeluaran melebihi total kas SIDATAN yang tersedia (Rp ${totalSidatan.toLocaleString('id-ID')})`, 'error');
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: 'Konfirmasi Pengeluaran Kegiatan',
      message: `Catat pengeluaran kegiatan [${expenseCategory}] sebesar Rp ${num.toLocaleString('id-ID')}? Saldo kas kegiatan akan berkurang.`,
      variant: 'warning',
      action: async () => {
        const res = await addTransaction({
          module: 'SIDATAN',
          type: 'PENGELUARAN_KEGIATAN',
          amount: num,
          date: expenseDate,
          description: `[${expenseCategory}] ${expenseDesc || 'Pengeluaran kegiatan sekolah'}`,
        });
        if (res.success) {
          setExpenseAmount('');
          setExpenseDesc('');
        }
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-amber-100 text-amber-800">
              <CalendarDays className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              SIDATAN — Simpanan Dana Kegiatan
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencatatan iuran kegiatan akumulatif per kelas (1 - 6) dan pembiayaan acara sekolah (Pramuka, PHBI, PHBN, Class Meeting).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('setoran-kelas')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'setoran-kelas' ? 'bg-amber-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Setoran per Kelas
          </button>
          <button
            onClick={() => setActiveTab('pengeluaran-kegiatan')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'pengeluaran-kegiatan' ? 'bg-amber-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Pengeluaran Acara
          </button>
          <button
            onClick={() => setActiveTab('rekap-kelas')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'rekap-kelas' ? 'bg-amber-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Rekap Saldo per Kelas
          </button>
          <button
            onClick={() => setActiveTab('riwayat')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'riwayat' ? 'bg-amber-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Riwayat SIDATAN
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Total Saldo Bersih SIDATAN</span>
          <p className="text-2xl font-black text-amber-800 mt-1 font-mono">
            Rp {totalSidatan.toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-400">Total Setoran Kelas − Pengeluaran</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Akumulasi Setoran Masuk</span>
          <p className="text-2xl font-black text-emerald-700 mt-1 font-mono">
            Rp{' '}
            {sidatanTxs
              .filter(t => t.type === 'SETORAN_KELAS' && t.status === 'VALID')
              .reduce((s, t) => s + t.amount, 0)
              .toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-400">Dari seluruh Kelas 1 - 6</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Total Pengeluaran Acara</span>
          <p className="text-2xl font-black text-rose-600 mt-1 font-mono">
            Rp{' '}
            {sidatanTxs
              .filter(t => t.type === 'PENGELUARAN_KEGIATAN' && t.status === 'VALID')
              .reduce((s, t) => s + t.amount, 0)
              .toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-400">Pramuka, PHBI, PHBN, dll.</p>
        </div>
      </div>

      {/* Tab 1: Setoran per Kelas */}
      {activeTab === 'setoran-kelas' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-base">Pencatatan Setoran Kas Kegiatan Kelas</h3>
            <form onSubmit={handleSaveSetoranKelas} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Pilih Kelas
                </label>
                <select
                  value={selectedClass}
                  onChange={e => setSelectedClass(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold focus:ring-2 focus:ring-amber-500 focus:outline-none"
                >
                  {[1, 2, 3, 4, 5, 6].map(c => (
                    <option key={c} value={c}>
                      Kelas {c} (Saldo saat ini: Rp {getClassSidatanBalance(c).toLocaleString('id-ID')})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nominal Setoran (Rp)
                </label>
                <input
                  type="number"
                  min="1000"
                  step="500"
                  value={setorAmount}
                  onChange={e => setSetorAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Contoh: 150000"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-semibold focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    value={setorDate}
                    onChange={e => setSetorDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Keterangan
                  </label>
                  <input
                    type="text"
                    value={setorDesc}
                    onChange={e => setSetorDesc(e.target.value)}
                    placeholder="Contoh: Iuran kegiatan semester ganjil"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl text-sm font-bold text-white bg-amber-700 hover:bg-amber-800 shadow-xs transition flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                Simpan Setoran Kelas {selectedClass}
              </button>
            </form>
          </div>

          <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
            <h4 className="font-bold text-slate-900 text-sm">Ketentuan SIDATAN</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              SIDATAN mencatat uang kegiatan secara komunal/kolektif per kelas, bukan per siswa. Setiap kelas memiliki alokasi kas tersendiri untuk mendukung partisipasi kegiatan sekolah.
            </p>
          </div>
        </div>
      )}

      {/* Tab 2: Pengeluaran Acara */}
      {activeTab === 'pengeluaran-kegiatan' && (
        <div className="max-w-xl bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <h3 className="font-bold text-slate-900 text-base">Pencatatan Pengeluaran Kegiatan Sekolah</h3>

          <form onSubmit={handleSavePengeluaranKegiatan} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Kategori Kegiatan
              </label>
              <select
                value={expenseCategory}
                onChange={e => setExpenseCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-amber-500 focus:outline-none"
              >
                <option value="PRAMUKA">Kegiatan Pramuka / Perkemahan</option>
                <option value="PHBI">Peringatan Hari Besar Islam (PHBI)</option>
                <option value="PHBN">Peringatan Hari Besar Nasional (PHBN / 17 Agustus)</option>
                <option value="CLASS_MEETING">Class Meeting / Lomba Siswa</option>
                <option value="LAINNYA">Kegiatan Lainnya</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Nominal Pengeluaran (Rp)
              </label>
              <input
                type="number"
                max={totalSidatan}
                value={expenseAmount}
                onChange={e => setExpenseAmount(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="Contoh: 300000"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-semibold focus:ring-2 focus:ring-amber-500 focus:outline-none"
                required
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Maksimal kas SIDATAN yang tersedia: Rp {totalSidatan.toLocaleString('id-ID')}
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Tanggal Pengeluaran
              </label>
              <input
                type="date"
                value={expenseDate}
                onChange={e => setExpenseDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Keterangan / Rincian Pengeluaran
              </label>
              <textarea
                rows={2}
                value={expenseDesc}
                onChange={e => setExpenseDesc(e.target.value)}
                placeholder="Contoh: Pembelian tenda dan konsumsi perkemahan sabtu-minggu"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                required
              />
            </div>

            <button
              type="submit"
              disabled={totalSidatan <= 0}
              className="w-full py-3 rounded-xl text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-xs transition"
            >
              Simpan Pengeluaran Acara
            </button>
          </form>
        </div>
      )}

      {/* Tab 3: Rekap Saldo per Kelas */}
      {activeTab === 'rekap-kelas' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
          <h3 className="font-bold text-slate-900 text-base">Rekapitulasi Saldo SIDATAN per Kelas</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map(c => {
              const bal = getClassSidatanBalance(c);
              const totalSetor = sidatanTxs
                .filter(t => t.type === 'SETORAN_KELAS' && t.class_id === c && t.status === 'VALID')
                .reduce((s, t) => s + t.amount, 0);

              return (
                <div key={c} className="p-4 rounded-xl border border-slate-200 bg-slate-50/70">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-base">Kelas {c}</span>
                    <span className="text-xs text-slate-500">SDN Pruwatan 02</span>
                  </div>
                  <div className="mt-3 space-y-1">
                    <div className="flex justify-between text-xs text-slate-600">
                      <span>Total Setoran Masuk:</span>
                      <span className="font-mono text-emerald-700">Rp {totalSetor.toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between text-xs font-bold text-slate-900 pt-1 border-t border-slate-200">
                      <span>Saldo Akhir Kelas:</span>
                      <span className="font-mono text-amber-800 text-sm">Rp {bal.toLocaleString('id-ID')}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 4: Riwayat Transaksi */}
      {activeTab === 'riwayat' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
          <h3 className="font-bold text-slate-900 text-base">Riwayat Transaksi SIDATAN</h3>
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">ID Transaksi</th>
                  <th className="px-4 py-3">Tanggal</th>
                  <th className="px-4 py-3">Jenis</th>
                  <th className="px-4 py-3">Kelas / Kategori</th>
                  <th className="px-4 py-3 text-right">Nominal</th>
                  <th className="px-4 py-3">Keterangan</th>
                  <th className="px-4 py-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sidatanTxs.map(tx => (
                  <tr key={tx.id} className="hover:bg-slate-50 transition">
                    <td className="px-4 py-3 font-mono font-semibold text-slate-900">{tx.id}</td>
                    <td className="px-4 py-3 text-slate-600">{tx.date}</td>
                    <td className="px-4 py-3 font-bold text-slate-800">{tx.type}</td>
                    <td className="px-4 py-3 text-slate-800">
                      {tx.class_id ? `Kelas ${tx.class_id}` : 'Umum Sekolah'}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold">
                      <span className={tx.type === 'SETORAN_KELAS' ? 'text-emerald-700' : 'text-rose-600'}>
                        {tx.type === 'SETORAN_KELAS' ? '+' : '-'}Rp {tx.amount.toLocaleString('id-ID')}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-500 text-[11px]">{tx.description}</td>
                    <td className="px-4 py-3 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
        onConfirm={confirmModal.action}
        onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
