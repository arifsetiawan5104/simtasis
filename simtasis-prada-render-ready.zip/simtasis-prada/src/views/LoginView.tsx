import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Landmark, Lock, ArrowRight, ShieldCheck, Phone, User, Award, HelpCircle } from 'lucide-react';

export const LoginView: React.FC = () => {
  const { db, login } = useApp();
  const [accessCode, setAccessCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showHelper, setShowHelper] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessCode.trim()) {
      setErrorMsg('Harap masukkan kode akses atau NIS siswa.');
      return;
    }

    setLoading(true);
    setErrorMsg('');
    const res = await login(accessCode.trim());
    setLoading(false);
    if (!res.success) {
      setErrorMsg(res.error || 'Kode akses salah atau tidak terdaftar.');
    }
  };

  const handleQuickLogin = (code: string) => {
    setAccessCode(code);
    setErrorMsg('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 flex flex-col justify-between px-4 py-8 sm:py-12">
      <div className="w-full max-w-md mx-auto my-auto">
        {/* Card Login */}
        <div className="bg-white rounded-3xl shadow-2xl border border-slate-100/10 overflow-hidden">
          {/* Header Identity */}
          <div className="p-6 sm:p-8 bg-gradient-to-b from-slate-50 to-white border-b border-slate-100 text-center">
            <div className="w-20 h-20 mx-auto rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-lg shadow-emerald-600/20 mb-4 overflow-hidden">
              {db.settings.logoUrl ? (
                <img
                  src={db.settings.logoUrl}
                  alt="Logo Sekolah"
                  className="w-full h-full object-cover"
                />
              ) : (
                <Landmark className="w-10 h-10 text-white" />
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              {db.settings.appName}
            </h1>
            <p className="text-sm font-semibold text-emerald-700 mt-1">
              Sistem Informasi dan Manajemen Tabungan Siswa
            </p>
            <p className="text-xs font-medium text-slate-500 mt-0.5">
              {db.settings.schoolName}
            </p>
          </div>

          {/* Form Login */}
          <div className="p-6 sm:p-8">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label
                  htmlFor="access-code-input"
                  className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2"
                >
                  Kode Akses Pegawai / NIS Siswa
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Lock className="w-5 h-5" />
                  </div>
                  <input
                    id="access-code-input"
                    type="password"
                    value={accessCode}
                    onChange={e => setAccessCode(e.target.value)}
                    placeholder="Masukkan kode akses atau NIS..."
                    autoFocus
                    className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 font-mono text-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5 leading-relaxed">
                  Guru/Bendahara/Admin: gunakan kode akses. Orang tua: gunakan <strong>NIS siswa</strong> (contoh: 240101).
                </p>
              </div>

              {errorMsg && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-medium">
                  {errorMsg}
                </div>
              )}

              <button
                type="submit"
                id="login-submit-button"
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 py-3.5 px-6 rounded-xl text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] transition shadow-md shadow-emerald-600/25 disabled:opacity-50"
              >
                {loading ? (
                  <span>Memverifikasi...</span>
                ) : (
                  <>
                    <span>Masuk ke Sistem</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Quick Demo Helper */}
            <div className="mt-6 pt-5 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowHelper(!showHelper)}
                className="w-full flex items-center justify-between text-xs text-slate-500 hover:text-emerald-700 py-1 font-medium transition"
              >
                <span className="flex items-center gap-1.5">
                  <HelpCircle className="w-4 h-4" />
                  Pilih Cepat Akun Demo (Klik untuk Mencoba)
                </span>
                <span>{showHelper ? '▲ Sembunyikan' : '▼ Tampilkan'}</span>
              </button>

              {showHelper && (
                <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2 max-h-56 overflow-y-auto">
                  <p className="text-[11px] font-bold text-slate-700 uppercase tracking-wide">
                    Pilih Peran untuk Menguji:
                  </p>
                  <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                    <button
                      type="button"
                      onClick={() => handleQuickLogin('guru1')}
                      className="text-left px-2 py-1.5 rounded bg-white hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 transition"
                    >
                      <span className="font-semibold block">Guru Kelas 1</span>
                      <span className="font-mono text-slate-400 text-[10px]">kode: guru1</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickLogin('guru5')}
                      className="text-left px-2 py-1.5 rounded bg-white hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 transition"
                    >
                      <span className="font-semibold block">Guru Kelas 5</span>
                      <span className="font-mono text-slate-400 text-[10px]">kode: guru5</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickLogin('bendhar')}
                      className="text-left px-2 py-1.5 rounded bg-white hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 transition"
                    >
                      <span className="font-semibold block">Bendahara TARIAN</span>
                      <span className="font-mono text-slate-400 text-[10px]">kode: bendhar</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickLogin('bendww')}
                      className="text-left px-2 py-1.5 rounded bg-white hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 transition"
                    >
                      <span className="font-semibold block">Bendahara SIDYASA</span>
                      <span className="font-mono text-slate-400 text-[10px]">kode: bendww</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickLogin('benddk')}
                      className="text-left px-2 py-1.5 rounded bg-white hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 transition"
                    >
                      <span className="font-semibold block">Bendahara SIDATAN</span>
                      <span className="font-mono text-slate-400 text-[10px]">kode: benddk</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickLogin('bendum')}
                      className="text-left px-2 py-1.5 rounded bg-white hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 transition"
                    >
                      <span className="font-semibold block">Bendahara SIDANUM</span>
                      <span className="font-mono text-slate-400 text-[10px]">kode: bendum</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickLogin('kepsek')}
                      className="text-left px-2 py-1.5 rounded bg-white hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 transition"
                    >
                      <span className="font-semibold block">Kepala Sekolah</span>
                      <span className="font-mono text-slate-400 text-[10px]">kode: kepsek</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickLogin('admin')}
                      className="text-left px-2 py-1.5 rounded bg-white hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 transition"
                    >
                      <span className="font-semibold block text-amber-700">Administrator</span>
                      <span className="font-mono text-slate-400 text-[10px]">kode: admin</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleQuickLogin('240101')}
                      className="col-span-2 text-left px-2 py-1.5 rounded bg-white hover:bg-emerald-50 hover:text-emerald-700 border border-slate-200 transition"
                    >
                      <span className="font-semibold block text-indigo-700">Orang Tua (Ahmad Fauzi)</span>
                      <span className="font-mono text-slate-400 text-[10px]">NIS: 240101</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer Identity (Requirement A) */}
        <div className="mt-8 text-center text-slate-300/80 text-xs space-y-1.5">
          <div className="flex items-center justify-center gap-1.5 font-medium text-white/90">
            <User className="w-3.5 h-3.5 text-emerald-400" />
            <span>Pengembang: {db.settings.developerName}</span>
          </div>
          <div className="flex items-center justify-center gap-1.5 text-slate-400">
            <Award className="w-3.5 h-3.5" />
            <span>NIP: {db.settings.developerNip}</span>
          </div>
          <div className="flex items-center justify-center gap-1.5 text-slate-400">
            <Phone className="w-3.5 h-3.5 text-emerald-400" />
            <span>WhatsApp: {db.settings.developerWa}</span>
          </div>
          <p className="text-[11px] text-slate-500 pt-2">
            © 2026 SDN Pruwatan 02. Dilindungi Hak Cipta & Prinsip Keamanan Finansial Sekolah.
          </p>
        </div>
      </div>
    </div>
  );
};
