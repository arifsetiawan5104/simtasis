import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ConfirmModal } from '../components/ConfirmModal';
import { GraduationCap, AlertTriangle, CheckCircle2, ArrowRight, RotateCcw } from 'lucide-react';

export const KenaikanView: React.FC = () => {
  const { db, promoteStudents, showToast } = useApp();

  const [newPeriod, setNewPeriod] = useState('2025/2026');
  // List of student IDs who are retained (tinggal kelas)
  const [retainedStudentIds, setRetainedStudentIds] = useState<string[]>([]);
  const [confirmationInput, setConfirmationInput] = useState('');

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const toggleRetain = (id: string) => {
    setRetainedStudentIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleExecutePromotion = () => {
    if (confirmationInput !== 'PROSES') {
      showToast('Ketik kata PROSES pada kolom konfirmasi untuk melanjutkan', 'error');
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: 'Konfirmasi Mutasi Kenaikan Kelas Kolektif',
      message: `Anda akan menaikkan tingkat seluruh siswa kelas 1-5 ke kelas berikutnya, dan meluluskan siswa kelas 6 untuk periode ${newPeriod}. Saldo tabungan siswa akan tetap utuh mengikuti siswa. Lanjutkan?`,
      action: async () => {
        const res = await promoteStudents(newPeriod, retainedStudentIds);
        if (res.success) {
          setConfirmationInput('');
        } else {
          showToast(res.error || 'Gagal memproses kenaikan kelas', 'error');
        }
      },
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center">
            <GraduationCap className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Proses Kenaikan Kelas & Kelulusan Siswa
            </h2>
            <p className="text-xs text-slate-500">
              Mutasi kenaikan kelas akhir tahun ajaran. Saldo tabungan dan histori transaksi siswa tetap utuh.
            </p>
          </div>
        </div>
      </div>

      {/* Info Warning Card */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 space-y-3">
        <div className="flex items-center gap-2 text-amber-900 font-bold text-sm">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
          Perhatian Mekanisme Kenaikan Kelas Otomatis
        </div>
        <ul className="text-xs text-amber-800 space-y-1 pl-4 list-disc leading-relaxed">
          <li>
            <strong>Kelas 1 s/d Kelas 5:</strong> Otomatis naik 1 tingkat (Kelas 1 &rarr; Kelas 2, Kelas 2 &rarr; Kelas 3, dst).
          </li>
          <li>
            <strong>Kelas 6:</strong> Berubah status menjadi <strong>LULUS</strong>. Tabungannya tetap tersimpan di histori dan dapat ditarik penuh oleh siswa saat wisuda/perpisahan.
          </li>
          <li>
            <strong>Saldo Siswa Aman:</strong> Seluruh saldo TARIAN & SIDYASA tetap melekat pada akun siswa tanpa potongan atau reset saldo.
          </li>
        </ul>
      </div>

      {/* Configuration Box */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Periode / Tahun Ajaran Baru
            </label>
            <input
              type="text"
              value={newPeriod}
              onChange={e => setNewPeriod(e.target.value)}
              placeholder="Contoh: 2025/2026"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              Periode saat ini: <strong>{db.settings.active_period}</strong>
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Konfirmasi Keamanan (Ketik: PROSES)
            </label>
            <input
              type="text"
              value={confirmationInput}
              onChange={e => setConfirmationInput(e.target.value)}
              placeholder="Ketik PROSES di sini..."
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-bold focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Retained Student Checkbox Selection (Siswa Tinggal Kelas) */}
        <div>
          <h4 className="font-bold text-slate-900 text-sm mb-2">
            Pengecualian: Siswa Tinggal Kelas (Tidak Naik)
          </h4>
          <p className="text-xs text-slate-500 mb-3">
            Centang siswa di bawah jika ada siswa yang tetap di kelas lama dan tidak naik kelas:
          </p>

          <div className="max-h-60 overflow-y-auto border border-slate-200 rounded-xl p-3 space-y-2">
            {db.students
              .filter(s => s.status === 'AKTIF' && s.class < 6)
              .map(s => {
                const isRetained = retainedStudentIds.includes(s.id);
                return (
                  <label
                    key={s.id}
                    className="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 cursor-pointer text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={isRetained}
                        onChange={() => toggleRetain(s.id)}
                        className="rounded text-blue-600 focus:ring-blue-500"
                      />
                      <span className="font-bold text-slate-800">{s.name}</span>
                      <span className="text-slate-400">({s.nis})</span>
                    </div>
                    <span className="font-semibold text-slate-600">
                      Kelas {s.class} &rarr; {isRetained ? `Tetap Kelas ${s.class}` : `Naik ke Kelas ${s.class + 1}`}
                    </span>
                  </label>
                );
              })}
          </div>
        </div>

        <button
          type="button"
          onClick={handleExecutePromotion}
          className="w-full py-3.5 bg-blue-700 hover:bg-blue-800 text-white font-bold text-sm rounded-xl transition shadow-xs flex items-center justify-center gap-2"
        >
          <GraduationCap className="w-5 h-5" />
          Eksekusi Proses Kenaikan Kelas & Kelulusan
        </button>
      </div>
    </div>
  );
};
