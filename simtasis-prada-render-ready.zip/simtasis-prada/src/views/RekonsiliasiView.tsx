import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Denominations } from '../types';
import {
  Coins,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  History,
  FileCheck2,
  Save,
} from 'lucide-react';

const DENOM_LIST: { key: keyof Denominations; label: string; value: number; type: 'kertas' | 'logam' }[] = [
  { key: 'd100000', label: 'Rp 100.000', value: 100000, type: 'kertas' },
  { key: 'd50000', label: 'Rp 50.000', value: 50000, type: 'kertas' },
  { key: 'd20000', label: 'Rp 20.000', value: 20000, type: 'kertas' },
  { key: 'd10000', label: 'Rp 10.000', value: 10000, type: 'kertas' },
  { key: 'd5000', label: 'Rp 5.000', value: 5000, type: 'kertas' },
  { key: 'd2000', label: 'Rp 2.000', value: 2000, type: 'kertas' },
  { key: 'd1000', label: 'Rp 1.000', value: 1000, type: 'kertas' },
  { key: 'c1000', label: 'Rp 1.000 (Logam)', value: 1000, type: 'logam' },
  { key: 'c500', label: 'Rp 500 (Logam)', value: 500, type: 'logam' },
  { key: 'c200', label: 'Rp 200 (Logam)', value: 200, type: 'logam' },
  { key: 'c100', label: 'Rp 100 (Logam)', value: 100, type: 'logam' },
];

export const RekonsiliasiView: React.FC = () => {
  const { session, db, getTeacherCash, getTarianBendaharaBalance, addReconciliation, showToast } = useApp();

  if (!session) return null;

  const isTeacher = session.role.startsWith('guru');
  const teacherClass = session.classAccess || 1;

  // Context: Guru rekonsiliasi kas kelasnya, Bendahara TARIAN rekonsiliasi kas bendahara
  const defaultContext = isTeacher ? `GURU_KELAS_${teacherClass}` : 'BENDAHARA_TARIAN';
  const [context, setContext] = useState<string>(defaultContext);

  // System balance calculation
  const systemBalance = useMemo(() => {
    if (context.startsWith('GURU_KELAS_')) {
      const c = Number(context.replace('GURU_KELAS_', ''));
      return getTeacherCash(c);
    }
    if (context === 'BENDAHARA_TARIAN') {
      return getTarianBendaharaBalance();
    }
    return 0;
  }, [context, getTeacherCash, getTarianBendaharaBalance]);

  // Denominations state
  const [denoms, setDenoms] = useState<Denominations>({
    d100000: 0,
    d50000: 0,
    d20000: 0,
    d10000: 0,
    d5000: 0,
    d2000: 0,
    d1000: 0,
    c1000: 0,
    c500: 0,
    c200: 0,
    c100: 0,
  });

  const [notes, setNotes] = useState('');

  // Calculate physical total
  const physicalTotal = useMemo(() => {
    return DENOM_LIST.reduce((acc, curr) => {
      const count = denoms[curr.key] || 0;
      return acc + count * curr.value;
    }, 0);
  }, [denoms]);

  const difference = physicalTotal - systemBalance;

  const handleDenomChange = (key: keyof Denominations, value: number) => {
    setDenoms(prev => ({ ...prev, [key]: Math.max(0, value) }));
  };

  const handleReset = () => {
    setDenoms({
      d100000: 0,
      d50000: 0,
      d20000: 0,
      d10000: 0,
      d5000: 0,
      d2000: 0,
      d1000: 0,
      c1000: 0,
      c500: 0,
      c200: 0,
      c100: 0,
    });
    setNotes('');
  };

  const handleSaveRecon = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await addReconciliation({
      context,
      system_balance: systemBalance,
      physical_balance: physicalTotal,
      denominations: denoms,
      notes,
    });

    if (res.success) {
      handleReset();
    } else {
      showToast(res.error || 'Gagal menyimpan rekonsiliasi', 'error');
    }
  };

  // Filter recons for this context
  const historyRecons = db.reconciliations.filter(r => {
    if (isTeacher) return r.context === `GURU_KELAS_${teacherClass}`;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-teal-100 text-teal-800">
              <FileCheck2 className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Rekonsiliasi Kas Fisik & Pecahan Uang
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencocokan antara saldo digital di sistem dengan hitungan lembaran uang fisik di brankas atau amplop guru.
          </p>
        </div>

        {!isTeacher && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 font-semibold">Pilih Kas:</span>
            <select
              value={context}
              onChange={e => setContext(e.target.value)}
              className="text-xs font-bold px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-xl"
            >
              <option value="BENDAHARA_TARIAN">Kas Bendahara TARIAN</option>
              {[1, 2, 3, 4, 5, 6].map(c => (
                <option key={c} value={`GURU_KELAS_${c}`}>
                  Kas Guru Kelas {c}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Hitung Pecahan Form */}
        <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-base">Rincian Lembar & Keping Pecahan Uang</h3>
            <button
              type="button"
              onClick={handleReset}
              className="text-xs text-slate-500 hover:text-rose-600 flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Hitungan
            </button>
          </div>

          <form onSubmit={handleSaveRecon} className="space-y-6">
            {/* Uang Kertas */}
            <div>
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
                1. Pecahan Uang Kertas
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {DENOM_LIST.filter(d => d.type === 'kertas').map(d => {
                  const count = denoms[d.key] || 0;
                  const subTotal = count * d.value;
                  return (
                    <div
                      key={d.key}
                      className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between"
                    >
                      <div>
                        <span className="font-bold text-slate-800 text-xs">{d.label}</span>
                        <p className="font-mono text-[11px] text-slate-500 mt-0.5">
                          = Rp {subTotal.toLocaleString('id-ID')}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min="0"
                          value={count === 0 ? '' : count}
                          onChange={e => handleDenomChange(d.key, Number(e.target.value) || 0)}
                          placeholder="0"
                          className="w-16 px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-center focus:ring-2 focus:ring-teal-500 focus:outline-none"
                        />
                        <span className="text-xs text-slate-400">lbr</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Uang Logam */}
            <div>
              <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
                2. Pecahan Uang Logam (Koin)
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {DENOM_LIST.filter(d => d.type === 'logam').map(d => {
                  const count = denoms[d.key] || 0;
                  const subTotal = count * d.value;
                  return (
                    <div
                      key={d.key}
                      className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between"
                    >
                      <div>
                        <span className="font-bold text-slate-800 text-xs">{d.label}</span>
                        <p className="font-mono text-[11px] text-slate-500 mt-0.5">
                          = Rp {subTotal.toLocaleString('id-ID')}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <input
                          type="number"
                          min="0"
                          value={count === 0 ? '' : count}
                          onChange={e => handleDenomChange(d.key, Number(e.target.value) || 0)}
                          placeholder="0"
                          className="w-16 px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-center focus:ring-2 focus:ring-teal-500 focus:outline-none"
                        />
                        <span className="text-xs text-slate-400">kpg</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Catatan Hasil Hitungan Fisik
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder="Catatan jika ada selisih atau penjelasan uang fisik..."
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-500 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white font-bold text-sm rounded-xl transition shadow-xs flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              Simpan Berita Acara Rekonsiliasi
            </button>
          </form>
        </div>

        {/* Right: Perbandingan Saldo & Selisih */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <h4 className="font-bold text-slate-900 text-sm">Hasil Pencocokan Kas</h4>

            <div className="space-y-3">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-xs text-slate-500 font-medium">Saldo di Sistem:</span>
                <p className="text-xl font-black text-slate-900 font-mono mt-0.5">
                  Rp {systemBalance.toLocaleString('id-ID')}
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-teal-50 border border-teal-200">
                <span className="text-xs text-teal-800 font-medium">Total Uang Fisik Terhitung:</span>
                <p className="text-2xl font-black text-teal-900 font-mono mt-0.5">
                  Rp {physicalTotal.toLocaleString('id-ID')}
                </p>
              </div>

              {/* Status Box */}
              <div
                className={`p-4 rounded-xl border flex items-center gap-3 ${
                  difference === 0
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                    : difference > 0
                    ? 'bg-blue-50 border-blue-200 text-blue-900'
                    : 'bg-rose-50 border-rose-200 text-rose-900'
                }`}
              >
                {difference === 0 ? (
                  <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
                ) : (
                  <AlertTriangle className="w-6 h-6 text-rose-600 shrink-0" />
                )}
                <div>
                  <p className="font-bold text-xs uppercase tracking-wide">
                    {difference === 0 ? 'Status: COCOK / KLOP' : difference > 0 ? 'Status: LEBIH' : 'Status: KURANG'}
                  </p>
                  <p className="font-mono font-bold text-sm mt-0.5">
                    Selisih: {difference > 0 ? '+' : ''}Rp {difference.toLocaleString('id-ID')}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Histori Rekonsiliasi */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden p-5 space-y-3">
        <h3 className="font-bold text-slate-900 text-base">Histori Berita Acara Rekonsiliasi Fisik</h3>
        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">ID Recon</th>
                <th className="px-4 py-3">Tanggal & Waktu</th>
                <th className="px-4 py-3">Petugas</th>
                <th className="px-4 py-3">Kas</th>
                <th className="px-4 py-3 text-right">Saldo Sistem</th>
                <th className="px-4 py-3 text-right">Fisik Terhitung</th>
                <th className="px-4 py-3 text-right">Selisih</th>
                <th className="px-4 py-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {historyRecons.map(rec => (
                <tr key={rec.id} className="hover:bg-slate-50 transition">
                  <td className="px-4 py-3 font-mono font-semibold text-slate-900">{rec.id}</td>
                  <td className="px-4 py-3 text-slate-600">{rec.date} {rec.time}</td>
                  <td className="px-4 py-3 font-medium text-slate-800">{rec.created_by}</td>
                  <td className="px-4 py-3 text-slate-600">{rec.context}</td>
                  <td className="px-4 py-3 text-right font-mono">Rp {rec.system_balance.toLocaleString('id-ID')}</td>
                  <td className="px-4 py-3 text-right font-mono font-bold">
                    Rp {rec.physical_balance.toLocaleString('id-ID')}
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold">
                    <span className={rec.difference === 0 ? 'text-emerald-700' : 'text-rose-600'}>
                      {rec.difference > 0 ? '+' : ''}Rp {rec.difference.toLocaleString('id-ID')}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        rec.difference === 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {rec.difference === 0 ? 'KLOP' : 'SELISIH'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
