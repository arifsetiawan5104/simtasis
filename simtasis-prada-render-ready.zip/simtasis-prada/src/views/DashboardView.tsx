import React from 'react';
import { useApp } from '../context/AppContext';
import { NavTab } from '../components/Sidebar';
import {
  Coins,
  Wallet,
  Clock,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  ArrowDownRight,
  ArrowUpRight,
  Palmtree,
  CalendarDays,
  BookOpen,
  HandCoins,
  Users,
  Printer,
  ChevronRight,
} from 'lucide-react';

interface DashboardViewProps {
  onNavigate: (tab: NavTab) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate }) => {
  const {
    session,
    db,
    getTeacherCash,
    getTarianBendaharaBalance,
    getTotalTarianBalance,
    getTotalSidyasaBalance,
    getClassSidatanBalance,
    getTotalSidatanBalance,
    getLedgerBalance,
    getTotalSidanumBalance,
  } = useApp();

  if (!session) return null;

  const role = session.role;
  const todayStr = new Date().toISOString().split('T')[0];

  // ==========================================
  // 1. GURU KELAS VIEW
  // ==========================================
  if (role.startsWith('guru')) {
    const classNum = session.classAccess || 1;
    const classStudents = db.students.filter(s => s.class === classNum);
    const activeStudents = classStudents.filter(s => s.status === 'AKTIF');

    // Transactions of this class
    const classTxs = db.transactions.filter(t => t.class_id === classNum && t.module === 'TARIAN');
    const todayTxs = classTxs.filter(t => t.date === todayStr);

    const teacherCash = getTeacherCash(classNum);

    // Total savings of this class
    const classSavings = classTxs
      .filter(t => t.status === 'VALID')
      .reduce((s, t) => (t.type === 'SETORAN' ? s + t.amount : t.type === 'PENARIKAN' ? s - t.amount : s), 0);

    const pendingSetoran = classTxs.filter(
      t => t.type === 'SETORAN_GURU_KE_BENDAHARA' && t.status === 'PENDING'
    );

    return (
      <div className="space-y-6">
        {/* Banner Welcome */}
        <div className="bg-gradient-to-r from-blue-900 to-indigo-900 rounded-2xl p-6 text-white shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-semibold px-2.5 py-1 bg-white/20 rounded-full">
                Portal Guru Kelas {classNum}
              </span>
              <h2 className="text-2xl font-black mt-2 tracking-tight">
                Tabungan Harian (TARIAN) Kelas {classNum}
              </h2>
              <p className="text-blue-200 text-sm mt-1">
                Kelola setoran harian, penarikan siswa, dan penyetoran kas ke Bendahara sekolah.
              </p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => onNavigate('tarian')}
                className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-sm shadow-sm transition flex items-center gap-1.5"
              >
                <Coins className="w-4 h-4" />
                Catat Transaksi Siswa
              </button>
            </div>
          </div>
        </div>

        {/* 4 Stat Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase">
              <span>Kas di Tangan Anda</span>
              <Wallet className="w-4 h-4 text-emerald-600" />
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2 font-mono">
              Rp {teacherCash.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">
              Uang fisik siap disetor ke bendahara
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase">
              <span>Total Saldo Siswa Kelas</span>
              <Coins className="w-4 h-4 text-blue-600" />
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2 font-mono">
              Rp {classSavings.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">
              Tabungan kumulatif siswa Kelas {classNum}
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase">
              <span>Jumlah Siswa Aktif</span>
              <Users className="w-4 h-4 text-purple-600" />
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2">
              {activeStudents.length}{' '}
              <span className="text-sm font-normal text-slate-500">/ {classStudents.length} siswa</span>
            </p>
            <p className="text-[11px] text-slate-500 mt-1">
              Terdaftar di kelas {classNum}
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="flex items-center justify-between text-slate-500 text-xs font-semibold uppercase">
              <span>Transaksi Hari Ini</span>
              <Clock className="w-4 h-4 text-amber-600" />
            </div>
            <p className="text-2xl font-black text-slate-900 mt-2">
              {todayTxs.length}{' '}
              <span className="text-sm font-normal text-slate-500">transaksi</span>
            </p>
            <p className="text-[11px] text-slate-500 mt-1">
              {pendingSetoran.length > 0 ? `${pendingSetoran.length} menunggu verifikasi` : 'Semua klop'}
            </p>
          </div>
        </div>

        {/* Pending Setoran Alert if any */}
        {pendingSetoran.length > 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
              <div>
                <p className="text-xs font-bold text-amber-900">
                  Ada {pendingSetoran.length} Pengajuan Setoran Menunggu Verifikasi Bendahara
                </p>
                <p className="text-[11px] text-amber-700">
                  Total pengajuan: Rp{' '}
                  {pendingSetoran.reduce((s, t) => s + t.amount, 0).toLocaleString('id-ID')}
                </p>
              </div>
            </div>
            <button
              onClick={() => onNavigate('tarian')}
              className="text-xs font-bold text-amber-800 underline hover:text-amber-950"
            >
              Lihat Detail
            </button>
          </div>
        )}

        {/* Recent Transactions List */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Riwayat Transaksi Terakhir</h3>
              <p className="text-xs text-slate-500">Aktivitas tabungan siswa kelas Anda</p>
            </div>
            <button
              onClick={() => onNavigate('tarian')}
              className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              Buka Semua
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="divide-y divide-slate-100 overflow-x-auto">
            {classTxs.slice(0, 5).map(tx => (
              <div key={tx.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition text-sm">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      tx.type === 'SETORAN'
                        ? 'bg-emerald-100 text-emerald-700'
                        : tx.type === 'PENARIKAN'
                        ? 'bg-rose-100 text-rose-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}
                  >
                    {tx.type === 'SETORAN' ? (
                      <ArrowDownRight className="w-5 h-5" />
                    ) : tx.type === 'PENARIKAN' ? (
                      <ArrowUpRight className="w-5 h-5" />
                    ) : (
                      <TrendingUp className="w-5 h-5" />
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{tx.student_name || tx.type}</span>
                      <span className="text-xs font-mono text-slate-400">({tx.id})</span>
                    </div>
                    <p className="text-xs text-slate-500">
                      {tx.date} • {tx.time} • {tx.description}
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <span
                    className={`font-mono font-bold ${
                      tx.type === 'PENARIKAN' ? 'text-rose-600' : 'text-emerald-700'
                    }`}
                  >
                    {tx.type === 'PENARIKAN' ? '-' : '+'}Rp {tx.amount.toLocaleString('id-ID')}
                  </span>
                  <div>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                        tx.status === 'VALID'
                          ? 'bg-emerald-50 text-emerald-700'
                          : tx.status === 'PENDING'
                          ? 'bg-amber-50 text-amber-700'
                          : 'bg-rose-50 text-rose-700'
                      }`}
                    >
                      {tx.status}
                    </span>
                  </div>
                </div>
              </div>
            ))}

            {classTxs.length === 0 && (
              <div className="p-8 text-center text-slate-400 text-xs">
                Belum ada transaksi di kelas {classNum}.
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // 2. BENDAHARA TARIAN VIEW
  // ==========================================
  if (role === 'bendhar') {
    const totalTarian = getTotalTarianBalance();
    const bendaharaKas = getTarianBendaharaBalance();
    const pendingSetoran = db.transactions.filter(
      t => t.module === 'TARIAN' && t.type === 'SETORAN_GURU_KE_BENDAHARA' && t.status === 'PENDING'
    );
    const activeBosLoans = db.loans.filter(l => l.source_module === 'TARIAN' && l.status !== 'LUNAS');

    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-emerald-900 to-teal-900 rounded-2xl p-6 text-white shadow-md">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs font-semibold px-2.5 py-1 bg-white/20 rounded-full">
                Bendahara TARIAN
              </span>
              <h2 className="text-2xl font-black mt-2 tracking-tight">
                Manajemen Tabungan Harian Siswa (TARIAN)
              </h2>
              <p className="text-emerald-200 text-sm mt-1">
                Verifikasi setoran kas guru kelas 1 - 6 dan kelola dana kas pusat TARIAN.
              </p>
            </div>
            <button
              onClick={() => onNavigate('verifikasi')}
              className="px-4 py-2.5 rounded-xl bg-white text-emerald-950 font-bold text-sm shadow-sm transition flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              Verifikasi Setoran ({pendingSetoran.length})
            </button>
          </div>
        </div>

        {/* 4 Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Kas Bendahara TARIAN</span>
            <p className="text-2xl font-black text-emerald-700 mt-2 font-mono">
              Rp {bendaharaKas.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Uang yang sudah diverifikasi</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Total Saldo Siswa</span>
            <p className="text-2xl font-black text-slate-900 mt-2 font-mono">
              Rp {totalTarian.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Seluruh siswa Kelas 1 - 6</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Setoran Belum Diverifikasi</span>
            <p className="text-2xl font-black text-amber-600 mt-2">
              {pendingSetoran.length}{' '}
              <span className="text-sm font-normal text-slate-500">pengajuan</span>
            </p>
            <p className="text-[11px] text-slate-500 mt-1">
              Rp {pendingSetoran.reduce((s, t) => s + t.amount, 0).toLocaleString('id-ID')}
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Pinjaman BOS Aktif</span>
            <p className="text-2xl font-black text-purple-700 mt-2 font-mono">
              Rp {activeBosLoans.reduce((s, l) => s + l.remaining, 0).toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">{activeBosLoans.length} pinjaman belum lunas</p>
          </div>
        </div>

        {/* Per-class breakdown */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
          <h3 className="font-bold text-slate-900 text-base mb-4">Rekapitulasi Saldo Kas per Kelas</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {[1, 2, 3, 4, 5, 6].map(c => {
              const teacherCash = getTeacherCash(c);
              const classSavings = db.transactions
                .filter(t => t.class_id === c && t.module === 'TARIAN' && t.status === 'VALID')
                .reduce((s, t) => (t.type === 'SETORAN' ? s + t.amount : t.type === 'PENARIKAN' ? s - t.amount : s), 0);

              return (
                <div key={c} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60">
                  <p className="text-xs font-bold text-slate-800">Kelas {c}</p>
                  <p className="text-[11px] text-slate-500 mt-1">Saldo Siswa:</p>
                  <p className="text-xs font-bold text-slate-900 font-mono">
                    Rp {classSavings.toLocaleString('id-ID')}
                  </p>
                  <p className="text-[11px] text-slate-500 mt-1">Dipegang Guru:</p>
                  <p className="text-xs font-bold text-emerald-700 font-mono">
                    Rp {teacherCash.toLocaleString('id-ID')}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // 3. BENDAHARA SIDYASA VIEW
  // ==========================================
  if (role === 'bendww') {
    const totalSidyasa = getTotalSidyasaBalance();
    const sidyasaTxs = db.transactions.filter(t => t.module === 'SIDYASA' && t.status === 'VALID');
    const setoran = sidyasaTxs.filter(t => t.type === 'SETORAN').reduce((s, t) => s + t.amount, 0);
    const penarikan = sidyasaTxs.filter(t => t.type === 'PENARIKAN').reduce((s, t) => s + t.amount, 0);
    const pengeluaranWisata = sidyasaTxs
      .filter(t => t.type === 'PENGELUARAN_WIDYAWISATA')
      .reduce((s, t) => s + t.amount, 0);

    const saversCount = new Set(sidyasaTxs.filter(t => t.type === 'SETORAN').map(t => t.student_id)).size;

    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-cyan-900 to-blue-900 rounded-2xl p-6 text-white shadow-md">
          <span className="text-xs font-semibold px-2.5 py-1 bg-white/20 rounded-full">
            Bendahara SIDYASA
          </span>
          <h2 className="text-2xl font-black mt-2 tracking-tight">Simpanan Widyawisata (SIDYASA)</h2>
          <p className="text-cyan-200 text-sm mt-1">
            Pengelolaan simpanan wisata siswa dari database siswa utama dan pengeluaran kegiatan widyawisata.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Total Kas SIDYASA</span>
            <p className="text-2xl font-black text-cyan-700 mt-2 font-mono">
              Rp {totalSidyasa.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Saldo aktif yang tersedia</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Total Setoran Siswa</span>
            <p className="text-2xl font-black text-slate-900 mt-2 font-mono">
              Rp {setoran.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Dari {saversCount} siswa menabung</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Penarikan Siswa</span>
            <p className="text-2xl font-black text-rose-600 mt-2 font-mono">
              Rp {penarikan.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Siswa ditarik kembali</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Pengeluaran Widyawisata</span>
            <p className="text-2xl font-black text-amber-600 mt-2 font-mono">
              Rp {pengeluaranWisata.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Biaya operasional wisata</p>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // 4. BENDAHARA SIDATAN VIEW
  // ==========================================
  if (role === 'benddk') {
    const totalSidatan = getTotalSidatanBalance();
    const sidatanTxs = db.transactions.filter(t => t.module === 'SIDATAN' && t.status === 'VALID');
    const totalSetoran = sidatanTxs.filter(t => t.type === 'SETORAN_KELAS').reduce((s, t) => s + t.amount, 0);
    const totalPengeluaran = sidatanTxs.filter(t => t.type === 'PENGELUARAN_KEGIATAN').reduce((s, t) => s + t.amount, 0);

    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-amber-900 to-orange-950 rounded-2xl p-6 text-white shadow-md">
          <span className="text-xs font-semibold px-2.5 py-1 bg-white/20 rounded-full">
            Bendahara SIDATAN
          </span>
          <h2 className="text-2xl font-black mt-2 tracking-tight">Simpanan Dana Kegiatan (SIDATAN)</h2>
          <p className="text-amber-200 text-sm mt-1">
            Pencatatan setoran akumulatif per kelas (Kelas 1 - 6) dan pengeluaran kegiatan sekolah.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Total Saldo SIDATAN</span>
            <p className="text-2xl font-black text-amber-700 mt-2 font-mono">
              Rp {totalSidatan.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Saldo akhir kas kegiatan</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Total Setoran Kelas</span>
            <p className="text-2xl font-black text-emerald-700 mt-2 font-mono">
              Rp {totalSetoran.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Iuran dari Kelas 1 - 6</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Total Pengeluaran</span>
            <p className="text-2xl font-black text-rose-600 mt-2 font-mono">
              Rp {totalPengeluaran.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Biaya pelaksanaan kegiatan</p>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
          <h3 className="font-bold text-slate-900 text-base mb-4">Saldo SIDATAN per Kelas</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {[1, 2, 3, 4, 5, 6].map(c => {
              const bal = getClassSidatanBalance(c);
              return (
                <div key={c} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60 text-center">
                  <p className="text-xs font-bold text-slate-700">Kelas {c}</p>
                  <p className="text-sm font-black text-amber-800 mt-1 font-mono">
                    Rp {bal.toLocaleString('id-ID')}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // 5. BENDAHARA SIDANUM VIEW
  // ==========================================
  if (role === 'bendum') {
    const totalSidanum = getTotalSidanumBalance();
    const activeLedgers = db.ledgers.filter(l => l.status === 'AKTIF');
    const activeBosLoans = db.loans.filter(l => l.source_module === 'SIDANUM' && l.status !== 'LUNAS');

    return (
      <div className="space-y-6">
        <div className="bg-gradient-to-r from-purple-950 to-indigo-950 rounded-2xl p-6 text-white shadow-md">
          <span className="text-xs font-semibold px-2.5 py-1 bg-white/20 rounded-full">
            Bendahara SIDANUM
          </span>
          <h2 className="text-2xl font-black mt-2 tracking-tight">Simpanan Dana Umum (SIDANUM)</h2>
          <p className="text-purple-200 text-sm mt-1">
            Pengelolaan buku-buku dana khusus (seragam, donasi, komite) dan pinjaman talangan BOS.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Saldo Global SIDANUM</span>
            <p className="text-2xl font-black text-purple-800 mt-2 font-mono">
              Rp {totalSidanum.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">Total seluruh buku aktif - pinjaman</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Jumlah Buku Aktif</span>
            <p className="text-2xl font-black text-slate-900 mt-2">{activeLedgers.length} Buku</p>
            <p className="text-[11px] text-slate-500 mt-1">Buku kas terpisah</p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
            <span className="text-xs font-semibold text-slate-500 uppercase">Pinjaman BOS</span>
            <p className="text-2xl font-black text-amber-700 mt-2 font-mono">
              Rp {activeBosLoans.reduce((s, l) => s + l.remaining, 0).toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-500 mt-1">{activeBosLoans.length} pinjaman dari SIDANUM</p>
          </div>
        </div>

        {/* Ledger Breakdown Cards */}
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6">
          <h3 className="font-bold text-slate-900 text-base mb-4">Rincian Buku Dana Aktif</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {activeLedgers.map(led => {
              const bal = getLedgerBalance(led.id);
              return (
                <div key={led.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-sm">{led.name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold">
                      AKTIF
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{led.source}</p>
                  <div className="mt-3 pt-2 border-t border-slate-200 flex items-center justify-between">
                    <span className="text-xs text-slate-500">Saldo Buku:</span>
                    <span className="font-mono font-bold text-slate-900">
                      Rp {bal.toLocaleString('id-ID')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // 6. KEPALA SEKOLAH & ADMINISTRATOR VIEW
  // ==========================================
  const totalTarian = getTotalTarianBalance();
  const totalSidyasa = getTotalSidyasaBalance();
  const totalSidatan = getTotalSidatanBalance();
  const totalSidanum = getTotalSidanumBalance();
  const tarianBendahara = getTarianBendaharaBalance();

  const totalSchoolFunds = totalTarian + totalSidyasa + totalSidatan + totalSidanum;

  const totalLoansRemaining = db.loans
    .filter(l => l.status !== 'LUNAS')
    .reduce((s, l) => s + l.remaining, 0);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 rounded-3xl p-6 sm:p-8 text-white shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold mb-2">
              <span>{role === 'kepsek' ? 'Laporan Eksekutif Kepala Sekolah' : 'Dashboard Utama Administrator'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
              Ringkasan Keuangan 4 Pilar Simpanan
            </h2>
            <p className="text-slate-300 text-sm mt-1 max-w-2xl leading-relaxed">
              SDN Pruwatan 02 — Rekapitulasi TARIAN, SIDYASA, SIDATAN, dan SIDANUM dengan transparansi & akurasi tinggi.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('laporan')}
              className="px-4 py-2.5 bg-white text-slate-900 font-bold rounded-xl text-xs hover:bg-slate-100 transition shadow flex items-center gap-1.5"
            >
              <Printer className="w-4 h-4" />
              Cetak Laporan
            </button>
          </div>
        </div>

        {/* Big Total Card */}
        <div className="mt-6 pt-6 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <span className="text-xs text-slate-400 font-medium">Akumulasi Seluruh Dana Sekolah</span>
            <p className="text-3xl font-black text-emerald-400 font-mono mt-1">
              Rp {totalSchoolFunds.toLocaleString('id-ID')}
            </p>
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium">Sisa Pinjaman Bendahara BOS</span>
            <p className="text-2xl font-bold text-amber-300 font-mono mt-1">
              Rp {totalLoansRemaining.toLocaleString('id-ID')}
            </p>
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium">Total Siswa Terdaftar</span>
            <p className="text-2xl font-bold text-white mt-1">
              {db.students.length} Siswa{' '}
              <span className="text-xs font-normal text-emerald-400">
                ({db.students.filter(s => s.status === 'AKTIF').length} Aktif)
              </span>
            </p>
          </div>
        </div>
      </div>

      {/* 4 Pilar Dana Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* TARIAN */}
        <div
          onClick={() => onNavigate('tarian')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-300 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
              1. TARIAN (Tabungan Siswa)
            </span>
            <Coins className="w-5 h-5 text-emerald-600 group-hover:scale-110 transition" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2 font-mono">
            Rp {totalTarian.toLocaleString('id-ID')}
          </p>
          <div className="mt-2 text-[11px] text-slate-500 space-y-0.5">
            <p>Kas di Bendahara: Rp {tarianBendahara.toLocaleString('id-ID')}</p>
            <p>
              Kas di Guru 1-6: Rp{' '}
              {[1, 2, 3, 4, 5, 6].reduce((s, c) => s + getTeacherCash(c), 0).toLocaleString('id-ID')}
            </p>
          </div>
        </div>

        {/* SIDYASA */}
        <div
          onClick={() => onNavigate('sidyasa')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-cyan-300 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-700">
              2. SIDYASA (Widyawisata)
            </span>
            <Palmtree className="w-5 h-5 text-cyan-600 group-hover:scale-110 transition" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2 font-mono">
            Rp {totalSidyasa.toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-500 mt-2">
            Simpanan terencana kegiatan widyawisata siswa
          </p>
        </div>

        {/* SIDATAN */}
        <div
          onClick={() => onNavigate('sidatan')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-amber-300 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700">
              3. SIDATAN (Dana Kegiatan)
            </span>
            <CalendarDays className="w-5 h-5 text-amber-600 group-hover:scale-110 transition" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2 font-mono">
            Rp {totalSidatan.toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-500 mt-2">
            Akumulasi simpanan kegiatan Kelas 1 - 6
          </p>
        </div>

        {/* SIDANUM */}
        <div
          onClick={() => onNavigate('sidanum')}
          className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-purple-300 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-purple-700">
              4. SIDANUM (Dana Umum)
            </span>
            <BookOpen className="w-5 h-5 text-purple-600 group-hover:scale-110 transition" />
          </div>
          <p className="text-2xl font-black text-slate-900 mt-2 font-mono">
            Rp {totalSidanum.toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-500 mt-2">
            {db.ledgers.filter(l => l.status === 'AKTIF').length} buku dana terkelola
          </p>
        </div>
      </div>

      {/* Rekap TARIAN per Kelas Table (Requirement AL) */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Rekapitulasi TARIAN per Kelas (1 — 6)</h3>
            <p className="text-xs text-slate-500">
              Rincian jumlah siswa, setoran, penarikan, kas dipegang guru, dan kas disetor ke bendahara
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Kelas</th>
                <th className="px-4 py-3 text-center">Jml Siswa</th>
                <th className="px-4 py-3 text-right">Total Setoran</th>
                <th className="px-4 py-3 text-right">Total Penarikan</th>
                <th className="px-4 py-3 text-right">Saldo Siswa</th>
                <th className="px-4 py-3 text-right">Kas Dipegang Guru</th>
                <th className="px-4 py-3 text-right">Disetor ke Bendahara</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[1, 2, 3, 4, 5, 6].map(c => {
                const classStudents = db.students.filter(s => s.class === c);
                const classTxs = db.transactions.filter(t => t.class_id === c && t.module === 'TARIAN');
                const setoran = classTxs.filter(t => t.type === 'SETORAN' && t.status === 'VALID').reduce((s, t) => s + t.amount, 0);
                const penarikan = classTxs.filter(t => t.type === 'PENARIKAN' && t.status === 'VALID').reduce((s, t) => s + t.amount, 0);
                const saldoSiswa = setoran - penarikan;
                const kasGuru = getTeacherCash(c);
                const disetorBendahara = classTxs
                  .filter(t => t.type === 'SETORAN_GURU_KE_BENDAHARA' && t.status === 'VALID')
                  .reduce((s, t) => s + t.amount, 0);

                return (
                  <tr key={c} className="hover:bg-slate-50/70 transition">
                    <td className="px-4 py-3 font-bold text-slate-900">Kelas {c}</td>
                    <td className="px-4 py-3 text-center text-slate-600">{classStudents.length}</td>
                    <td className="px-4 py-3 text-right font-mono text-emerald-700">
                      Rp {setoran.toLocaleString('id-ID')}
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-rose-600">
                      Rp {penarikan.toLocaleString('id-ID')}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-slate-900">
                      Rp {saldoSiswa.toLocaleString('id-ID')}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-semibold text-blue-700">
                      Rp {kasGuru.toLocaleString('id-ID')}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-semibold text-emerald-700">
                      Rp {disetorBendahara.toLocaleString('id-ID')}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
