import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { ConfirmModal } from '../components/ConfirmModal';
import { Ledger } from '../types';
import {
  BookOpen,
  PlusCircle,
  ArrowDownRight,
  ArrowUpRight,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  FolderKanban,
} from 'lucide-react';

export const SidanumView: React.FC = () => {
  const {
    db,
    addLedger,
    editLedger,
    addTransaction,
    getLedgerBalance,
    getTotalSidanumBalance,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'transaksi-buku' | 'daftar-buku' | 'riwayat'>('transaksi-buku');

  // Selected Ledger for Transaction
  const [selectedLedgerId, setSelectedLedgerId] = useState<string>(
    db.ledgers.length > 0 ? db.ledgers[0].id : ''
  );
  const [txType, setTxType] = useState<'PEMASUKAN' | 'PENGELUARAN'>('PEMASUKAN');
  const [amount, setAmount] = useState<number | ''>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState<string>('');

  // Add Ledger Form State
  const [isAddLedgerOpen, setIsAddLedgerOpen] = useState(false);
  const [newLedgerName, setNewLedgerName] = useState('');
  const [newLedgerSource, setNewLedgerSource] = useState('');
  const [newLedgerDesc, setNewLedgerDesc] = useState('');

  // Edit Ledger Form State
  const [editingLedger, setEditingLedger] = useState<Ledger | null>(null);
  const [editName, setEditName] = useState('');
  const [editStatus, setEditStatus] = useState<'AKTIF' | 'NONAKTIF'>('AKTIF');

  // Confirmation Modal
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
    variant?: 'danger' | 'warning' | 'primary';
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const totalSidanum = getTotalSidanumBalance();
  const activeLedgers = db.ledgers.filter(l => l.status === 'AKTIF');

  const selectedLedger = useMemo(() => {
    return db.ledgers.find(l => l.id === selectedLedgerId);
  }, [db.ledgers, selectedLedgerId]);

  const selectedLedgerBal = selectedLedger ? getLedgerBalance(selectedLedger.id) : 0;

  // Submit Transaction
  const handleSaveTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedLedger) {
      showToast('Pilih buku dana terlebih dahulu', 'error');
      return;
    }

    const num = Number(amount);
    if (!num || num <= 0) {
      showToast('Nominal harus lebih besar dari 0', 'error');
      return;
    }

    if (txType === 'PENGELUARAN' && num > selectedLedgerBal) {
      showToast(`Pengeluaran melebihi saldo buku "${selectedLedger.name}" (Rp ${selectedLedgerBal.toLocaleString('id-ID')})`, 'error');
      return;
    }

    const backendType = txType === 'PEMASUKAN' ? 'PEMASUKAN_DANA_UMUM' : 'PENGELUARAN_DANA_UMUM';

    setConfirmModal({
      isOpen: true,
      title: txType === 'PEMASUKAN' ? 'Konfirmasi Pemasukan Dana' : 'Konfirmasi Pengeluaran Dana',
      message: `Catat ${txType.toLowerCase()} sebesar Rp ${num.toLocaleString('id-ID')} pada buku "${selectedLedger.name}"?`,
      variant: txType === 'PENGELUARAN' ? 'warning' : 'primary',
      action: async () => {
        const res = await addTransaction({
          module: 'SIDANUM',
          type: backendType,
          ledger_id: selectedLedger.id,
          amount: num,
          date,
          description: description || (txType === 'PEMASUKAN' ? 'Pemasukan dana kas' : 'Pengeluaran keperluan dana'),
        });
        if (res.success) {
          setAmount('');
          setDescription('');
        }
      },
    });
  };

  // Submit Add Ledger
  const handleSaveNewLedger = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLedgerName.trim() || !newLedgerSource.trim()) {
      showToast('Nama buku dan sumber dana wajib diisi', 'error');
      return;
    }
    const res = await addLedger(newLedgerName.trim(), newLedgerSource.trim(), newLedgerDesc.trim());
    if (res.success) {
      setIsAddLedgerOpen(false);
      setNewLedgerName('');
      setNewLedgerSource('');
      setNewLedgerDesc('');
    } else {
      showToast(res.error || 'Gagal menambahkan buku', 'error');
    }
  };

  // Submit Edit Ledger
  const handleSaveEditLedger = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingLedger) return;
    const res = await editLedger(editingLedger.id, editName, editStatus);
    if (res.success) {
      setEditingLedger(null);
    } else {
      showToast(res.error || 'Gagal memperbarui buku', 'error');
    }
  };

  const sidanumTxs = db.transactions.filter(t => t.module === 'SIDANUM');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-purple-100 text-purple-800">
              <BookOpen className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              SIDANUM — Simpanan Dana Umum
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Manajemen multi-buku dana khusus yang independen (Buku Seragam, Donasi, Uang Komite, dll.).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('transaksi-buku')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'transaksi-buku' ? 'bg-purple-800 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Transaksi Buku Dana
          </button>
          <button
            onClick={() => setActiveTab('daftar-buku')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'daftar-buku' ? 'bg-purple-800 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Kelola Buku ({db.ledgers.length})
          </button>
          <button
            onClick={() => setActiveTab('riwayat')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'riwayat' ? 'bg-purple-800 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Riwayat SIDANUM
          </button>
        </div>
      </div>

      {/* Global Balance Card */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Saldo Global SIDANUM</span>
          <p className="text-2xl font-black text-purple-900 mt-1 font-mono">
            Rp {totalSidanum.toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-400">Total seluruh buku aktif yang tersedia</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Jumlah Buku Aktif</span>
          <p className="text-2xl font-black text-slate-900 mt-1">
            {activeLedgers.length} <span className="text-sm font-normal text-slate-500">/ {db.ledgers.length} buku</span>
          </p>
          <p className="text-[11px] text-slate-400">Buku kas mandiri berstatus aktif</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Total Transaksi Masuk/Keluar</span>
          <p className="text-2xl font-black text-slate-900 mt-1">{sidanumTxs.length} Transaksi</p>
          <p className="text-[11px] text-slate-400">Tersimpan dalam database</p>
        </div>
      </div>

      {/* Tab 1: Transaksi Buku */}
      {activeTab === 'transaksi-buku' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-base">Pencatatan Transaksi Kas Buku Dana</h3>
              <div className="flex rounded-xl p-1 bg-slate-100 border border-slate-200">
                <button
                  type="button"
                  onClick={() => setTxType('PEMASUKAN')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    txType === 'PEMASUKAN' ? 'bg-purple-800 text-white shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Pemasukan
                </button>
                <button
                  type="button"
                  onClick={() => setTxType('PENGELUARAN')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    txType === 'PENGELUARAN' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Pengeluaran
                </button>
              </div>
            </div>

            <form onSubmit={handleSaveTransaction} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Pilih Buku Dana
                </label>
                <select
                  value={selectedLedgerId}
                  onChange={e => setSelectedLedgerId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none"
                  required
                >
                  <option value="">-- Pilih Buku Dana --</option>
                  {activeLedgers.map(l => {
                    const bal = getLedgerBalance(l.id);
                    return (
                      <option key={l.id} value={l.id}>
                        {l.name} (Saldo: Rp {bal.toLocaleString('id-ID')})
                      </option>
                    );
                  })}
                </select>
              </div>

              {selectedLedger && (
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs flex justify-between items-center">
                  <div>
                    <p className="font-bold text-slate-900">{selectedLedger.name}</p>
                    <p className="text-slate-500">Sumber Dana: {selectedLedger.source}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[11px] text-slate-400">Saldo Buku Saat Ini:</p>
                    <p className="font-mono font-bold text-purple-900 text-sm">
                      Rp {selectedLedgerBal.toLocaleString('id-ID')}
                    </p>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nominal Transaksi (Rp)
                </label>
                <input
                  type="number"
                  min="1000"
                  step="500"
                  value={amount}
                  onChange={e => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Contoh: 200000"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-semibold focus:ring-2 focus:ring-purple-500 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Keterangan
                  </label>
                  <input
                    type="text"
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    placeholder="Contoh: Pembayaran kain batik seragam"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className={`w-full py-3 rounded-xl text-sm font-bold text-white shadow-xs transition flex items-center justify-center gap-2 ${
                  txType === 'PEMASUKAN' ? 'bg-purple-800 hover:bg-purple-900' : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                Simpan {txType === 'PEMASUKAN' ? 'Pemasukan Dana' : 'Pengeluaran Dana'}
              </button>
            </form>
          </div>

          <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
            <h4 className="font-bold text-slate-900 text-sm">Prinsip Multi-Buku SIDANUM</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Setiap buku dana dihitung secara mandiri (terpisah dari buku lainnya). Pengeluaran dari suatu buku tidak boleh melebihi saldo buku yang bersangkutan.
            </p>
          </div>
        </div>
      )}

      {/* Tab 2: Kelola Buku Dana */}
      {activeTab === 'daftar-buku' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Daftar Buku Dana Umum</h3>
              <p className="text-xs text-slate-500">Kelola buku dana terpisah untuk tiap peruntukan</p>
            </div>
            <button
              onClick={() => setIsAddLedgerOpen(true)}
              className="px-4 py-2 bg-purple-800 hover:bg-purple-900 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5"
            >
              <PlusCircle className="w-4 h-4" />
              Buat Buku Baru
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {db.ledgers.map(led => {
              const bal = getLedgerBalance(led.id);
              return (
                <div key={led.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-sm">{led.name}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        led.status === 'AKTIF' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {led.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">Sumber: {led.source}</p>
                  <p className="text-[11px] text-slate-400">{led.description}</p>

                  <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                    <span className="text-xs text-slate-600 font-medium">Saldo:</span>
                    <span className="font-mono font-bold text-purple-900">Rp {bal.toLocaleString('id-ID')}</span>
                  </div>

                  <div className="pt-1 flex justify-end">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingLedger(led);
                        setEditName(led.name);
                        setEditStatus(led.status);
                      }}
                      className="text-xs font-semibold text-slate-600 hover:text-purple-800 flex items-center gap-1"
                    >
                      <Edit2 className="w-3 h-3" />
                      Edit Buku
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 3: Riwayat Transaksi */}
      {activeTab === 'riwayat' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
          <h3 className="font-bold text-slate-900 text-base">Riwayat Transaksi SIDANUM</h3>
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">ID Transaksi</th>
                  <th className="px-4 py-3">Tanggal</th>
                  <th className="px-4 py-3">Buku Dana</th>
                  <th className="px-4 py-3">Jenis</th>
                  <th className="px-4 py-3 text-right">Nominal</th>
                  <th className="px-4 py-3">Keterangan</th>
                  <th className="px-4 py-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sidanumTxs.map(tx => {
                  const ledger = db.ledgers.find(l => l.id === tx.ledger_id);
                  return (
                    <tr key={tx.id} className="hover:bg-slate-50 transition">
                      <td className="px-4 py-3 font-mono font-semibold text-slate-900">{tx.id}</td>
                      <td className="px-4 py-3 text-slate-600">{tx.date}</td>
                      <td className="px-4 py-3 font-medium text-slate-800">{ledger ? ledger.name : 'Buku Khusus'}</td>
                      <td className="px-4 py-3 font-bold text-slate-800">
                        {tx.type === 'PEMASUKAN_DANA_UMUM' ? 'PEMASUKAN' : 'PENGELUARAN'}
                      </td>
                      <td className="px-4 py-3 text-right font-mono font-bold">
                        <span className={tx.type === 'PEMASUKAN_DANA_UMUM' ? 'text-emerald-700' : 'text-rose-600'}>
                          {tx.type === 'PEMASUKAN_DANA_UMUM' ? '+' : '-'}Rp {tx.amount.toLocaleString('id-ID')}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-500 text-[11px]">{tx.description}</td>
                      <td className="px-4 py-3 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          {tx.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Add Ledger */}
      {isAddLedgerOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-slate-900 text-base">Buat Buku Dana Baru</h3>
            <form onSubmit={handleSaveNewLedger} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nama Buku Dana
                </label>
                <input
                  type="text"
                  value={newLedgerName}
                  onChange={e => setNewLedgerName(e.target.value)}
                  placeholder="Contoh: Buku Dana Donasi Masjid"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Sumber Dana
                </label>
                <input
                  type="text"
                  value={newLedgerSource}
                  onChange={e => setNewLedgerSource(e.target.value)}
                  placeholder="Contoh: Wali Murid & Alumni"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Deskripsi / Keterangan
                </label>
                <textarea
                  rows={2}
                  value={newLedgerDesc}
                  onChange={e => setNewLedgerDesc(e.target.value)}
                  placeholder="Keterangan peruntukan buku dana ini..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-purple-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddLedgerOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-800 hover:bg-purple-900 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Simpan Buku
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Edit Ledger */}
      {editingLedger && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-slate-900 text-base">Edit Buku Dana</h3>
            <form onSubmit={handleSaveEditLedger} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nama Buku Dana
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Status Buku
                </label>
                <select
                  value={editStatus}
                  onChange={e => setEditStatus(e.target.value as 'AKTIF' | 'NONAKTIF')}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-purple-500 focus:outline-none"
                >
                  <option value="AKTIF">AKTIF</option>
                  <option value="NONAKTIF">NONAKTIF</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingLedger(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-purple-800 hover:bg-purple-900 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Perbarui Buku
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
        onConfirm={confirmModal.action}
        onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
