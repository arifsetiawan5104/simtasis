import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Printer,
  FileSpreadsheet,
  Coins,
  BookOpen,
  CalendarDays,
  Palmtree,
  UserCheck,
  Search,
} from 'lucide-react';

export const LaporanView: React.FC = () => {
  const {
    db,
    getTotalTarianBalance,
    getTarianBendaharaBalance,
    getTeacherCash,
    getTotalSidyasaBalance,
    getTotalSidatanBalance,
    getTotalSidanumBalance,
    getStudentTarianBalance,
    getStudentSidyasaBalance,
  } = useApp();

  const [reportType, setReportType] = useState<
    'rekap-sekolah' | 'tarian-kelas' | 'buku-siswa' | 'rekap-pinjaman-bos'
  >('rekap-sekolah');

  // For Buku Tabungan Siswa
  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    db.students.length > 0 ? db.students[0].id : ''
  );
  const [selectedClass, setSelectedClass] = useState<number>(1);

  const selectedStudent = db.students.find(s => s.id === selectedStudentId);

  // Totals
  const totalTarian = getTotalTarianBalance();
  const tarianBendahara = getTarianBendaharaBalance();
  const totalSidyasa = getTotalSidyasaBalance();
  const totalSidatan = getTotalSidatanBalance();
  const totalSidanum = getTotalSidanumBalance();
  const grandTotal = totalTarian + totalSidyasa + totalSidatan + totalSidanum;

  const totalLoansRemaining = db.loans
    .filter(l => l.status !== 'LUNAS')
    .reduce((s, l) => s + l.remaining, 0);

  const handlePrint = () => {
    window.print();
  };

  // Student Transactions for Buku Tabungan
  const studentTxs = db.transactions.filter(
    t => t.student_id === selectedStudentId && t.status === 'VALID'
  );

  return (
    <div className="space-y-6">
      {/* Control Bar (Hidden when printing) */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Printer className="w-5 h-5 text-emerald-600" />
            Laporan Keuangan & Cetak Dokumen Resmi
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Format laporan akuntansi resmi lengkap dengan Kop Surat Sekolah dan Lembar Pengesahan Tanda Tangan.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            value={reportType}
            onChange={e => setReportType(e.target.value as any)}
            className="text-xs font-bold px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl"
          >
            <option value="rekap-sekolah">Laporan Komprehensif 4 Pilar Dana</option>
            <option value="tarian-kelas">Rekapitulasi TARIAN per Kelas (1-6)</option>
            <option value="buku-siswa">Buku Tabungan Perorangan Siswa</option>
            <option value="rekap-pinjaman-bos">Laporan Pinjaman Dana BOS</option>
          </select>

          {reportType === 'buku-siswa' && (
            <select
              value={selectedStudentId}
              onChange={e => setSelectedStudentId(e.target.value)}
              className="text-xs font-medium px-3 py-2 bg-slate-100 border border-slate-200 rounded-xl max-w-xs"
            >
              {db.students.map(s => (
                <option key={s.id} value={s.id}>
                  {s.nis} - {s.name} (Kelas {s.class})
                </option>
              ))}
            </select>
          )}

          <button
            onClick={handlePrint}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" />
            Cetak Dokumen
          </button>
        </div>
      </div>

      {/* Printable Sheet Container */}
      <div className="bg-white p-8 sm:p-12 rounded-2xl border border-slate-200 shadow-sm max-w-5xl mx-auto print:p-0 print:border-none print:shadow-none">
        {/* KOP SURAT RESMI SEKOLAH */}
        <div className="border-b-4 border-double border-slate-900 pb-4 text-center space-y-1">
          <p className="text-xs uppercase font-bold tracking-widest text-slate-600">
            PEMERINTAH KABUPATEN BREBES • DINAS PENDIDIKAN PEMUDA DAN OLAHRAGA
          </p>
          <h1 className="text-xl sm:text-2xl font-black text-slate-950 tracking-wide uppercase">
            SD NEGERI PRUWATAN 02
          </h1>
          <p className="text-xs text-slate-600">
            Alamat: Jl. Raya Pruwatan, Kec. Bumiayu, Kab. Brebes, Jawa Tengah 52273
          </p>
          <p className="text-[11px] font-medium text-slate-500">
            Sistem Informasi & Manajemen Tabungan Siswa (SIMTASIS PRADA)
          </p>
        </div>

        {/* =================================================== */}
        {/* LAPORAN 1: REKAPITULASI KOMPREHENSIF 4 PILAR DANA   */}
        {/* =================================================== */}
        {reportType === 'rekap-sekolah' && (
          <div className="mt-6 space-y-6">
            <div className="text-center">
              <h2 className="text-base font-black text-slate-900 uppercase underline tracking-wider">
                LAPORAN KEUANGAN 4 PILAR SIMPANAN SEKOLAH
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Periode Aktif: {db.settings.active_period} • Tanggal Cetak:{' '}
                {new Date().toLocaleDateString('id-ID', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                })}
              </p>
            </div>

            {/* Table 4 Pilar */}
            <table className="w-full text-xs border border-slate-300">
              <thead className="bg-slate-100 font-bold border-b border-slate-300">
                <tr>
                  <th className="p-2.5 text-left border-r border-slate-300">No.</th>
                  <th className="p-2.5 text-left border-r border-slate-300">Pilar Simpanan</th>
                  <th className="p-2.5 text-left border-r border-slate-300">Peruntukan Dana</th>
                  <th className="p-2.5 text-left border-r border-slate-300">Penanggung Jawab</th>
                  <th className="p-2.5 text-right">Saldo Kas Berjalan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-300">
                <tr>
                  <td className="p-2.5 text-center border-r border-slate-300">1</td>
                  <td className="p-2.5 font-bold border-r border-slate-300">TARIAN</td>
                  <td className="p-2.5 border-r border-slate-300">Tabungan Harian Siswa Kelas 1 - 6</td>
                  <td className="p-2.5 border-r border-slate-300">Guru Kelas & Bendahara TARIAN</td>
                  <td className="p-2.5 text-right font-mono font-bold">
                    Rp {totalTarian.toLocaleString('id-ID')}
                  </td>
                </tr>
                <tr>
                  <td className="p-2.5 text-center border-r border-slate-300">2</td>
                  <td className="p-2.5 font-bold border-r border-slate-300">SIDYASA</td>
                  <td className="p-2.5 border-r border-slate-300">Simpanan Widyawisata Siswa Terencana</td>
                  <td className="p-2.5 border-r border-slate-300">Bendahara SIDYASA</td>
                  <td className="p-2.5 text-right font-mono font-bold">
                    Rp {totalSidyasa.toLocaleString('id-ID')}
                  </td>
                </tr>
                <tr>
                  <td className="p-2.5 text-center border-r border-slate-300">3</td>
                  <td className="p-2.5 font-bold border-r border-slate-300">SIDATAN</td>
                  <td className="p-2.5 border-r border-slate-300">Simpanan Dana Kegiatan (Pramuka, PHBI, dll)</td>
                  <td className="p-2.5 border-r border-slate-300">Bendahara SIDATAN</td>
                  <td className="p-2.5 text-right font-mono font-bold">
                    Rp {totalSidatan.toLocaleString('id-ID')}
                  </td>
                </tr>
                <tr>
                  <td className="p-2.5 text-center border-r border-slate-300">4</td>
                  <td className="p-2.5 font-bold border-r border-slate-300">SIDANUM</td>
                  <td className="p-2.5 border-r border-slate-300">Simpanan Dana Umum (Multi-Buku Khusus)</td>
                  <td className="p-2.5 border-r border-slate-300">Bendahara SIDANUM</td>
                  <td className="p-2.5 text-right font-mono font-bold">
                    Rp {totalSidanum.toLocaleString('id-ID')}
                  </td>
                </tr>
              </tbody>
              <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-400">
                <tr>
                  <td colSpan={4} className="p-2.5 text-right uppercase border-r border-slate-300">
                    Akumulasi Saldo Seluruh Dana Sekolah:
                  </td>
                  <td className="p-2.5 text-right font-mono text-sm text-slate-950">
                    Rp {grandTotal.toLocaleString('id-ID')}
                  </td>
                </tr>
              </tfoot>
            </table>

            {/* Catatan Pinjaman BOS */}
            <div className="p-3 bg-slate-50 border border-slate-300 rounded text-xs space-y-1">
              <p className="font-bold">Informasi Tambahan Pinjaman Dana Talangan BOS:</p>
              <p>
                Total Sisa Pinjaman BOS Belum Kembali:{' '}
                <strong>Rp {totalLoansRemaining.toLocaleString('id-ID')}</strong> (dari{' '}
                {db.loans.filter(l => l.status !== 'LUNAS').length} transaksi pinjaman aktif).
              </p>
            </div>
          </div>
        )}

        {/* =================================================== */}
        {/* LAPORAN 2: REKAPITULASI TARIAN PER KELAS 1 - 6     */}
        {/* =================================================== */}
        {reportType === 'tarian-kelas' && (
          <div className="mt-6 space-y-6">
            <div className="text-center">
              <h2 className="text-base font-black text-slate-900 uppercase underline tracking-wider">
                REKAPITULASI TABUNGAN HARIAN (TARIAN) PER KELAS
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">Tahun Ajaran: {db.settings.active_period}</p>
            </div>

            <table className="w-full text-xs border border-slate-300">
              <thead className="bg-slate-100 font-bold border-b border-slate-300">
                <tr>
                  <th className="p-2 text-left border-r border-slate-300">Kelas</th>
                  <th className="p-2 text-center border-r border-slate-300">Siswa</th>
                  <th className="p-2 text-right border-r border-slate-300">Total Setoran</th>
                  <th className="p-2 text-right border-r border-slate-300">Total Penarikan</th>
                  <th className="p-2 text-right border-r border-slate-300">Saldo Siswa</th>
                  <th className="p-2 text-right border-r border-slate-300">Kas Dipegang Guru</th>
                  <th className="p-2 text-right">Disetor ke Bendahara</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-300">
                {[1, 2, 3, 4, 5, 6].map(c => {
                  const classStudents = db.students.filter(s => s.class === c);
                  const classTxs = db.transactions.filter(t => t.class_id === c && t.module === 'TARIAN');
                  const setoran = classTxs
                    .filter(t => t.type === 'SETORAN' && t.status === 'VALID')
                    .reduce((s, t) => s + t.amount, 0);
                  const penarikan = classTxs
                    .filter(t => t.type === 'PENARIKAN' && t.status === 'VALID')
                    .reduce((s, t) => s + t.amount, 0);
                  const saldoSiswa = setoran - penarikan;
                  const kasGuru = getTeacherCash(c);
                  const disetorBendahara = classTxs
                    .filter(t => t.type === 'SETORAN_GURU_KE_BENDAHARA' && t.status === 'VALID')
                    .reduce((s, t) => s + t.amount, 0);

                  return (
                    <tr key={c}>
                      <td className="p-2 font-bold border-r border-slate-300">Kelas {c}</td>
                      <td className="p-2 text-center border-r border-slate-300">{classStudents.length}</td>
                      <td className="p-2 text-right font-mono border-r border-slate-300">
                        Rp {setoran.toLocaleString('id-ID')}
                      </td>
                      <td className="p-2 text-right font-mono border-r border-slate-300">
                        Rp {penarikan.toLocaleString('id-ID')}
                      </td>
                      <td className="p-2 text-right font-mono font-bold border-r border-slate-300">
                        Rp {saldoSiswa.toLocaleString('id-ID')}
                      </td>
                      <td className="p-2 text-right font-mono border-r border-slate-300">
                        Rp {kasGuru.toLocaleString('id-ID')}
                      </td>
                      <td className="p-2 text-right font-mono font-bold">
                        Rp {disetorBendahara.toLocaleString('id-ID')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* =================================================== */}
        {/* LAPORAN 3: BUKU TABUNGAN PERORANGAN SISWA          */}
        {/* =================================================== */}
        {reportType === 'buku-siswa' && selectedStudent && (
          <div className="mt-6 space-y-6">
            <div className="text-center">
              <h2 className="text-base font-black text-slate-900 uppercase underline tracking-wider">
                BUKU CATATAN REKENING TABUNGAN SISWA
              </h2>
            </div>

            <div className="grid grid-cols-2 text-xs border border-slate-300 p-3 bg-slate-50 gap-2">
              <div>
                <p>
                  Nama Siswa: <strong>{selectedStudent.name}</strong>
                </p>
                <p>
                  NIS: <strong>{selectedStudent.nis}</strong>
                </p>
              </div>
              <div className="text-right">
                <p>
                  Kelas: <strong>Kelas {selectedStudent.class}</strong>
                </p>
                <p>
                  Saldo TARIAN:{' '}
                  <strong className="text-emerald-800 font-mono">
                    Rp {getStudentTarianBalance(selectedStudent.id).toLocaleString('id-ID')}
                  </strong>
                </p>
              </div>
            </div>

            <table className="w-full text-xs border border-slate-300">
              <thead className="bg-slate-100 font-bold border-b border-slate-300">
                <tr>
                  <th className="p-2 text-left border-r border-slate-300">Tanggal</th>
                  <th className="p-2 text-left border-r border-slate-300">No. Transaksi</th>
                  <th className="p-2 text-left border-r border-slate-300">Keterangan</th>
                  <th className="p-2 text-right border-r border-slate-300">Setoran (Masuk)</th>
                  <th className="p-2 text-right border-r border-slate-300">Penarikan (Keluar)</th>
                  <th className="p-2 text-center">Petugas</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-300">
                {studentTxs.map(tx => (
                  <tr key={tx.id}>
                    <td className="p-2 border-r border-slate-300">{tx.date}</td>
                    <td className="p-2 font-mono border-r border-slate-300">{tx.id}</td>
                    <td className="p-2 border-r border-slate-300">{tx.description}</td>
                    <td className="p-2 text-right font-mono border-r border-slate-300">
                      {tx.type === 'SETORAN' ? `Rp ${tx.amount.toLocaleString('id-ID')}` : '-'}
                    </td>
                    <td className="p-2 text-right font-mono border-r border-slate-300">
                      {tx.type === 'PENARIKAN' ? `Rp ${tx.amount.toLocaleString('id-ID')}` : '-'}
                    </td>
                    <td className="p-2 text-center">{tx.created_by}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* =================================================== */}
        {/* LAPORAN 4: LAPORAN PINJAMAN DANA TALANGAN BOS       */}
        {/* =================================================== */}
        {reportType === 'rekap-pinjaman-bos' && (
          <div className="mt-6 space-y-6">
            <div className="text-center">
              <h2 className="text-base font-black text-slate-900 uppercase underline tracking-wider">
                LAPORAN STATUS PINJAMAN DANA TALANGAN BOS
              </h2>
            </div>

            <table className="w-full text-xs border border-slate-300">
              <thead className="bg-slate-100 font-bold border-b border-slate-300">
                <tr>
                  <th className="p-2 text-left border-r border-slate-300">ID</th>
                  <th className="p-2 text-left border-r border-slate-300">Tgl Pinjam</th>
                  <th className="p-2 text-left border-r border-slate-300">Sumber Kas</th>
                  <th className="p-2 text-left border-r border-slate-300">Keperluan</th>
                  <th className="p-2 text-right border-r border-slate-300">Nominal Pinjaman</th>
                  <th className="p-2 text-right border-r border-slate-300">Sisa Belum Lunas</th>
                  <th className="p-2 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-300">
                {db.loans.map(l => (
                  <tr key={l.id}>
                    <td className="p-2 font-mono border-r border-slate-300">{l.id}</td>
                    <td className="p-2 border-r border-slate-300">{l.borrow_date}</td>
                    <td className="p-2 font-bold border-r border-slate-300">{l.source_module}</td>
                    <td className="p-2 border-r border-slate-300">{l.purpose}</td>
                    <td className="p-2 text-right font-mono border-r border-slate-300">
                      Rp {l.amount.toLocaleString('id-ID')}
                    </td>
                    <td className="p-2 text-right font-mono font-bold text-amber-700 border-r border-slate-300">
                      Rp {l.remaining.toLocaleString('id-ID')}
                    </td>
                    <td className="p-2 text-center font-bold">{l.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* LEMBAR PENGESAHAN TANDA TANGAN (KOP BAWAH) */}
        <div className="mt-12 pt-8 border-t border-slate-300 grid grid-cols-2 text-center text-xs">
          <div>
            <p>Mengetahui,</p>
            <p className="font-bold">Kepala Sekolah SDN Pruwatan 02</p>
            <div className="h-20" />
            <p className="font-bold underline">SUGIYANTO, S.Pd.</p>
            <p className="text-[11px] text-slate-500">NIP. 196805121992031007</p>
          </div>

          <div>
            <p>Bumiayu, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
            <p className="font-bold">Bendahara Sekolah</p>
            <div className="h-20" />
            <p className="font-bold underline">SITI NURHALIZA, S.Pd.</p>
            <p className="text-[11px] text-slate-500">NIP. 198408152009022004</p>
          </div>
        </div>
      </div>
    </div>
  );
};
