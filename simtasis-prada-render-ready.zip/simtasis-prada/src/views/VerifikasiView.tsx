import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CheckCheck, CheckCircle2, XCircle, AlertCircle, Clock } from 'lucide-react';
import { ConfirmModal } from '../components/ConfirmModal';

export const VerifikasiView: React.FC = () => {
  const { db, verifyTeacherSetoran, showToast } = useApp();
  const [rejectId, setRejectId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState<string>('');

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const pendingList = db.transactions.filter(
    t => t.module === 'TARIAN' && t.type === 'SETORAN_GURU_KE_BENDAHARA' && t.status === 'PENDING'
  );

  const historyList = db.transactions.filter(
    t => t.module === 'TARIAN' && t.type === 'SETORAN_GURU_KE_BENDAHARA' && t.status !== 'PENDING'
  );

  const handleAccept = (id: string, kelas: number | undefined, amount: number) => {
    setConfirmModal({
      isOpen: true,
      title: 'Konfirmasi Verifikasi Setoran',
      message: `Terima dan verifikasi setoran kas Kelas ${kelas} sebesar Rp ${amount.toLocaleString('id-ID')}? Saldo kas bendahara akan bertambah dan kas guru berkurang.`,
      action: async () => {
        const res = await verifyTeacherSetoran(id, 'ACCEPT');
        if (!res.success) {
          showToast(res.error || 'Gagal memverifikasi', 'error');
        }
      },
    });
  };

  const handleRejectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rejectId) return;
    if (!rejectReason.trim()) {
      showToast('Alasan penolakan wajib diisi', 'error');
      return;
    }

    const res = await verifyTeacherSetoran(rejectId, 'REJECT', rejectReason.trim());
    if (res.success) {
      setRejectId(null);
      setRejectReason('');
    } else {
      showToast(res.error || 'Gagal menolak', 'error');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
            <CheckCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Verifikasi Setoran Kas Guru ke Bendahara TARIAN
            </h2>
            <p className="text-xs text-slate-500">
              Uang yang diserahkan guru kelas diverifikasi untuk masuk ke saldo kas resmi Bendahara Sekolah.
            </p>
          </div>
        </div>
      </div>

      {/* Pending Items */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-500" />
            <h3 className="font-bold text-slate-900 text-base">
              Menunggu Verifikasi ({pendingList.length})
            </h3>
          </div>
          {pendingList.length > 0 && (
            <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
              Total: Rp{' '}
              {pendingList.reduce((s, t) => s + t.amount, 0).toLocaleString('id-ID')}
            </span>
          )}
        </div>

        {pendingList.length === 0 ? (
          <div className="p-12 text-center text-slate-400 text-xs">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2 opacity-80" />
            <p className="font-medium text-slate-600">Semua setoran telah diverifikasi!</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Tidak ada pengajuan setoran yang pending saat ini.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {pendingList.map(item => (
              <div
                key={item.id}
                className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-50 transition"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black px-2.5 py-0.5 rounded-md bg-blue-100 text-blue-800">
                      Kelas {item.class_id}
                    </span>
                    <span className="font-mono text-xs font-bold text-slate-800">{item.id}</span>
                    <span className="text-xs text-slate-500">• Oleh: {item.created_by}</span>
                  </div>
                  <p className="text-sm font-black font-mono text-slate-900 pt-1">
                    Rp {item.amount.toLocaleString('id-ID')}
                  </p>
                  <p className="text-xs text-slate-500">
                    Tanggal: {item.date} {item.time} • {item.description}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setRejectId(item.id);
                      setRejectReason('');
                    }}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 transition flex items-center gap-1.5"
                  >
                    <XCircle className="w-4 h-4" />
                    Tolak
                  </button>
                  <button
                    type="button"
                    onClick={() => handleAccept(item.id, item.class_id, item.amount)}
                    className="px-5 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs transition flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    Terima & Verifikasi
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* History Verification */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100">
          <h3 className="font-bold text-slate-900 text-base">Histori Setoran yang Telah Diproses</h3>
          <p className="text-xs text-slate-500">Catatan setoran guru yang telah diverifikasi atau ditolak</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">ID Transaksi</th>
                <th className="px-4 py-3">Tanggal</th>
                <th className="px-4 py-3">Kelas / Guru</th>
                <th className="px-4 py-3 text-right">Nominal</th>
                <th className="px-4 py-3">Diverifikasi Oleh</th>
                <th className="px-4 py-3 text-center">Status</th>
                <th className="px-4 py-3">Keterangan / Alasan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {historyList.map(tx => (
                <tr key={tx.id} className="hover:bg-slate-50 transition">
                  <td className="px-4 py-3 font-mono font-semibold text-slate-900">{tx.id}</td>
                  <td className="px-4 py-3 text-slate-600">{tx.date}</td>
                  <td className="px-4 py-3 font-medium text-slate-800">
                    Kelas {tx.class_id} ({tx.created_by})
                  </td>
                  <td className="px-4 py-3 text-right font-mono font-bold text-emerald-700">
                    Rp {tx.amount.toLocaleString('id-ID')}
                  </td>
                  <td className="px-4 py-3 text-slate-600">{tx.verified_by || '-'}</td>
                  <td className="px-4 py-3 text-center">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        tx.status === 'VALID'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {tx.status === 'VALID' ? 'TERVERIFIKASI' : 'DITOLAK'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-slate-500 text-[11px]">
                    {tx.rejection_reason ? `Alasan: ${tx.rejection_reason}` : tx.description}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Rejection Reason */}
      {rejectId && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-600" />
              Tolak Setoran Kas Guru
            </h3>
            <p className="text-xs text-slate-500">
              Masukkan alasan penolakan setoran. Guru kelas akan dapat melihat alasan penolakan dan saldo fisik kas tetap berada di tangan guru.
            </p>

            <form onSubmit={handleRejectSubmit} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Alasan Penolakan (Wajib)
                </label>
                <textarea
                  rows={3}
                  value={rejectReason}
                  onChange={e => setRejectReason(e.target.value)}
                  placeholder="Contoh: Jumlah uang fisik yang diserahkan kurang Rp50.000 dari amplop."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-rose-500 focus:outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRejectId(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Tolak Setoran
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        onConfirm={confirmModal.action}
        onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
