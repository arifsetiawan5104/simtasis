import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { Student, Transaction } from '../types';
import { ConfirmModal } from '../components/ConfirmModal';
import {
  Coins,
  ArrowDownRight,
  ArrowUpRight,
  Send,
  UserPlus,
  Edit2,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  History,
  Wallet,
  RotateCcw,
  ChevronLeft,
  ChevronRight,
  SkipForward,
  Check,
  Lock,
  Users,
  ShieldCheck,
} from 'lucide-react';

export const TarianView: React.FC = () => {
  const {
    session,
    db,
    addStudent,
    editStudent,
    addTransaction,
    correctTransaction,
    getStudentTarianBalance,
    getTeacherCash,
    showToast,
  } = useApp();

  if (!session) return null;

  const userRole = session.role;
  const isTeacher = userRole.startsWith('guru');
  const isAdmin = userRole === 'admin';
  const canInputTransaction = isTeacher || isAdmin;
  const teacherClass = session.classAccess;

  // Selected Class filter (if admin or bendahara, can pick class 1-6 or All)
  const [selectedClassFilter, setSelectedClassFilter] = useState<number | 'ALL'>(
    isTeacher ? teacherClass || 1 : 1
  );

  // Active tab inside TARIAN: 'transaksi' | 'siswa' | 'setor-bendahara' | 'riwayat'
  const [subTab, setSubTab] = useState<'transaksi' | 'siswa' | 'setor-bendahara' | 'riwayat'>('transaksi');

  // Transaction Form State
  const [txType, setTxType] = useState<'SETORAN' | 'PENARIKAN'>('SETORAN');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [amount, setAmount] = useState<number | ''>('');
  const [txDate, setTxDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState<string>('');
  const [searchStudent, setSearchStudent] = useState<string>('');

  // Add Student Form State
  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [newNis, setNewNis] = useState('');
  const [newName, setNewName] = useState('');
  const [newClass, setNewClass] = useState<number>(isTeacher ? teacherClass || 1 : 1);

  // Edit Student Form State
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [editName, setEditName] = useState('');
  const [editStatus, setEditStatus] = useState<string>('AKTIF');

  // Setoran Guru ke Bendahara Form State
  const [guruSetorAmount, setGuruSetorAmount] = useState<number | ''>('');
  const [guruSetorDesc, setGuruSetorDesc] = useState('Setoran uang kas tabungan siswa ke bendahara');

  // Correction Form State
  const [correctingTx, setCorrectingTx] = useState<Transaction | null>(null);
  const [corrAmount, setCorrAmount] = useState<number | ''>('');
  const [corrDesc, setCorrDesc] = useState('');
  const [corrReason, setCorrReason] = useState('');

  // Confirmation Modal State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
    variant?: 'danger' | 'warning' | 'primary';
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  // Filter students based on role & class filter
  const visibleStudents = useMemo(() => {
    return db.students.filter(s => {
      if (isTeacher && s.class !== teacherClass) return false;
      if (!isTeacher && selectedClassFilter !== 'ALL' && s.class !== selectedClassFilter) return false;
      if (searchStudent) {
        const q = searchStudent.toLowerCase();
        return s.name.toLowerCase().includes(q) || s.nis.toLowerCase().includes(q);
      }
      return true;
    });
  }, [db.students, isTeacher, teacherClass, selectedClassFilter, searchStudent]);

  // Active students for quick selection (ordered by NIS)
  const activeClassStudents = useMemo(() => {
    return visibleStudents
      .filter(s => s.status === 'AKTIF')
      .sort((a, b) => a.nis.localeCompare(b.nis, undefined, { numeric: true }));
  }, [visibleStudents]);

  // Automatically select first active student in class if none is selected
  useEffect(() => {
    if (activeClassStudents.length > 0) {
      const exists = activeClassStudents.some(s => s.id === selectedStudentId);
      if (!exists && !selectedStudentId) {
        setSelectedStudentId(activeClassStudents[0].id);
      }
    }
  }, [activeClassStudents, selectedStudentId]);

  // Selected Student Index among active students of this class
  const currentStudentIndex = useMemo(() => {
    return activeClassStudents.findIndex(s => s.id === selectedStudentId);
  }, [activeClassStudents, selectedStudentId]);

  // Fast Navigation: Previous Student Button
  const handlePrevStudent = () => {
    if (activeClassStudents.length === 0) return;
    const prevIdx = currentStudentIndex <= 0 ? activeClassStudents.length - 1 : currentStudentIndex - 1;
    setSelectedStudentId(activeClassStudents[prevIdx].id);
  };

  // Fast Navigation: Next Student Button
  const handleNextStudent = () => {
    if (activeClassStudents.length === 0) return;
    const nextIdx = currentStudentIndex >= activeClassStudents.length - 1 ? 0 : currentStudentIndex + 1;
    setSelectedStudentId(activeClassStudents[nextIdx].id);
  };

  // Selected Student Object & Current Balance
  const selectedStudent = useMemo(() => {
    return db.students.find(s => s.id === selectedStudentId);
  }, [db.students, selectedStudentId]);

  const studentBalance = selectedStudent ? getStudentTarianBalance(selectedStudent.id) : 0;

  // Estimated After Balance
  const estimatedAfterBalance = useMemo(() => {
    const num = Number(amount) || 0;
    if (txType === 'SETORAN') return studentBalance + num;
    return studentBalance - num;
  }, [studentBalance, amount, txType]);

  // Teacher Cash
  const currentTeacherClass = isTeacher ? teacherClass || 1 : Number(selectedClassFilter) || 1;
  const currentTeacherCash = getTeacherCash(currentTeacherClass);

  // Handle Quick Nominal Click
  const handleQuickNominal = (val: number) => {
    setAmount(val);
  };

  // Submit Transaction (supports andAdvanceNext for teacher speed)
  const handleSaveTransaction = (e?: React.FormEvent, andAdvanceNext: boolean = false) => {
    if (e) e.preventDefault();

    if (!canInputTransaction) {
      showToast(
        'Akses Ditolak: Input transaksi/setoran tabungan harian hanya bisa dilakukan oleh guru kelas atau Administrator.',
        'error'
      );
      return;
    }

    if (!selectedStudent) {
      showToast('Pilih siswa terlebih dahulu', 'error');
      return;
    }

    const numAmount = Number(amount);
    if (!numAmount || numAmount <= 0) {
      showToast('Nominal transaksi harus lebih dari 0', 'error');
      return;
    }

    if (txType === 'PENARIKAN' && numAmount > studentBalance) {
      showToast(
        `Saldo siswa tidak mencukupi. Saldo saat ini: Rp ${studentBalance.toLocaleString('id-ID')}`,
        'error'
      );
      return;
    }

    const confirmTitle = txType === 'SETORAN' ? 'Konfirmasi Setoran Tabungan' : 'Konfirmasi Penarikan Tabungan';
    const confirmMsg = `Anda akan mencatat ${txType.toLowerCase()} sebesar Rp ${numAmount.toLocaleString('id-ID')} untuk siswa ${selectedStudent.name} (NIS: ${selectedStudent.nis}). Lanjutkan?`;

    setConfirmModal({
      isOpen: true,
      title: confirmTitle,
      message: confirmMsg,
      variant: txType === 'PENARIKAN' ? 'warning' : 'primary',
      action: async () => {
        const res = await addTransaction({
          module: 'TARIAN',
          type: txType,
          student_id: selectedStudent.id,
          class_id: selectedStudent.class,
          amount: numAmount,
          date: txDate,
          description: description || (txType === 'SETORAN' ? 'Setoran tabungan harian' : 'Penarikan tabungan harian'),
        });
        if (res.success) {
          setAmount('');
          setDescription('');
          if (andAdvanceNext && activeClassStudents.length > 1) {
            const nextIdx = (currentStudentIndex + 1) % activeClassStudents.length;
            setSelectedStudentId(activeClassStudents[nextIdx].id);
            showToast(
              `Setoran ${selectedStudent.name} berhasil disimpan! Beralih ke: ${activeClassStudents[nextIdx].name}`,
              'success'
            );
          } else {
            showToast(`Transaksi ${txType === 'SETORAN' ? 'setoran' : 'penarikan'} berhasil disimpan!`, 'success');
          }
        } else {
          showToast(res.error || 'Gagal mencatat transaksi', 'error');
        }
      },
    });
  };

  // Submit Add Student
  const handleSaveStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNis.trim() || !newName.trim()) {
      showToast('NIS dan Nama siswa wajib diisi', 'error');
      return;
    }
    const res = await addStudent(newNis.trim(), newName.trim(), newClass);
    if (res.success) {
      setIsAddStudentOpen(false);
      setNewNis('');
      setNewName('');
    } else {
      showToast(res.error || 'Gagal menambahkan siswa', 'error');
    }
  };

  // Submit Edit Student
  const handleSaveEditStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudent) return;
    const res = await editStudent(editingStudent.id, editName, editStatus);
    if (res.success) {
      setEditingStudent(null);
    } else {
      showToast(res.error || 'Gagal memperbarui siswa', 'error');
    }
  };

  // Submit Setoran Guru ke Bendahara
  const handleSaveGuruSetoran = (e: React.FormEvent) => {
    e.preventDefault();
    const num = Number(guruSetorAmount);
    if (!num || num <= 0) {
      showToast('Nominal setoran harus lebih dari 0', 'error');
      return;
    }
    if (num > currentTeacherCash) {
      showToast(
        `Nominal melebihi kas yang Anda pegang (Rp ${currentTeacherCash.toLocaleString('id-ID')})`,
        'error'
      );
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: 'Konfirmasi Setoran ke Bendahara',
      message: `Anda akan mengajukan setoran kas sebesar Rp ${num.toLocaleString('id-ID')} kepada Bendahara TARIAN. Setelah diajukan, status menunggu verifikasi. Lanjutkan?`,
      variant: 'primary',
      action: async () => {
        const res = await addTransaction({
          module: 'TARIAN',
          type: 'SETORAN_GURU_KE_BENDAHARA',
          class_id: currentTeacherClass,
          amount: num,
          date: new Date().toISOString().split('T')[0],
          description: guruSetorDesc || 'Setoran kas tabungan guru ke bendahara',
        });
        if (res.success) {
          setGuruSetorAmount('');
        }
      },
    });
  };

  // Submit Transaction Correction
  const handleSaveCorrection = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!correctingTx) return;
    if (!corrReason.trim()) {
      showToast('Alasan koreksi wajib diisi untuk audit trail', 'error');
      return;
    }
    const num = Number(corrAmount);
    if (!num || num <= 0) {
      showToast('Nominal baru harus lebih dari 0', 'error');
      return;
    }

    const res = await correctTransaction(correctingTx.id, num, corrDesc, corrReason.trim());
    if (res.success) {
      setCorrectingTx(null);
      setCorrReason('');
      setCorrAmount('');
      setCorrDesc('');
    } else {
      showToast(res.error || 'Gagal mengoreksi transaksi', 'error');
    }
  };

  // Class Transactions
  const tarianTxs = useMemo(() => {
    return db.transactions
      .filter(t => t.module === 'TARIAN')
      .filter(t => {
        if (isTeacher && t.class_id !== teacherClass) return false;
        if (!isTeacher && selectedClassFilter !== 'ALL' && t.class_id !== selectedClassFilter) return false;
        return true;
      });
  }, [db.transactions, isTeacher, teacherClass, selectedClassFilter]);

  return (
    <div className="space-y-6">
      {/* Top Header & Navigation Tabs */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <Coins className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              TARIAN — Tabungan Harian Siswa
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            {isTeacher
              ? `Pengelolaan kelas Anda: Kelas ${teacherClass}`
              : 'Pengelolaan tabungan harian seluruh siswa SDN Pruwatan 02'}
          </p>
        </div>

        {/* Sub Navigation Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {!isTeacher && (
            <div className="flex items-center gap-1.5 mr-2">
              <span className="text-xs text-slate-500 font-medium">Filter Kelas:</span>
              <select
                value={selectedClassFilter}
                onChange={e => setSelectedClassFilter(e.target.value === 'ALL' ? 'ALL' : Number(e.target.value))}
                className="text-xs font-semibold px-2.5 py-1.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-700"
              >
                <option value="ALL">Semua Kelas</option>
                {[1, 2, 3, 4, 5, 6].map(c => (
                  <option key={c} value={c}>
                    Kelas {c}
                  </option>
                ))}
              </select>
            </div>
          )}

          <button
            onClick={() => setSubTab('transaksi')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              subTab === 'transaksi'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Input Transaksi
          </button>
          <button
            onClick={() => setSubTab('siswa')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              subTab === 'siswa'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Data Siswa ({visibleStudents.length})
          </button>
          <button
            onClick={() => setSubTab('setor-bendahara')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              subTab === 'setor-bendahara'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Setor ke Bendahara
          </button>
          <button
            onClick={() => setSubTab('riwayat')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              subTab === 'riwayat'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Riwayat Transaksi
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SUB-TAB 1: INPUT TRANSAKSI CEPAT (Requirement H, I, AI, AJ) */}
      {/* ========================================================= */}
      {subTab === 'transaksi' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Form Transaksi */}
          <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-slate-900 text-base">Pencatatan Transaksi Siswa</h3>
                <p className="text-xs text-slate-500">Pilih siswa, klik nominal cepat, lalu simpan.</p>
              </div>

              {/* Toggle SETORAN vs PENARIKAN */}
              <div className="flex rounded-xl p-1 bg-slate-100 border border-slate-200">
                <button
                  type="button"
                  onClick={() => setTxType('SETORAN')}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
                    txType === 'SETORAN'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ArrowDownRight className="w-4 h-4" />
                  Setoran
                </button>
                <button
                  type="button"
                  onClick={() => setTxType('PENARIKAN')}
                  className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition ${
                    txType === 'PENARIKAN'
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ArrowUpRight className="w-4 h-4" />
                  Penarikan
                </button>
              </div>
            </div>

            {!canInputTransaction ? (
              <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 space-y-3">
                <div className="flex items-center gap-2.5 font-bold text-amber-800 text-sm">
                  <Lock className="w-5 h-5 text-amber-600" />
                  <span>Hak Akses Input Transaksi Dibatasi</span>
                </div>
                <p className="text-xs text-amber-800 leading-relaxed">
                  Input transaksi/setoran tabungan harian hanya bisa dilakukan oleh <strong>Guru Kelas</strong> yang bersangkutan atau <strong>Administrator</strong>.
                </p>
                <p className="text-[11px] text-amber-700">
                  Peran Anda saat ini (<strong>{userRole}</strong>) hanya memiliki hak akses untuk melihat data siswa dan riwayat transaksi pada tab di atas.
                </p>
              </div>
            ) : (
              <form onSubmit={e => handleSaveTransaction(e, false)} className="space-y-4">
                {/* Admin Multi-Class Selector */}
                {isAdmin && (
                  <div className="p-3 bg-indigo-50 border border-indigo-200/80 rounded-xl flex flex-wrap items-center justify-between gap-2.5">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                        <ShieldCheck className="w-4 h-4 text-indigo-600" />
                        Pilih Kelas Transaksi:
                      </span>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5, 6].map(c => (
                          <button
                            key={c}
                            type="button"
                            onClick={() => {
                              setSelectedClassFilter(c);
                              setSelectedStudentId('');
                            }}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                              selectedClassFilter === c
                                ? 'bg-indigo-600 text-white shadow-xs'
                                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                            }`}
                          >
                            Kelas {c}
                          </button>
                        ))}
                      </div>
                    </div>
                    <span className="text-[11px] font-bold text-indigo-700 bg-white/80 px-2 py-0.5 rounded-md border border-indigo-200">
                      Mode Admin (Bebas Input Semua Kelas)
                    </span>
                  </div>
                )}

                {/* 1. Navigasi Cepat Siswa (Requirement User: Tombol Navigasi Siswa 1 ke Siswa Lainnya) */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      1. Navigasi Siswa (Kelas {currentTeacherClass})
                    </label>
                    <span className="text-[11px] font-semibold text-slate-500">
                      Total {activeClassStudents.length} Siswa Aktif
                    </span>
                  </div>

                  {/* Tombol Navigasi Sebelumnya & Berikutnya */}
                  <div className="flex items-center justify-between gap-2 p-2 bg-slate-50 border border-slate-200 rounded-xl">
                    <button
                      type="button"
                      id="btn-prev-student"
                      onClick={handlePrevStudent}
                      disabled={activeClassStudents.length <= 1}
                      className="px-3 py-2 bg-white hover:bg-slate-100 disabled:opacity-40 text-slate-700 rounded-lg text-xs font-bold border border-slate-200/80 shadow-2xs flex items-center gap-1.5 transition"
                      title="Pindah ke Siswa Sebelumnya (Siswa - 1)"
                    >
                      <ChevronLeft className="w-4 h-4 text-slate-600" />
                      <span>Siswa Sebelumnya</span>
                    </button>

                    <div className="text-center px-2 min-w-0">
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                        {currentStudentIndex >= 0 ? `Siswa ${currentStudentIndex + 1} dari ${activeClassStudents.length}` : 'Pilih Siswa'}
                      </p>
                      <p className="text-xs font-bold text-slate-900 truncate">
                        {selectedStudent ? selectedStudent.name : '-- Belum Dipilih --'}
                      </p>
                    </div>

                    <button
                      type="button"
                      id="btn-next-student"
                      onClick={handleNextStudent}
                      disabled={activeClassStudents.length <= 1}
                      className="px-3 py-2 bg-white hover:bg-slate-100 disabled:opacity-40 text-slate-700 rounded-lg text-xs font-bold border border-slate-200/80 shadow-2xs flex items-center gap-1.5 transition"
                      title="Pindah ke Siswa Berikutnya (Siswa + 1)"
                    >
                      <span>Siswa Berikutnya</span>
                      <ChevronRight className="w-4 h-4 text-slate-600" />
                    </button>
                  </div>

                  {/* Bilah Tombol / Chip Siswa Cepat (Quick Student Carousel / Strip) */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
                      <span>Pilih Cepat Siswa (Klik nomor/nama):</span>
                      <span className="text-[10px] text-slate-400">Gulir mendatar →</span>
                    </div>
                    <div className="flex items-center gap-1.5 overflow-x-auto pb-2 pt-0.5 scrollbar-thin">
                      {activeClassStudents.map((s, idx) => {
                        const isSel = s.id === selectedStudentId;
                        return (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() => {
                              setSelectedStudentId(s.id);
                              setAmount('');
                            }}
                            className={`shrink-0 px-3 py-1.5 rounded-xl text-xs transition flex items-center gap-1.5 border ${
                              isSel
                                ? 'bg-emerald-600 border-emerald-600 text-white font-bold shadow-xs ring-2 ring-emerald-400/40'
                                : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300 hover:bg-slate-50 font-medium'
                            }`}
                          >
                            <span
                              className={`w-4 h-4 rounded-full text-[10px] flex items-center justify-center font-mono font-bold ${
                                isSel ? 'bg-white/25 text-white' : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {idx + 1}
                            </span>
                            <span className="truncate max-w-[100px]">{s.name.split(' ')[0]}</span>
                            {isSel && <Check className="w-3 h-3 text-white shrink-0" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Dropdown Siswa Lengkap (Alternatif) */}
                  <select
                    value={selectedStudentId}
                    onChange={e => setSelectedStudentId(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  >
                    <option value="">-- Atau Pilih Dari Dropdown Siswa Kelas {teacherClass} --</option>
                    {activeClassStudents.map((s, idx) => {
                      const bal = getStudentTarianBalance(s.id);
                      return (
                        <option key={s.id} value={s.id}>
                          {idx + 1}. {s.nis} - {s.name} (Saldo: Rp {bal.toLocaleString('id-ID')})
                        </option>
                      );
                    })}
                  </select>
                </div>

              {/* Student Info Box (Requirement AJ) */}
              {selectedStudent && (
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2 text-xs">
                  <div className="flex justify-between items-center text-slate-600">
                    <span>Nama Siswa:</span>
                    <span className="font-bold text-slate-900 text-sm">{selectedStudent.name}</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-600">
                    <span>NIS / Kelas:</span>
                    <span className="font-mono text-slate-800">
                      {selectedStudent.nis} • Kelas {selectedStudent.class}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-slate-600 pt-1 border-t border-slate-200">
                    <span>Saldo Saat Ini:</span>
                    <span className="font-mono font-bold text-base text-emerald-700">
                      Rp {studentBalance.toLocaleString('id-ID')}
                    </span>
                  </div>

                  {amount && Number(amount) > 0 ? (
                    <div className="flex justify-between items-center text-slate-700 pt-1 border-t border-dashed border-slate-200">
                      <span>Estimasi Saldo Sesudah:</span>
                      <span
                        className={`font-mono font-bold text-sm ${
                          estimatedAfterBalance < 0 ? 'text-rose-600' : 'text-slate-900'
                        }`}
                      >
                        Rp {estimatedAfterBalance.toLocaleString('id-ID')}
                        {estimatedAfterBalance < 0 && ' (TIDAK CUKUP!)'}
                      </span>
                    </div>
                  ) : null}
                </div>
              )}

              {/* 2. Nominal Cepat (Requirement H) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                  2. Pilih Nominal Cepat (Klik)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[5000, 10000, 15000, 20000].map(val => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => handleQuickNominal(val)}
                      className={`py-2.5 px-3 rounded-xl border text-xs font-bold font-mono transition ${
                        amount === val
                          ? 'bg-emerald-600 border-emerald-600 text-white shadow-xs'
                          : 'bg-white border-slate-200 text-slate-800 hover:border-emerald-400 hover:bg-emerald-50/50'
                      }`}
                    >
                      Rp {val.toLocaleString('id-ID')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Nominal Lainnya Manual */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Atau Masukkan Nominal Lainnya (Rp)
                </label>
                <input
                  type="number"
                  min="1000"
                  step="500"
                  value={amount}
                  onChange={e => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Contoh: 25000"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              {/* Tanggal & Keterangan */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Tanggal Transaksi
                  </label>
                  <input
                    type="date"
                    value={txDate}
                    onChange={e => setTxDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Keterangan (Opsional)
                  </label>
                  <input
                    type="text"
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    placeholder={txType === 'SETORAN' ? 'Setoran tabungan' : 'Keperluan jajan/buku'}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-2 space-y-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    id="save-and-next-btn"
                    onClick={() => handleSaveTransaction(undefined, true)}
                    className="py-3 px-4 rounded-xl text-xs sm:text-sm font-bold bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs transition flex items-center justify-center gap-1.5"
                    title="Simpan setoran siswa ini dan langsung beralih ke siswa berikutnya"
                  >
                    <SkipForward className="w-4 h-4" />
                    <span>Simpan & Lanjut Siswa Berikutnya</span>
                  </button>

                  <button
                    type="submit"
                    id="save-transaction-btn"
                    className={`py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-white shadow-xs transition flex items-center justify-center gap-1.5 ${
                      txType === 'SETORAN'
                        ? 'bg-emerald-600 hover:bg-emerald-700'
                        : 'bg-rose-600 hover:bg-rose-700'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Simpan Transaksi Ini</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 text-center">
                  💡 Gunakan tombol <strong>"Simpan & Lanjut Siswa Berikutnya"</strong> agar tidak ribet memilih siswa berulang kali.
                </p>
              </div>
            </form>
          )}
        </div>

          {/* Right Column: Mini Info & Summary */}
          <div className="lg:col-span-5 space-y-4">
            {/* Kas Guru Widget */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white p-5 rounded-2xl shadow-sm">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-400">
                Kas di Tangan Guru Kelas {currentTeacherClass}
              </span>
              <p className="text-3xl font-black font-mono mt-1 text-white">
                Rp {currentTeacherCash.toLocaleString('id-ID')}
              </p>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Uang fisik hasil setoran siswa yang belum disetorkan ke Bendahara TARIAN.
              </p>
              <button
                type="button"
                onClick={() => setSubTab('setor-bendahara')}
                className="mt-4 w-full py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                Setor ke Bendahara Sekarang
              </button>
            </div>

            {/* Quick Validation Rules Reminder */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs space-y-2 text-xs text-slate-600">
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                Prinsip Keamanan Finansial TARIAN
              </h4>
              <ul className="space-y-1.5 pl-4 list-disc text-slate-600 leading-relaxed">
                <li>
                  <strong>Validasi Saldo:</strong> Penarikan siswa tidak boleh melebihi saldo tabungan. Saldo negatif dicegah oleh sistem.
                </li>
                <li>
                  <strong>Struk Otomatis:</strong> Setelah transaksi disimpan, struk bukti transaksi resmi dapat langsung dicetak.
                </li>
                <li>
                  <strong>Audit Koreksi:</strong> Jika terjadi salah input, gunakan fitur koreksi untuk mencatat riwayat perubahan.
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-TAB 2: DATA SISWA (Requirement D & W - NO DELETE BUTTON!) */}
      {/* ========================================================= */}
      {subTab === 'siswa' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Database Siswa</h3>
              <p className="text-xs text-slate-500">
                Siswa tidak boleh dihapus demi keutuhan histori tabungan. Ubah status jika siswa pindah/lulus.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Cari nama / NIS..."
                  value={searchStudent}
                  onChange={e => setSearchStudent(e.target.value)}
                  className="pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <button
                type="button"
                onClick={() => setIsAddStudentOpen(true)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center gap-1.5 shrink-0"
              >
                <UserPlus className="w-4 h-4" />
                Tambah Siswa
              </button>
            </div>
          </div>

          {/* Table Students */}
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">NIS</th>
                  <th className="px-4 py-3">Nama Siswa</th>
                  <th className="px-4 py-3 text-center">Kelas</th>
                  <th className="px-4 py-3 text-right">Saldo TARIAN</th>
                  <th className="px-4 py-3 text-right">Saldo SIDYASA</th>
                  <th className="px-4 py-3 text-center">Status</th>
                  <th className="px-4 py-3 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {visibleStudents.map(s => {
                  const tarianBal = getStudentTarianBalance(s.id);
                  const sidyasaBal = useApp().getStudentSidyasaBalance(s.id);

                  return (
                    <tr key={s.id} className="hover:bg-slate-50/70 transition">
                      <td className="px-4 py-3 font-mono font-bold text-slate-900">{s.nis}</td>
                      <td className="px-4 py-3 font-medium text-slate-800">{s.name}</td>
                      <td className="px-4 py-3 text-center text-slate-600">Kelas {s.class}</td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-emerald-700">
                        Rp {tarianBal.toLocaleString('id-ID')}
                      </td>
                      <td className="px-4 py-3 text-right font-mono text-cyan-700">
                        Rp {sidyasaBal.toLocaleString('id-ID')}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            s.status === 'AKTIF'
                              ? 'bg-emerald-100 text-emerald-800'
                              : s.status === 'PINDAH'
                              ? 'bg-amber-100 text-amber-800'
                              : s.status === 'LULUS'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {s.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingStudent(s);
                            setEditName(s.name);
                            setEditStatus(s.status);
                          }}
                          className="px-2 py-1 text-slate-600 hover:text-emerald-700 hover:bg-slate-100 rounded text-xs inline-flex items-center gap-1 font-medium transition"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          Edit
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-TAB 3: SETORAN GURU KE BENDAHARA (Requirement K) */}
      {/* ========================================================= */}
      {subTab === 'setor-bendahara' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-5">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Setor Uang Kas ke Bendahara TARIAN</h3>
              <p className="text-xs text-slate-500">
                Penyetoran kas tabungan dari guru kelas kepada bendahara sekolah.
              </p>
            </div>

            {isAdmin && (
              <div className="p-3 bg-indigo-50 border border-indigo-200/80 rounded-xl flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-indigo-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  Pilih Kas Guru Kelas:
                </span>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5, 6].map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setSelectedClassFilter(c)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                        selectedClassFilter === c
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                      }`}
                    >
                      Kelas {c}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Saldo kas yang masih dipegang guru (Requirement K) */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-xs text-slate-500 font-medium">
                Saldo kas di tangan {isAdmin ? `Guru Kelas ${currentTeacherClass}` : 'Anda saat ini'}:
              </span>
              <p className="text-2xl font-black text-emerald-700 font-mono">
                Rp {currentTeacherCash.toLocaleString('id-ID')}
              </p>
              <p className="text-[11px] text-slate-400">
                Maksimal nominal yang dapat disetorkan adalah sebesar saldo kas kelas ini.
              </p>
            </div>

            <form onSubmit={handleSaveGuruSetoran} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Nominal Setoran (Rp)
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    max={currentTeacherCash}
                    value={guruSetorAmount}
                    onChange={e => setGuruSetorAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    placeholder="Contoh: 350000"
                    className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setGuruSetorAmount(currentTeacherCash)}
                    className="px-3 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl transition"
                  >
                    Setor Semua
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Catatan / Keterangan
                </label>
                <input
                  type="text"
                  value={guruSetorDesc}
                  onChange={e => setGuruSetorDesc(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={currentTeacherCash <= 0}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-sm rounded-xl transition shadow-xs flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                Ajukan Setoran ke Bendahara
              </button>
            </form>
          </div>

          <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <h4 className="font-bold text-slate-900 text-sm">Riwayat Pengajuan Setoran ke Bendahara</h4>
            <div className="divide-y divide-slate-100 overflow-y-auto max-h-96">
              {tarianTxs
                .filter(t => t.type === 'SETORAN_GURU_KE_BENDAHARA')
                .map(t => (
                  <div key={t.id} className="py-3 flex items-center justify-between text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900">Kelas {t.class_id}</span>
                        <span className="font-mono text-slate-400">({t.id})</span>
                      </div>
                      <p className="text-[11px] text-slate-500">{t.date} • {t.description}</p>
                      {t.rejection_reason && (
                        <p className="text-[11px] text-rose-600 font-medium">Alasan ditolak: {t.rejection_reason}</p>
                      )}
                    </div>
                    <div className="text-right">
                      <p className="font-mono font-bold text-emerald-700">Rp {t.amount.toLocaleString('id-ID')}</p>
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          t.status === 'VALID'
                            ? 'bg-emerald-100 text-emerald-800'
                            : t.status === 'PENDING'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {t.status === 'VALID' ? 'TERVERIFIKASI' : t.status === 'PENDING' ? 'MENUNGGU VERIFIKASI' : t.status}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-TAB 4: RIWAYAT TRANSAKSI & KOREKSI (Requirement L) */}
      {/* ========================================================= */}
      {subTab === 'riwayat' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Riwayat Transaksi Lengkap TARIAN</h3>
              <p className="text-xs text-slate-500">
                Seluruh catatan tersimpan permanen. Kesalahan input dapat dikoreksi melalui tombol Koreksi.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-3.5 py-3">ID Transaksi</th>
                  <th className="px-3.5 py-3">Tanggal & Waktu</th>
                  <th className="px-3.5 py-3">Siswa / Jenis</th>
                  <th className="px-3.5 py-3 text-right">Nominal</th>
                  <th className="px-3.5 py-3">Petugas</th>
                  <th className="px-3.5 py-3 text-center">Status</th>
                  <th className="px-3.5 py-3 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {tarianTxs.map(tx => (
                  <tr key={tx.id} className="hover:bg-slate-50 transition">
                    <td className="px-3.5 py-3 font-mono font-semibold text-slate-900">{tx.id}</td>
                    <td className="px-3.5 py-3 text-slate-600 whitespace-nowrap">
                      {tx.date} <span className="text-slate-400">{tx.time}</span>
                    </td>
                    <td className="px-3.5 py-3">
                      <div className="font-bold text-slate-800">
                        {tx.student_name ? `${tx.student_name} (${tx.student_nis})` : tx.type}
                      </div>
                      <div className="text-[11px] text-slate-500">{tx.description}</div>
                    </td>
                    <td className="px-3.5 py-3 text-right font-mono font-bold">
                      <span
                        className={
                          tx.type === 'PENARIKAN' ? 'text-rose-600' : 'text-emerald-700'
                        }
                      >
                        {tx.type === 'PENARIKAN' ? '-' : '+'}Rp {tx.amount.toLocaleString('id-ID')}
                      </span>
                    </td>
                    <td className="px-3.5 py-3 text-slate-600">{tx.created_by}</td>
                    <td className="px-3.5 py-3 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          tx.status === 'VALID'
                            ? 'bg-emerald-100 text-emerald-800'
                            : tx.status === 'PENDING'
                            ? 'bg-amber-100 text-amber-800'
                            : tx.status === 'DIPERBAIKI'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {tx.status}
                      </span>
                    </td>
                    <td className="px-3.5 py-3 text-center">
                      {tx.status === 'VALID' && (userRole === 'admin' || isTeacher) && (
                        <button
                          type="button"
                          onClick={() => {
                            setCorrectingTx(tx);
                            setCorrAmount(tx.amount);
                            setCorrDesc(tx.description);
                          }}
                          className="px-2 py-1 text-slate-600 hover:text-amber-800 hover:bg-amber-50 rounded text-xs inline-flex items-center gap-1 font-medium transition"
                        >
                          <RotateCcw className="w-3 h-3" />
                          Koreksi
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Add Student */}
      {isAddStudentOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-slate-900 text-base">Tambah Siswa Baru</h3>
            <form onSubmit={handleSaveStudent} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  NIS (Nomor Induk Siswa - Harus Unik)
                </label>
                <input
                  type="text"
                  value={newNis}
                  onChange={e => setNewNis(e.target.value)}
                  placeholder="Contoh: 240104"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nama Lengkap Siswa
                </label>
                <input
                  type="text"
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  placeholder="Nama siswa..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              {!isTeacher && (
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Kelas
                  </label>
                  <select
                    value={newClass}
                    onChange={e => setNewClass(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  >
                    {[1, 2, 3, 4, 5, 6].map(c => (
                      <option key={c} value={c}>
                        Kelas {c}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddStudentOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Simpan Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Edit Student */}
      {editingStudent && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-slate-900 text-base">
              Edit Data Siswa (NIS: {editingStudent.nis})
            </h3>
            <form onSubmit={handleSaveEditStudent} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nama Siswa
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Status Siswa
                </label>
                <select
                  value={editStatus}
                  onChange={e => setEditStatus(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="AKTIF">AKTIF</option>
                  <option value="PINDAH">PINDAH</option>
                  <option value="LULUS">LULUS</option>
                  <option value="NONAKTIF">NONAKTIF</option>
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Siswa tidak boleh dihapus. Mengubah status tetap menjaga seluruh histori transaksi.
                </p>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingStudent(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Perbarui Data
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Correction (Requirement L) */}
      {correctingTx && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-slate-900 text-base">
              Koreksi Transaksi ({correctingTx.id})
            </h3>
            <p className="text-xs text-slate-500">
              Transaksi asli tidak akan dihapus, melainkan ditandai sebagai DIPERBAIKI dan dibuat catatan koreksi baru untuk audit trail.
            </p>

            <form onSubmit={handleSaveCorrection} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nominal Sebelum: Rp {correctingTx.amount.toLocaleString('id-ID')}
                </label>
                <label className="block text-xs text-slate-600 mb-1">Nominal yang Benar (Rp):</label>
                <input
                  type="number"
                  value={corrAmount}
                  onChange={e => setCorrAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Keterangan Baru
                </label>
                <input
                  type="text"
                  value={corrDesc}
                  onChange={e => setCorrDesc(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Alasan Koreksi (Wajib untuk Audit)
                </label>
                <textarea
                  rows={2}
                  value={corrReason}
                  onChange={e => setCorrReason(e.target.value)}
                  placeholder="Contoh: Salah ketik angka nominal oleh petugas"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setCorrectingTx(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Simpan Koreksi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
        onConfirm={confirmModal.action}
        onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
