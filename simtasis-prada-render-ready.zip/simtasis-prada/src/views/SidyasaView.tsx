import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { ConfirmModal } from '../components/ConfirmModal';
import {
  Palmtree,
  ArrowDownRight,
  ArrowUpRight,
  Receipt,
  Search,
  CheckCircle2,
  AlertTriangle,
  History,
  Filter,
} from 'lucide-react';

export const SidyasaView: React.FC = () => {
  const {
    db,
    addTransaction,
    getStudentSidyasaBalance,
    getTotalSidyasaBalance,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'transaksi-siswa' | 'pengeluaran-wisata' | 'daftar-siswa' | 'riwayat'>('transaksi-siswa');

  // Filter & Search
  const [selectedClass, setSelectedClass] = useState<number | 'ALL'>('ALL');
  const [searchStudent, setSearchStudent] = useState('');

  // Transaction form state (Siswa Setoran / Penarikan)
  const [txType, setTxType] = useState<'SETORAN' | 'PENARIKAN'>('SETORAN');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [amount, setAmount] = useState<number | ''>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState<string>('');

  // Pengeluaran Wisata form state
  const [expenseAmount, setExpenseAmount] = useState<number | ''>('');
  const [expenseDesc, setExpenseDesc] = useState<string>('');
  const [expenseDate, setExpenseDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Confirmation Modal
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
    variant?: 'danger' | 'warning' | 'primary';
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const totalSidyasa = getTotalSidyasaBalance();

  // Filtered Students from master DB
  const filteredStudents = useMemo(() => {
    return db.students.filter(s => {
      if (selectedClass !== 'ALL' && s.class !== selectedClass) return false;
      if (searchStudent) {
        const q = searchStudent.toLowerCase();
        return s.name.toLowerCase().includes(q) || s.nis.toLowerCase().includes(q);
      }
      return true;
    });
  }, [db.students, selectedClass, searchStudent]);

  const selectedStudent = useMemo(() => {
    return db.students.find(s => s.id === selectedStudentId);
  }, [db.students, selectedStudentId]);

  const studentBalance = selectedStudent ? getStudentSidyasaBalance(selectedStudent.id) : 0;

  // Submit Siswa Setoran / Penarikan
  const handleSaveStudentTx = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) {
      showToast('Pilih siswa terlebih dahulu', 'error');
      return;
    }

    const num = Number(amount);
    if (!num || num <= 0) {
      showToast('Nominal harus lebih besar dari 0', 'error');
      return;
    }

    if (txType === 'PENARIKAN' && num > studentBalance) {
      showToast(`Saldo simpanan widyawisata siswa tidak mencukupi (Rp ${studentBalance.toLocaleString('id-ID')})`, 'error');
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: txType === 'SETORAN' ? 'Konfirmasi Setoran Widyawisata' : 'Konfirmasi Penarikan Widyawisata',
      message: `Anda akan mencatat ${txType.toLowerCase()} sebesar Rp ${num.toLocaleString('id-ID')} untuk ${selectedStudent.name}. Lanjutkan?`,
      variant: txType === 'PENARIKAN' ? 'warning' : 'primary',
      action: async () => {
        const res = await addTransaction({
          module: 'SIDYASA',
          type: txType,
          student_id: selectedStudent.id,
          class_id: selectedStudent.class,
          amount: num,
          date,
          description: description || (txType === 'SETORAN' ? 'Cicilan simpanan widyawisata' : 'Penarikan simpanan widyawisata'),
        });
        if (res.success) {
          setAmount('');
          setDescription('');
        }
      },
    });
  };

  // Submit Pengeluaran Wisata
  const handleSaveExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const num = Number(expenseAmount);
    if (!num || num <= 0) {
      showToast('Nominal pengeluaran harus lebih besar dari 0', 'error');
      return;
    }

    if (num > totalSidyasa) {
      showToast(`Pengeluaran melebihi total kas SIDYASA yang tersedia (Rp ${totalSidyasa.toLocaleString('id-ID')})`, 'error');
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: 'Konfirmasi Pengeluaran Widyawisata',
      message: `Catat pengeluaran operasional widyawisata sebesar Rp ${num.toLocaleString('id-ID')}? Saldo kas SIDYASA akan berkurang.`,
      variant: 'warning',
      action: async () => {
        const res = await addTransaction({
          module: 'SIDYASA',
          type: 'PENGELUARAN_WIDYAWISATA',
          amount: num,
          date: expenseDate,
          description: expenseDesc || 'Pengeluaran kegiatan widyawisata',
        });
        if (res.success) {
          setExpenseAmount('');
          setExpenseDesc('');
        }
      },
    });
  };

  const sidyasaTxs = db.transactions.filter(t => t.module === 'SIDYASA');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-cyan-100 text-cyan-800">
              <Palmtree className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              SIDYASA — Simpanan Widyawisata
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Pengelolaan tabungan terencana wisata siswa terintegrasi dengan database siswa utama SDN Pruwatan 02.
          </p>
        </div>

        {/* Sub Tabs */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveTab('transaksi-siswa')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'transaksi-siswa' ? 'bg-cyan-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Setoran / Penarikan Siswa
          </button>
          <button
            onClick={() => setActiveTab('pengeluaran-wisata')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'pengeluaran-wisata' ? 'bg-cyan-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Pengeluaran Wisata
          </button>
          <button
            onClick={() => setActiveTab('daftar-siswa')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'daftar-siswa' ? 'bg-cyan-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Daftar Saldo Siswa
          </button>
          <button
            onClick={() => setActiveTab('riwayat')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'riwayat' ? 'bg-cyan-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Riwayat SIDYASA
          </button>
        </div>
      </div>

      {/* Saldo Summary Card */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Total Kas Bersih SIDYASA</span>
          <p className="text-2xl font-black text-cyan-700 mt-1 font-mono">
            Rp {totalSidyasa.toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-400">Total Setoran − Penarikan − Pengeluaran</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Akumulasi Setoran Masuk</span>
          <p className="text-2xl font-black text-emerald-700 mt-1 font-mono">
            Rp{' '}
            {sidyasaTxs
              .filter(t => t.type === 'SETORAN' && t.status === 'VALID')
              .reduce((s, t) => s + t.amount, 0)
              .toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-400">Seluruh cicilan yang diterima</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Pengeluaran Operasional Wisata</span>
          <p className="text-2xl font-black text-rose-600 mt-1 font-mono">
            Rp{' '}
            {sidyasaTxs
              .filter(t => t.type === 'PENGELUARAN_WIDYAWISATA' && t.status === 'VALID')
              .reduce((s, t) => s + t.amount, 0)
              .toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-400">Biaya bus, tiket, akomodasi, dll.</p>
        </div>
      </div>

      {/* Tab 1: Transaksi Siswa */}
      {activeTab === 'transaksi-siswa' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-base">Pencatatan Simpanan Siswa</h3>
              <div className="flex rounded-xl p-1 bg-slate-100 border border-slate-200">
                <button
                  type="button"
                  onClick={() => setTxType('SETORAN')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    txType === 'SETORAN' ? 'bg-cyan-700 text-white shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Setoran
                </button>
                <button
                  type="button"
                  onClick={() => setTxType('PENARIKAN')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    txType === 'PENARIKAN' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600'
                  }`}
                >
                  Penarikan
                </button>
              </div>
            </div>

            <form onSubmit={handleSaveStudentTx} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Pilih Siswa (Database Utama Sekolah)
                </label>
                <select
                  value={selectedStudentId}
                  onChange={e => setSelectedStudentId(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                  required
                >
                  <option value="">-- Pilih Siswa --</option>
                  {db.students.map(s => {
                    const bal = getStudentSidyasaBalance(s.id);
                    return (
                      <option key={s.id} value={s.id}>
                        {s.nis} - {s.name} (Kelas {s.class}, Saldo: Rp {bal.toLocaleString('id-ID')})
                      </option>
                    );
                  })}
                </select>
              </div>

              {selectedStudent && (
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs flex justify-between items-center">
                  <div>
                    <p className="font-bold text-slate-900">{selectedStudent.name}</p>
                    <p className="text-slate-500">NIS: {selectedStudent.nis} • Kelas {selectedStudent.class}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[11px] text-slate-400">Saldo SIDYASA:</p>
                    <p className="font-mono font-bold text-cyan-800 text-sm">
                      Rp {studentBalance.toLocaleString('id-ID')}
                    </p>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nominal (Rp)
                </label>
                <input
                  type="number"
                  min="1000"
                  step="500"
                  value={amount}
                  onChange={e => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Contoh: 50000"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-semibold focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Tanggal
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                    Keterangan
                  </label>
                  <input
                    type="text"
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    placeholder="Contoh: Cicilan ke-2 wisata Yogya"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className={`w-full py-3 rounded-xl text-sm font-bold text-white shadow-xs transition flex items-center justify-center gap-2 ${
                  txType === 'SETORAN' ? 'bg-cyan-700 hover:bg-cyan-800' : 'bg-rose-600 hover:bg-rose-700'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                Simpan {txType === 'SETORAN' ? 'Setoran Widyawisata' : 'Penarikan Siswa'}
              </button>
            </form>
          </div>

          <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-3">
            <h4 className="font-bold text-slate-900 text-sm">Ketentuan Khusus SIDYASA</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              SIDYASA dikhususkan bagi siswa untuk mencicil simpanan kegiatan widyawisata. Seluruh siswa berasal dari database terpusat yang sama sehingga terjamin konsistensi NIS dan identitas siswa.
            </p>
            <div className="p-3 bg-cyan-50 border border-cyan-200 rounded-xl text-xs text-cyan-900 space-y-1">
              <p className="font-bold">Validasi Otomatis:</p>
              <p>• Penarikan siswa tidak boleh melebihi saldo tabungan siswa tersebut.</p>
              <p>• Pengeluaran widyawisata tidak boleh melebihi total kas SIDYASA yang terkumpul.</p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Pengeluaran Wisata */}
      {activeTab === 'pengeluaran-wisata' && (
        <div className="max-w-xl bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-base">Catat Pengeluaran Kegiatan Widyawisata</h3>
            <p className="text-xs text-slate-500">
              Pengeluaran operasional (seperti sewa bus, pembayaran hotel, tiket masuk objek wisata).
            </p>
          </div>

          <form onSubmit={handleSaveExpense} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Nominal Pengeluaran (Rp)
              </label>
              <input
                type="number"
                max={totalSidyasa}
                value={expenseAmount}
                onChange={e => setExpenseAmount(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="Contoh: 1500000"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-semibold focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                required
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Maksimal pengeluaran: Rp {totalSidyasa.toLocaleString('id-ID')}
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Tanggal Pengeluaran
              </label>
              <input
                type="date"
                value={expenseDate}
                onChange={e => setExpenseDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Tujuan / Keterangan Pengeluaran
              </label>
              <textarea
                rows={2}
                value={expenseDesc}
                onChange={e => setExpenseDesc(e.target.value)}
                placeholder="Contoh: Pembayaran DP Bus Pariwisata untuk Widyawisata ke Candi Borobudur"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-cyan-500 focus:outline-none"
                required
              />
            </div>

            <button
              type="submit"
              disabled={totalSidyasa <= 0}
              className="w-full py-3 rounded-xl text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 shadow-xs transition"
            >
              Simpan Pengeluaran Widyawisata
            </button>
          </form>
        </div>
      )}

      {/* Tab 3: Daftar Siswa & Saldo */}
      {activeTab === 'daftar-siswa' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Daftar Saldo Widyawisata Seluruh Siswa</h3>
              <p className="text-xs text-slate-500">Filter berdasarkan kelas dan cari siswa</p>
            </div>

            <div className="flex items-center gap-3">
              <select
                value={selectedClass}
                onChange={e => setSelectedClass(e.target.value === 'ALL' ? 'ALL' : Number(e.target.value))}
                className="text-xs font-semibold px-3 py-1.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-700"
              >
                <option value="ALL">Semua Kelas</option>
                {[1, 2, 3, 4, 5, 6].map(c => (
                  <option key={c} value={c}>
                    Kelas {c}
                  </option>
                ))}
              </select>

              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Cari nama / NIS..."
                  value={searchStudent}
                  onChange={e => setSearchStudent(e.target.value)}
                  className="pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
            </div>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">NIS</th>
                  <th className="px-4 py-3">Nama Siswa</th>
                  <th className="px-4 py-3 text-center">Kelas</th>
                  <th className="px-4 py-3 text-right">Saldo SIDYASA</th>
                  <th className="px-4 py-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStudents.map(s => {
                  const bal = getStudentSidyasaBalance(s.id);
                  return (
                    <tr key={s.id} className="hover:bg-slate-50 transition">
                      <td className="px-4 py-3 font-mono font-bold text-slate-900">{s.nis}</td>
                      <td className="px-4 py-3 font-medium text-slate-800">{s.name}</td>
                      <td className="px-4 py-3 text-center text-slate-600">Kelas {s.class}</td>
                      <td className="px-4 py-3 text-right font-mono font-bold text-cyan-800">
                        Rp {bal.toLocaleString('id-ID')}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700">
                          {s.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: Riwayat Transaksi */}
      {activeTab === 'riwayat' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
          <h3 className="font-bold text-slate-900 text-base">Riwayat Transaksi SIDYASA</h3>
          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">ID Transaksi</th>
                  <th className="px-4 py-3">Tanggal</th>
                  <th className="px-4 py-3">Jenis</th>
                  <th className="px-4 py-3">Siswa / Penerima</th>
                  <th className="px-4 py-3 text-right">Nominal</th>
                  <th className="px-4 py-3">Keterangan</th>
                  <th className="px-4 py-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sidyasaTxs.map(tx => (
                  <tr key={tx.id} className="hover:bg-slate-50 transition">
                    <td className="px-4 py-3 font-mono font-semibold text-slate-900">{tx.id}</td>
                    <td className="px-4 py-3 text-slate-600">{tx.date}</td>
                    <td className="px-4 py-3 font-bold text-slate-800">{tx.type}</td>
                    <td className="px-4 py-3 font-medium text-slate-800">
                      {tx.student_name ? `${tx.student_name} (NIS: ${tx.student_nis})` : 'Operasional Wisata'}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold">
                      <span className={tx.type === 'SETORAN' ? 'text-emerald-700' : 'text-rose-600'}>
                        {tx.type === 'SETORAN' ? '+' : '-'}Rp {tx.amount.toLocaleString('id-ID')}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-500 text-[11px]">{tx.description}</td>
                    <td className="px-4 py-3 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                        {tx.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
        onConfirm={confirmModal.action}
        onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
