import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ConfirmModal } from '../components/ConfirmModal';
import { Loan } from '../types';
import {
  HandCoins,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Calendar,
  Wallet,
  Clock,
  ArrowDownLeft,
} from 'lucide-react';

export const BosView: React.FC = () => {
  const {
    db,
    addLoan,
    repayLoan,
    getTarianBendaharaBalance,
    getTotalSidanumBalance,
    showToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'daftar-pinjaman' | 'tambah-pinjaman'>('daftar-pinjaman');

  // Form Pinjaman Baru
  const [sourceModule, setSourceModule] = useState<'TARIAN' | 'SIDANUM'>('TARIAN');
  const [amount, setAmount] = useState<number | ''>('');
  const [borrowDate, setBorrowDate] = useState(new Date().toISOString().split('T')[0]);
  const [expectedReturnDate, setExpectedReturnDate] = useState('');
  const [borrower, setBorrower] = useState('Bendahara BOS SDN Pruwatan 02');
  const [approver, setApprover] = useState('Kepala Sekolah SDN Pruwatan 02');
  const [purpose, setPurpose] = useState('');

  // Form Pelunasan Modal
  const [repayingLoan, setRepayingLoan] = useState<Loan | null>(null);
  const [repayAmount, setRepayAmount] = useState<number | ''>('');
  const [repayDate, setRepayDate] = useState(new Date().toISOString().split('T')[0]);
  const [repayDesc, setRepayDesc] = useState('Pengembalian talangan dana BOS');

  // Confirmation Modal
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    action: () => void;
    variant?: 'danger' | 'warning' | 'primary';
  }>({
    isOpen: false,
    title: '',
    message: '',
    action: () => {},
  });

  const tarianKas = getTarianBendaharaBalance();
  const sidanumKas = getTotalSidanumBalance();
  const maxAvailable = sourceModule === 'TARIAN' ? tarianKas : sidanumKas;

  // Submit Pinjaman Baru
  const handleSaveNewLoan = (e: React.FormEvent) => {
    e.preventDefault();
    const num = Number(amount);
    if (!num || num <= 0) {
      showToast('Nominal pinjaman harus lebih dari 0', 'error');
      return;
    }

    if (num > maxAvailable) {
      showToast(
        `Nominal pinjaman melebihi kas ${sourceModule} yang tersedia (Rp ${maxAvailable.toLocaleString('id-ID')})`,
        'error'
      );
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: 'Konfirmasi Pinjaman Talangan BOS',
      message: `Catat pinjaman dana talangan BOS sebesar Rp ${num.toLocaleString('id-ID')} dari kas ${sourceModule}? Kas sumber akan langsung berkurang.`,
      variant: 'warning',
      action: async () => {
        const res = await addLoan({
          source_module: sourceModule,
          amount: num,
          borrow_date: borrowDate,
          expected_return_date: expectedReturnDate,
          purpose: purpose || 'Talangan kegiatan operasional BOS',
          borrower,
          approver,
        });
        if (res.success) {
          setAmount('');
          setPurpose('');
          setActiveTab('daftar-pinjaman');
        } else {
          showToast(res.error || 'Gagal mencatat pinjaman', 'error');
        }
      },
    });
  };

  // Submit Pelunasan
  const handleSaveRepayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!repayingLoan) return;
    const num = Number(repayAmount);
    if (!num || num <= 0) {
      showToast('Nominal pelunasan harus lebih dari 0', 'error');
      return;
    }
    if (num > repayingLoan.remaining) {
      showToast(
        `Nominal pelunasan tidak boleh melebihi sisa pinjaman (Rp ${repayingLoan.remaining.toLocaleString('id-ID')})`,
        'error'
      );
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: 'Konfirmasi Pelunasan Pinjaman BOS',
      message: `Catat pengembalian sebesar Rp ${num.toLocaleString('id-ID')} untuk pinjaman ${repayingLoan.id}? Saldo kas ${repayingLoan.source_module} akan otomatis bertambah kembali.`,
      variant: 'primary',
      action: async () => {
        const res = await repayLoan(repayingLoan.id, num, repayDate, repayDesc);
        if (res.success) {
          setRepayingLoan(null);
          setRepayAmount('');
        } else {
          showToast(res.error || 'Gagal memproses pelunasan', 'error');
        }
      },
    });
  };

  const activeLoans = db.loans.filter(l => l.status !== 'LUNAS');
  const totalLoanRemaining = activeLoans.reduce((s, l) => s + l.remaining, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-indigo-100 text-indigo-800">
              <HandCoins className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Manajemen Pinjaman Dana BOS
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencatatan pinjaman sementara dana talangan operasional BOS dari kas resmi TARIAN atau SIDANUM.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('daftar-pinjaman')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'daftar-pinjaman' ? 'bg-indigo-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Daftar Pinjaman ({db.loans.length})
          </button>
          <button
            onClick={() => setActiveTab('tambah-pinjaman')}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
              activeTab === 'tambah-pinjaman' ? 'bg-indigo-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            + Ajukan Pinjaman BOS
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Total Sisa Pinjaman BOS Belum Lunas</span>
          <p className="text-2xl font-black text-amber-600 mt-1 font-mono">
            Rp {totalLoanRemaining.toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-400">{activeLoans.length} pinjaman berstatus aktif / sebagian</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Kas Bendahara TARIAN Tersedia</span>
          <p className="text-2xl font-black text-emerald-700 mt-1 font-mono">
            Rp {tarianKas.toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-400">Dapat dipinjam jika disetujui</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs font-semibold text-slate-500 uppercase">Kas SIDANUM Tersedia</span>
          <p className="text-2xl font-black text-purple-900 mt-1 font-mono">
            Rp {sidanumKas.toLocaleString('id-ID')}
          </p>
          <p className="text-[11px] text-slate-400">Total saldo buku aktif</p>
        </div>
      </div>

      {/* Tab 1: Daftar Pinjaman */}
      {activeTab === 'daftar-pinjaman' && (
        <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-5 space-y-4">
          <h3 className="font-bold text-slate-900 text-base">Daftar Pinjaman BOS dan Status Pelunasan</h3>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">ID Pinjaman</th>
                  <th className="px-4 py-3">Tanggal Pinjam</th>
                  <th className="px-4 py-3">Sumber Dana</th>
                  <th className="px-4 py-3 text-right">Nominal Awal</th>
                  <th className="px-4 py-3 text-right">Sisa Pinjaman</th>
                  <th className="px-4 py-3">Target Kembali</th>
                  <th className="px-4 py-3 text-center">Status</th>
                  <th className="px-4 py-3 text-center">Aksi Pelunasan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {db.loans.map(loan => (
                  <tr key={loan.id} className="hover:bg-slate-50 transition">
                    <td className="px-4 py-3 font-mono font-semibold text-slate-900">{loan.id}</td>
                    <td className="px-4 py-3 text-slate-600">{loan.borrow_date}</td>
                    <td className="px-4 py-3 font-bold text-slate-800">{loan.source_module}</td>
                    <td className="px-4 py-3 text-right font-mono font-medium text-slate-700">
                      Rp {loan.amount.toLocaleString('id-ID')}
                    </td>
                    <td className="px-4 py-3 text-right font-mono font-bold text-amber-700">
                      Rp {loan.remaining.toLocaleString('id-ID')}
                    </td>
                    <td className="px-4 py-3 text-slate-600">{loan.expected_return_date || '-'}</td>
                    <td className="px-4 py-3 text-center">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          loan.status === 'LUNAS'
                            ? 'bg-emerald-100 text-emerald-800'
                            : loan.status === 'SEBAGIAN'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {loan.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {loan.status !== 'LUNAS' && (
                        <button
                          type="button"
                          onClick={() => {
                            setRepayingLoan(loan);
                            setRepayAmount(loan.remaining);
                          }}
                          className="px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold transition inline-flex items-center gap-1"
                        >
                          <ArrowDownLeft className="w-3.5 h-3.5" />
                          Pelunasan / Cicil
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Tambah Pinjaman BOS */}
      {activeTab === 'tambah-pinjaman' && (
        <div className="max-w-2xl bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="pb-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-base">Pencatatan Pinjaman Dana Talangan BOS</h3>
            <p className="text-xs text-slate-500">
              Hanya kas resmi bendahara (TARIAN atau SIDANUM) yang dapat dijadikan sumber pinjaman.
            </p>
          </div>

          <form onSubmit={handleSaveNewLoan} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Sumber Dana Pinjaman
                </label>
                <select
                  value={sourceModule}
                  onChange={e => setSourceModule(e.target.value as 'TARIAN' | 'SIDANUM')}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="TARIAN">Kas Bendahara TARIAN</option>
                  <option value="SIDANUM">Kas SIDANUM</option>
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Kas tersedia: <strong>Rp {maxAvailable.toLocaleString('id-ID')}</strong>
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nominal Pinjaman (Rp)
                </label>
                <input
                  type="number"
                  max={maxAvailable}
                  value={amount}
                  onChange={e => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Contoh: 1500000"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Tanggal Peminjaman
                </label>
                <input
                  type="date"
                  value={borrowDate}
                  onChange={e => setBorrowDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Target Tanggal Pengembalian
                </label>
                <input
                  type="date"
                  value={expectedReturnDate}
                  onChange={e => setExpectedReturnDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nama Peminjam
                </label>
                <input
                  type="text"
                  value={borrower}
                  onChange={e => setBorrower(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Pejabat yang Menyetujui
                </label>
                <input
                  type="text"
                  value={approver}
                  onChange={e => setApprover(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Keperluan Pinjaman Talangan
              </label>
              <textarea
                rows={2}
                value={purpose}
                onChange={e => setPurpose(e.target.value)}
                placeholder="Contoh: Talangan pembelian lembar soal ujian sebelum dana BOS cair"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                required
              />
            </div>

            <button
              type="submit"
              disabled={maxAvailable <= 0}
              className="w-full py-3 rounded-xl text-sm font-bold text-white bg-indigo-700 hover:bg-indigo-800 shadow-xs transition"
            >
              Simpan Pinjaman Talangan BOS
            </button>
          </form>
        </div>
      )}

      {/* Modal Pelunasan */}
      {repayingLoan && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-2xl p-6 shadow-2xl space-y-4">
            <h3 className="font-bold text-slate-900 text-base">
              Pelunasan Pinjaman ({repayingLoan.id})
            </h3>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1">
              <p>Sumber Dana: <strong>{repayingLoan.source_module}</strong></p>
              <p>Total Pinjaman: <strong>Rp {repayingLoan.amount.toLocaleString('id-ID')}</strong></p>
              <p>Sisa Saat Ini: <strong className="text-rose-600">Rp {repayingLoan.remaining.toLocaleString('id-ID')}</strong></p>
            </div>

            <form onSubmit={handleSaveRepayment} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Nominal Pembayaran (Rp)
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    max={repayingLoan.remaining}
                    value={repayAmount}
                    onChange={e => setRepayAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-semibold focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setRepayAmount(repayingLoan.remaining)}
                    className="px-3 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl"
                  >
                    Lunas Semua
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Tanggal Pembayaran
                </label>
                <input
                  type="date"
                  value={repayDate}
                  onChange={e => setRepayDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Keterangan
                </label>
                <input
                  type="text"
                  value={repayDesc}
                  onChange={e => setRepayDesc(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setRepayingLoan(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-700 hover:bg-indigo-800 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Simpan Pelunasan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        variant={confirmModal.variant}
        onConfirm={confirmModal.action}
        onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
