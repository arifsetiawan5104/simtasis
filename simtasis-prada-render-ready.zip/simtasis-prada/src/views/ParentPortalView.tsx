import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  UserCheck,
  Coins,
  Palmtree,
  Wallet,
  ArrowDownRight,
  ArrowUpRight,
  Printer,
  ShieldCheck,
  Calendar,
  Clock,
  Search,
  Filter,
  FileText,
  LogOut,
  Landmark,
} from 'lucide-react';

export const ParentPortalView: React.FC = () => {
  const { session, db, getStudentTarianBalance, getStudentSidyasaBalance, setReceiptTx, logout } = useApp();

  // Find the exact student from DB using the session NIS to ensure up-to-date state
  const currentStudent = useMemo(() => {
    if (!session?.studentData) return null;
    return db.students.find(s => s.nis === session.studentData?.nis || s.id === session.studentData?.id) || session.studentData;
  }, [db.students, session]);

  const [filterModule, setFilterModule] = useState<'ALL' | 'TARIAN' | 'SIDYASA'>('ALL');
  const [filterType, setFilterType] = useState<'ALL' | 'SETORAN' | 'PENARIKAN'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  if (!currentStudent) {
    return (
      <div className="bg-white p-8 rounded-2xl border border-slate-200 text-center space-y-4 max-w-md mx-auto my-12">
        <div className="w-12 h-12 mx-auto rounded-full bg-rose-100 text-rose-600 flex items-center justify-center">
          <UserCheck className="w-6 h-6" />
        </div>
        <h3 className="text-lg font-bold text-slate-900">Data Siswa Tidak Ditemukan</h3>
        <p className="text-xs text-slate-500">
          Sesi Anda tidak memiliki NIS siswa yang valid. Silakan logout dan masukkan kembali NIS siswa yang terdaftar.
        </p>
        <button
          onClick={logout}
          className="px-4 py-2 bg-slate-800 text-white rounded-xl text-xs font-semibold hover:bg-slate-900"
        >
          Kembali ke Halaman Login
        </button>
      </div>
    );
  }

  // Calculate student balances strictly for this child
  const tarianBalance = getStudentTarianBalance(currentStudent.id);
  const sidyasaBalance = getStudentSidyasaBalance(currentStudent.id);
  const totalSavings = tarianBalance + sidyasaBalance;

  // Transactions strictly belonging to this student only (no other student's data)
  const studentTransactions = useMemo(() => {
    return db.transactions
      .filter(t => (t.student_id && t.student_id === currentStudent.id) || (t.student_nis && t.student_nis === currentStudent.nis))
      .filter(t => t.status === 'VALID')
      .sort((a, b) => new Date(b.date + ' ' + (b.time || '00:00')).getTime() - new Date(a.date + ' ' + (a.time || '00:00')).getTime());
  }, [db.transactions, currentStudent]);

  // Filtered transactions for display
  const filteredTxs = useMemo(() => {
    return studentTransactions.filter(t => {
      if (filterModule !== 'ALL' && t.module !== filterModule) return false;
      if (filterType !== 'ALL' && t.type !== filterType) return false;
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          t.description.toLowerCase().includes(q) ||
          t.id.toLowerCase().includes(q) ||
          t.date.includes(q)
        );
      }
      return true;
    });
  }, [studentTransactions, filterModule, filterType, searchQuery]);

  const handlePrintPassbook = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Privacy & Role Notice */}
      <div className="bg-emerald-50 border border-emerald-200/80 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-emerald-900 print:hidden">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-600 text-white rounded-xl shadow-xs">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold">Portal Tabungan Orang Tua / Wali Murid</h4>
            <p className="text-xs text-emerald-700">
              Akses privat & transparan. Anda hanya melihat data dan mutasi rekening putra/putri Anda ({currentStudent.name}).
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 self-end sm:self-center">
          <button
            onClick={handlePrintPassbook}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-emerald-300 text-emerald-800 rounded-xl text-xs font-semibold hover:bg-emerald-100/50 transition shadow-2xs"
          >
            <Printer className="w-4 h-4" />
            Cetak Buku Tabungan
          </button>
          <button
            onClick={logout}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 text-white rounded-xl text-xs font-semibold hover:bg-rose-700 transition shadow-2xs"
          >
            <LogOut className="w-4 h-4" />
            Keluar
          </button>
        </div>
      </div>

      {/* Identity Card: Child's Profile */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 text-white flex items-center justify-center font-black text-2xl shadow-sm">
              {currentStudent.name.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-slate-900 tracking-tight">
                  {currentStudent.name}
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                  {currentStudent.status}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                NIS: <span className="font-mono font-bold text-slate-800">{currentStudent.nis}</span> • Kelas <span className="font-bold text-slate-800">{currentStudent.class}</span> • {db.settings.schoolName || 'SDN Pruwatan 02'}
              </p>
            </div>
          </div>

          <div className="bg-slate-50 px-4 py-2.5 rounded-xl border border-slate-200/80 text-right sm:text-right">
            <p className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Tahun Pelajaran</p>
            <p className="text-xs font-bold text-slate-900 mt-0.5">{db.settings.activePeriod || '2024/2025'}</p>
          </div>
        </div>

        {/* Savings Balance Cards for this child */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-5">
          {/* TARIAN (Harian) */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-50 to-emerald-100/50 border border-emerald-200/70">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
                1. Tabungan Harian (TARIAN)
              </span>
              <Coins className="w-4 h-4 text-emerald-700" />
            </div>
            <p className="text-2xl font-black text-emerald-900 mt-2 font-mono">
              Rp {tarianBalance.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-emerald-700 mt-1">
              Simpanan harian yang disetor di kelas
            </p>
          </div>

          {/* SIDYASA (Widyawisata) */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-cyan-50 to-cyan-100/50 border border-cyan-200/70">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-800">
                2. Tabungan Widyawisata (SIDYASA)
              </span>
              <Palmtree className="w-4 h-4 text-cyan-700" />
            </div>
            <p className="text-2xl font-black text-cyan-900 mt-2 font-mono">
              Rp {sidyasaBalance.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-cyan-700 mt-1">
              Simpanan terencana karya wisata siswa
            </p>
          </div>

          {/* Total Simpanan Siswa */}
          <div className="p-4 rounded-xl bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-slate-700 shadow-xs">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Total Tabungan Anak
              </span>
              <Wallet className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-2xl font-black text-white mt-2 font-mono">
              Rp {totalSavings.toLocaleString('id-ID')}
            </p>
            <p className="text-[11px] text-slate-300 mt-1">
              Akumulasi saldo simpanan aktif anak
            </p>
          </div>
        </div>
      </div>

      {/* Transaction History Section (Child only) */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="font-bold text-slate-900 text-base">
              Riwayat Transaksi Tabungan {currentStudent.name}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Daftar seluruh mutasi setoran dan penarikan yang tercatat di buku tabungan sekolah
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2 print:hidden">
            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Cari transaksi / tanggal..."
                className="pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none w-44"
              />
            </div>

            {/* Filter Module */}
            <select
              value={filterModule}
              onChange={e => setFilterModule(e.target.value as any)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              <option value="ALL">Semua Tabungan</option>
              <option value="TARIAN">Tabungan Harian</option>
              <option value="SIDYASA">Tabungan Widyawisata</option>
            </select>

            {/* Filter Type */}
            <select
              value={filterType}
              onChange={e => setFilterType(e.target.value as any)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            >
              <option value="ALL">Semua Mutasi</option>
              <option value="SETORAN">Hanya Setoran (+)</option>
              <option value="PENARIKAN">Hanya Penarikan (-)</option>
            </select>
          </div>
        </div>

        {/* Transactions Table */}
        <div className="overflow-x-auto">
          {filteredTxs.length === 0 ? (
            <div className="py-12 text-center text-slate-400">
              <FileText className="w-10 h-10 mx-auto text-slate-300 mb-2" />
              <p className="text-sm font-medium text-slate-600">Belum ada riwayat transaksi</p>
              <p className="text-xs text-slate-400 mt-1">
                {studentTransactions.length === 0
                  ? 'Siswa belum memiliki riwayat setoran maupun penarikan tabungan.'
                  : 'Tidak ada transaksi yang cocok dengan filter yang dipilih.'}
              </p>
            </div>
          ) : (
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-600 uppercase font-semibold border-b border-slate-200">
                <tr>
                  <th className="px-4 py-3">No. / ID Bukti</th>
                  <th className="px-4 py-3">Tanggal & Waktu</th>
                  <th className="px-4 py-3">Modul Tabungan</th>
                  <th className="px-4 py-3">Jenis Mutasi</th>
                  <th className="px-4 py-3 text-right">Nominal (Rp)</th>
                  <th className="px-4 py-3">Keterangan</th>
                  <th className="px-4 py-3 text-center print:hidden">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTxs.map((tx, idx) => {
                  const isDeposit = tx.type === 'SETORAN';
                  return (
                    <tr key={tx.id} className="hover:bg-slate-50/80 transition">
                      <td className="px-4 py-3 font-mono text-slate-500 font-semibold">
                        {idx + 1}. <span className="text-slate-800">{tx.id}</span>
                      </td>
                      <td className="px-4 py-3 text-slate-700 whitespace-nowrap">
                        <div className="font-medium">{tx.date}</div>
                        {tx.time && <div className="text-[11px] text-slate-400">{tx.time} WIB</div>}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {tx.module === 'TARIAN' ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold text-[11px]">
                            TARIAN (Harian)
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-cyan-100 text-cyan-800 font-semibold text-[11px]">
                            SIDYASA (Widyawisata)
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        {isDeposit ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-bold">
                            <ArrowDownRight className="w-3.5 h-3.5 text-emerald-600" />
                            Setoran
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-rose-700 font-bold">
                            <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />
                            Penarikan
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right font-mono font-bold whitespace-nowrap">
                        <span className={isDeposit ? 'text-emerald-700' : 'text-rose-600'}>
                          {isDeposit ? '+' : '-'} Rp {tx.amount.toLocaleString('id-ID')}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-slate-600 max-w-xs truncate">
                        {tx.description || '-'}
                        {tx.created_by && (
                          <span className="block text-[10px] text-slate-400">
                            Petugas: {tx.created_by}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-center whitespace-nowrap print:hidden">
                        <button
                          type="button"
                          onClick={() => setReceiptTx(tx)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-emerald-100 hover:text-emerald-800 text-slate-600 font-medium transition inline-flex items-center gap-1 text-xs"
                          title="Lihat & Cetak Bukti Slip Transaksi"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          Slip Bukti
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Print-Only Passbook Header & Signatures */}
      <div className="hidden print:block pt-8 space-y-8 text-xs text-slate-800">
        <div className="border-t border-slate-300 pt-4 flex justify-between">
          <div>
            <p>Dicetak pada: {new Date().toLocaleDateString('id-ID', { dateStyle: 'full' })}</p>
            <p>Status: Sah melalui Sistem SIMTASIS PRADA</p>
          </div>
          <div className="text-right">
            <p className="font-bold">Total Saldo Simpanan Siswa:</p>
            <p className="font-mono text-sm font-bold text-slate-900">Rp {totalSavings.toLocaleString('id-ID')}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-8 pt-6">
          <div className="text-center">
            <p className="font-semibold text-slate-700">Orang Tua / Wali Siswa</p>
            <div className="h-16"></div>
            <p className="font-bold underline text-slate-900">............................................</p>
            <p className="text-[11px] text-slate-500">Wali dari {currentStudent.name}</p>
          </div>

          <div className="text-center">
            <p className="font-semibold text-slate-700">Guru Kelas {currentStudent.class}</p>
            <div className="h-16"></div>
            <p className="font-bold underline text-slate-900">
              {db.accessCodes.find(a => a.role === `guru${currentStudent.class}`)?.label || `Guru Kelas ${currentStudent.class}`}
            </p>
            <p className="text-[11px] text-slate-500">{db.settings.schoolName || 'SDN Pruwatan 02'}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
