import React from 'react';
import { useApp } from '../context/AppContext';
import {
  LayoutDashboard,
  Coins,
  CheckCheck,
  Palmtree,
  CalendarDays,
  BookOpen,
  HandCoins,
  Scale,
  Lock,
  History,
  FileBarChart,
  Settings as SettingsIcon,
  UserCheck,
  GraduationCap,
  X,
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'tarian'
  | 'verifikasi'
  | 'sidyasa'
  | 'sidatan'
  | 'sidanum'
  | 'bos'
  | 'pinjaman-bos'
  | 'rekonsiliasi'
  | 'tutup-buku'
  | 'audit-trail'
  | 'laporan'
  | 'kenaikan'
  | 'pengaturan'
  | 'parent-portal';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  isOpenMobile?: boolean;
  isMobileOpen?: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  isOpenMobile,
  isMobileOpen,
  onCloseMobile,
}) => {
  const { session, db } = useApp();

  if (!session) return null;

  const role = session.role;
  const mobileOpen = isMobileOpen ?? isOpenMobile ?? false;

  // Compute badge counters
  const pendingSetoranCount = db.transactions.filter(
    t => t.module === 'TARIAN' && t.type === 'SETORAN_GURU_KE_BENDAHARA' && t.status === 'PENDING'
  ).length;

  const pendingTeacherSetoran = session.classAccess
    ? db.transactions.filter(
        t =>
          t.class_id === session.classAccess &&
          t.type === 'SETORAN_GURU_KE_BENDAHARA' &&
          t.status === 'PENDING'
      ).length
    : 0;

  interface MenuItem {
    id: NavTab;
    label: string;
    icon: React.ReactNode;
    badge?: number;
    description?: string;
  }

  const getMenuItems = (): MenuItem[] => {
    // Orang Tua Portal
    if (role === 'ortu') {
      return [
        {
          id: 'parent-portal',
          label: 'Tabungan Anak Saya',
          icon: <UserCheck className="w-4 h-4" />,
          description: 'Mutasi & Saldo Siswa',
        },
      ];
    }

    // Guru Kelas 1-6
    if (role.startsWith('guru')) {
      return [
        {
          id: 'dashboard',
          label: 'Dashboard Guru',
          icon: <LayoutDashboard className="w-4 h-4" />,
        },
        {
          id: 'tarian',
          label: 'Tabungan TARIAN',
          icon: <Coins className="w-4 h-4" />,
          badge: pendingTeacherSetoran > 0 ? pendingTeacherSetoran : undefined,
          description: `Kelas ${session.classAccess}`,
        },
        {
          id: 'rekonsiliasi',
          label: 'Rekonsiliasi Fisik',
          icon: <Scale className="w-4 h-4" />,
        },
        {
          id: 'laporan',
          label: 'Rekap & Laporan',
          icon: <FileBarChart className="w-4 h-4" />,
        },
      ];
    }

    // Bendahara TARIAN
    if (role === 'bendhar') {
      return [
        {
          id: 'dashboard',
          label: 'Dashboard TARIAN',
          icon: <LayoutDashboard className="w-4 h-4" />,
        },
        {
          id: 'verifikasi',
          label: 'Verifikasi Setoran Guru',
          icon: <CheckCheck className="w-4 h-4" />,
          badge: pendingSetoranCount > 0 ? pendingSetoranCount : undefined,
        },
        {
          id: 'tarian',
          label: 'Data TARIAN Siswa',
          icon: <Coins className="w-4 h-4" />,
        },
        {
          id: 'bos',
          label: 'Pinjaman BOS',
          icon: <HandCoins className="w-4 h-4" />,
        },
        {
          id: 'rekonsiliasi',
          label: 'Rekonsiliasi Fisik',
          icon: <Scale className="w-4 h-4" />,
        },
        {
          id: 'laporan',
          label: 'Laporan TARIAN',
          icon: <FileBarChart className="w-4 h-4" />,
        },
      ];
    }

    // Bendahara SIDYASA
    if (role === 'bendww') {
      return [
        {
          id: 'dashboard',
          label: 'Dashboard SIDYASA',
          icon: <LayoutDashboard className="w-4 h-4" />,
        },
        {
          id: 'sidyasa',
          label: 'Simpanan Widyawisata',
          icon: <Palmtree className="w-4 h-4" />,
        },
        {
          id: 'laporan',
          label: 'Laporan SIDYASA',
          icon: <FileBarChart className="w-4 h-4" />,
        },
      ];
    }

    // Bendahara SIDATAN
    if (role === 'benddk') {
      return [
        {
          id: 'dashboard',
          label: 'Dashboard SIDATAN',
          icon: <LayoutDashboard className="w-4 h-4" />,
        },
        {
          id: 'sidatan',
          label: 'Simpanan Kegiatan',
          icon: <CalendarDays className="w-4 h-4" />,
        },
        {
          id: 'laporan',
          label: 'Laporan SIDATAN',
          icon: <FileBarChart className="w-4 h-4" />,
        },
      ];
    }

    // Bendahara SIDANUM
    if (role === 'bendum') {
      return [
        {
          id: 'dashboard',
          label: 'Dashboard SIDANUM',
          icon: <LayoutDashboard className="w-4 h-4" />,
        },
        {
          id: 'sidanum',
          label: 'Buku-Buku Dana Umum',
          icon: <BookOpen className="w-4 h-4" />,
        },
        {
          id: 'bos',
          label: 'Pinjaman BOS',
          icon: <HandCoins className="w-4 h-4" />,
        },
        {
          id: 'laporan',
          label: 'Laporan SIDANUM',
          icon: <FileBarChart className="w-4 h-4" />,
        },
      ];
    }

    // Kepala Sekolah (Read Only)
    if (role === 'kepsek') {
      return [
        {
          id: 'dashboard',
          label: 'Dashboard Eksekutif',
          icon: <LayoutDashboard className="w-4 h-4" />,
        },
        {
          id: 'tarian',
          label: 'Rekap TARIAN (Kelas)',
          icon: <Coins className="w-4 h-4" />,
        },
        {
          id: 'sidyasa',
          label: 'Rekap SIDYASA',
          icon: <Palmtree className="w-4 h-4" />,
        },
        {
          id: 'sidatan',
          label: 'Rekap SIDATAN',
          icon: <CalendarDays className="w-4 h-4" />,
        },
        {
          id: 'sidanum',
          label: 'Rekap SIDANUM',
          icon: <BookOpen className="w-4 h-4" />,
        },
        {
          id: 'bos',
          label: 'Status Pinjaman BOS',
          icon: <HandCoins className="w-4 h-4" />,
        },
        {
          id: 'laporan',
          label: 'Laporan & Rekapitulasi',
          icon: <FileBarChart className="w-4 h-4" />,
        },
      ];
    }

    // Administrator (Super Admin)
    return [
      {
        id: 'dashboard',
        label: 'Dashboard Utama',
        icon: <LayoutDashboard className="w-4 h-4" />,
      },
      {
        id: 'tarian',
        label: 'TARIAN (Tabungan Siswa)',
        icon: <Coins className="w-4 h-4" />,
      },
      {
        id: 'verifikasi',
        label: 'Verifikasi Setoran',
        icon: <CheckCheck className="w-4 h-4" />,
        badge: pendingSetoranCount > 0 ? pendingSetoranCount : undefined,
      },
      {
        id: 'sidyasa',
        label: 'SIDYASA (Widyawisata)',
        icon: <Palmtree className="w-4 h-4" />,
      },
      {
        id: 'sidatan',
        label: 'SIDATAN (Kegiatan)',
        icon: <CalendarDays className="w-4 h-4" />,
      },
      {
        id: 'sidanum',
        label: 'SIDANUM (Dana Umum)',
        icon: <BookOpen className="w-4 h-4" />,
      },
      {
        id: 'bos',
        label: 'Pinjaman BOS',
        icon: <HandCoins className="w-4 h-4" />,
      },
      {
        id: 'rekonsiliasi',
        label: 'Rekonsiliasi Kas Fisik',
        icon: <Scale className="w-4 h-4" />,
      },
      {
        id: 'kenaikan',
        label: 'Kenaikan Kelas & Kelulusan',
        icon: <GraduationCap className="w-4 h-4" />,
      },
      {
        id: 'laporan',
        label: 'Laporan Keuangan',
        icon: <FileBarChart className="w-4 h-4" />,
      },
      {
        id: 'pengaturan',
        label: 'Pengaturan & Backup',
        icon: <SettingsIcon className="w-4 h-4" />,
      },
    ];
  };

  const menuItems = getMenuItems();

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-0 left-0 z-40 h-screen w-64 bg-slate-900 text-white flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        } print:hidden`}
      >
        {/* Sidebar Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-500 text-white font-black text-lg flex items-center justify-center shadow-xs">
              SP
            </div>
            <div>
              <h1 className="font-black text-sm tracking-tight leading-none text-white">SIMTASIS PRADA</h1>
              <p className="text-[10px] text-slate-400 mt-0.5">SDN Pruwatan 02</p>
            </div>
          </div>
          <button
            onClick={onCloseMobile}
            className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Info Capsule */}
        <div className="p-4 mx-3 my-2 bg-white/5 rounded-xl border border-white/10">
          <p className="text-xs font-bold text-white truncate">{session.name}</p>
          <div className="flex items-center justify-between mt-1">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-emerald-400">
              {session.role}
            </span>
            {session.classAccess && (
              <span className="text-[10px] bg-white/10 px-1.5 py-0.5 rounded text-slate-300">
                Kelas {session.classAccess}
              </span>
            )}
          </div>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-2 space-y-1 overflow-y-auto">
          {menuItems.map(item => {
            const isActive = currentTab === item.id || (item.id === 'bos' && currentTab === 'pinjaman-bos');
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium transition ${
                  isActive
                    ? 'bg-emerald-600 text-white font-bold shadow-xs'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={isActive ? 'text-white' : 'text-slate-400'}>
                    {item.icon}
                  </span>
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer info */}
        <div className="p-4 border-t border-white/10 text-center">
          <p className="text-[10px] text-slate-400">Arif Setiawan, M.Pd.</p>
          <p className="text-[9px] text-slate-500">SIMTASIS PRADA v2.4</p>
        </div>
      </aside>
    </>
  );
};
