import React from 'react';
import { useApp } from '../context/AppContext';
import { LogOut, RefreshCw, Landmark, Menu } from 'lucide-react';

interface NavbarProps {
  onToggleSidebar?: () => void;
  onToggleMobileSidebar?: () => void;
  currentTab?: string;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar, onToggleMobileSidebar }) => {
  const toggleAction = onToggleMobileSidebar || onToggleSidebar || (() => {});
  const { db, session, logout, syncing, lastSynced } = useApp();

  const getRoleBadge = (role?: string) => {
    if (!role) return null;
    if (role.startsWith('guru')) {
      return <span className="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">Guru Kelas</span>;
    }
    if (role.startsWith('bend')) {
      return <span className="bg-emerald-100 text-emerald-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">Bendahara</span>;
    }
    if (role === 'kepsek') {
      return <span className="bg-purple-100 text-purple-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">Kepala Sekolah</span>;
    }
    if (role === 'admin') {
      return <span className="bg-amber-100 text-amber-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">Administrator</span>;
    }
    if (role === 'ortu') {
      return <span className="bg-indigo-100 text-indigo-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">Orang Tua</span>;
    }
    return <span className="bg-slate-100 text-slate-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">{role}</span>;
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-xs border-b border-slate-200 print:hidden">
      <div className="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Left: Mobile menu toggle + School Branding */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={toggleAction}
            className="md:hidden p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg"
            aria-label="Toggle Navigation"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-sm shrink-0 overflow-hidden">
              {db.settings.logoUrl ? (
                <img
                  src={db.settings.logoUrl}
                  alt="Logo Sekolah"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              ) : (
                <Landmark className="w-5 h-5 text-white" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-900 tracking-tight text-base sm:text-lg">
                  {db.settings.appName}
                </span>
                <span className="hidden sm:inline-block text-[11px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-mono">
                  v2.6
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium truncate max-w-[200px] sm:max-w-xs">
                {db.settings.schoolName}
              </p>
            </div>
          </div>
        </div>

        {/* Right: Sync Status + User Role Info + Logout */}
        <div className="flex items-center gap-2 sm:gap-4">
          {/* Live Multi-device Sync indicator for school staff */}
          {session?.role !== 'ortu' && (
            <div className="hidden lg:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-50 border border-slate-200 text-xs text-slate-600">
              <span className={`w-2 h-2 rounded-full ${syncing ? 'bg-amber-400 animate-ping' : 'bg-emerald-500'}`} />
              <span>{syncing ? 'Menyinkronkan...' : 'Multi-Perangkat Aktif'}</span>
              {lastSynced && (
                <span className="text-slate-400 text-[10px]">
                  ({lastSynced.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' })})
                </span>
              )}
            </div>
          )}

          {/* User Profile Badge */}
          {session && (
            <div className="flex items-center gap-2 pl-2 sm:pl-0">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-semibold text-slate-800 leading-tight">{session.name}</p>
                <div className="mt-0.5">{getRoleBadge(session.role)}</div>
              </div>

              <button
                type="button"
                id="logout-button"
                onClick={logout}
                title="Keluar dari Akun"
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-600 hover:text-rose-600 hover:bg-rose-50 rounded-xl border border-slate-200 hover:border-rose-200 transition"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Keluar</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
