import React from 'react';
import { useApp } from '../context/AppContext';
import { Printer, X, CheckCircle2 } from 'lucide-react';

export const ReceiptModal: React.FC = () => {
  const { receiptTx, setReceiptTx, db } = useApp();

  if (!receiptTx) return null;

  const handlePrint = () => {
    window.print();
  };

  // Find previous balance calculation if student transaction
  let beforeBalance = 0;
  let afterBalance = 0;

  if (receiptTx.student_id && receiptTx.module === 'TARIAN') {
    // calculate up to this tx
    const validTxs = db.transactions
      .filter(t => t.student_id === receiptTx.student_id && t.module === 'TARIAN' && t.status === 'VALID')
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

    let running = 0;
    for (const t of validTxs) {
      if (t.id === receiptTx.id) {
        beforeBalance = running;
        if (t.type === 'SETORAN') running += t.amount;
        if (t.type === 'PENARIKAN') running -= t.amount;
        afterBalance = running;
        break;
      }
      if (t.type === 'SETORAN') running += t.amount;
      if (t.type === 'PENARIKAN') running -= t.amount;
    }
  }

  return (
    <div
      id="receipt-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
      onClick={() => setReceiptTx(null)}
    >
      <div
        id="receipt-modal-content"
        className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        {/* Header (No print if print mode) */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-emerald-50 print:bg-transparent">
          <div className="flex items-center gap-2 text-emerald-800">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <h3 className="font-bold text-base">Bukti Transaksi Tersimpan</h3>
          </div>
          <button
            onClick={() => setReceiptTx(null)}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-white/80 transition print:hidden"
            aria-label="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Receipt Paper */}
        <div id="printable-receipt" className="p-6 bg-white text-slate-800 font-mono text-sm leading-relaxed">
          <div className="text-center pb-4 mb-4 border-b border-dashed border-slate-300">
            <h4 className="font-bold text-lg tracking-wider text-slate-900">SIMTASIS PRADA</h4>
            <p className="text-xs text-slate-600">{db.settings.schoolName}</p>
            <p className="text-[10px] text-slate-400 mt-0.5">BUKTI PENCATATAN TRANSAKSI RESMI</p>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-0.5">
              <span className="text-slate-500">ID Transaksi:</span>
              <span className="font-semibold text-slate-900">{receiptTx.id}</span>
            </div>
            <div className="flex justify-between py-0.5">
              <span className="text-slate-500">Tanggal & Waktu:</span>
              <span>{receiptTx.date} {receiptTx.time}</span>
            </div>
            <div className="flex justify-between py-0.5">
              <span className="text-slate-500">Modul Dana:</span>
              <span className="font-medium text-emerald-700">{receiptTx.module}</span>
            </div>
            <div className="flex justify-between py-0.5">
              <span className="text-slate-500">Jenis Transaksi:</span>
              <span className="font-bold text-slate-900">{receiptTx.type}</span>
            </div>

            {receiptTx.student_name && (
              <>
                <div className="flex justify-between py-0.5">
                  <span className="text-slate-500">Nama Siswa:</span>
                  <span className="font-medium text-slate-900">{receiptTx.student_name}</span>
                </div>
                <div className="flex justify-between py-0.5">
                  <span className="text-slate-500">NIS:</span>
                  <span>{receiptTx.student_nis}</span>
                </div>
              </>
            )}

            {receiptTx.class_id && (
              <div className="flex justify-between py-0.5">
                <span className="text-slate-500">Kelas:</span>
                <span>Kelas {receiptTx.class_id}</span>
              </div>
            )}

            {receiptTx.ledger_name && (
              <div className="flex justify-between py-0.5">
                <span className="text-slate-500">Buku Dana:</span>
                <span className="font-medium">{receiptTx.ledger_name}</span>
              </div>
            )}

            <div className="my-3 border-t border-dashed border-slate-200" />

            <div className="flex justify-between py-1 text-sm bg-slate-50 px-2 rounded">
              <span className="font-semibold text-slate-700">Nominal:</span>
              <span className="font-bold text-emerald-700">
                Rp {receiptTx.amount.toLocaleString('id-ID')}
              </span>
            </div>

            {beforeBalance > 0 || afterBalance > 0 ? (
              <div className="bg-slate-50/70 p-2 rounded space-y-1 text-[11px] text-slate-600">
                <div className="flex justify-between">
                  <span>Saldo Sebelum:</span>
                  <span>Rp {beforeBalance.toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between font-semibold text-slate-800">
                  <span>Saldo Sesudah:</span>
                  <span>Rp {afterBalance.toLocaleString('id-ID')}</span>
                </div>
              </div>
            ) : null}

            <div className="flex justify-between py-0.5 pt-2">
              <span className="text-slate-500">Keterangan:</span>
              <span className="text-right max-w-[200px] truncate">{receiptTx.description}</span>
            </div>
            <div className="flex justify-between py-0.5">
              <span className="text-slate-500">Petugas:</span>
              <span>{receiptTx.created_by}</span>
            </div>
            <div className="flex justify-between py-0.5">
              <span className="text-slate-500">Status:</span>
              <span className="font-bold text-emerald-600">{receiptTx.status}</span>
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-dashed border-slate-300 text-center text-[10px] text-slate-400">
            <p>Terima kasih atas tertib administrasi tabungan.</p>
            <p>Dicetak melalui SIMTASIS PRADA • {db.settings.schoolName}</p>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 bg-slate-50 border-t border-slate-100 print:hidden">
          <button
            id="close-receipt-btn"
            onClick={() => setReceiptTx(null)}
            className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-800 hover:bg-slate-200/60 rounded-xl transition"
          >
            Selesai
          </button>
          <button
            id="print-receipt-btn"
            onClick={handlePrint}
            className="inline-flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-sm transition"
          >
            <Printer className="w-4 h-4" />
            Cetak Bukti
          </button>
        </div>
      </div>
    </div>
  );
};
