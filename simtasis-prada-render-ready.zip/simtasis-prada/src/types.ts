export type Role =
  | 'guru1'
  | 'guru2'
  | 'guru3'
  | 'guru4'
  | 'guru5'
  | 'guru6'
  | 'bendhar'
  | 'bendww'
  | 'benddk'
  | 'bendum'
  | 'kepsek'
  | 'admin'
  | 'ortu';

export type StudentStatus = 'AKTIF' | 'PINDAH' | 'LULUS' | 'NONAKTIF';

export interface Student {
  id: string;
  nis: string;
  name: string;
  class: number; // 1 to 6
  status: StudentStatus;
  created_at: string;
  updated_at: string;
}

export type TransactionModule = 'TARIAN' | 'SIDYASA' | 'SIDATAN' | 'SIDANUM';

export type TransactionType =
  | 'SETORAN'
  | 'PENARIKAN'
  | 'SETORAN_GURU_KE_BENDAHARA'
  | 'PENGELUARAN_WIDYAWISATA'
  | 'SETORAN_KELAS'
  | 'PENGELUARAN_KEGIATAN'
  | 'PEMASUKAN_DANA_UMUM'
  | 'PENGELUARAN_DANA_UMUM'
  | 'PEMASUKAN_BUKU'
  | 'PENGELUARAN_BUKU'
  | 'KOREKSI';

export type TransactionStatus =
  | 'DRAFT'
  | 'PENDING'
  | 'VALID'
  | 'DITOLAK'
  | 'DIPERBAIKI'
  | 'VOID';

export interface Transaction {
  id: string;
  module: TransactionModule;
  type: TransactionType;
  student_id?: string;
  student_nis?: string;
  student_name?: string;
  class_id?: number; // 1 to 6
  ledger_id?: string; // for SIDANUM
  ledger_name?: string;
  amount: number;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm:ss
  description: string;
  status: TransactionStatus;
  created_by: string;
  created_by_role: Role;
  verified_by?: string;
  verified_at?: string;
  rejection_reason?: string;
  correction_reason?: string;
  original_transaction_id?: string;
  created_at: string;
  updated_at: string;
}

export interface LoanRepayment {
  id: string;
  date: string;
  amount: number;
  note: string;
  created_by: string;
  created_at: string;
}

export type LoanStatus = 'AKTIF' | 'SEBAGIAN_DIKEMBALIKAN' | 'SEBAGIAN' | 'LUNAS';

export interface Loan {
  id: string;
  date: string;
  borrow_date?: string;
  expected_return_date?: string;
  source_module: 'TARIAN' | 'SIDANUM';
  borrower: string; // e.g. "Bendahara BOS"
  approver?: string;
  amount: number;
  returned: number;
  remaining: number;
  purpose: string;
  status: LoanStatus;
  created_by: string;
  created_at: string;
  repayments: LoanRepayment[];
}

export interface Ledger {
  id: string;
  name: string;
  source: string;
  description?: string;
  status: 'AKTIF' | 'NONAKTIF';
  created_at: string;
}

export interface Period {
  id: string;
  month: string; // e.g. "2026-09"
  name: string; // e.g. "September 2026"
  opening_balance: {
    tarian: number;
    sidyasa: number;
    sidatan: number;
    sidanum: number;
  };
  total_in: {
    tarian: number;
    sidyasa: number;
    sidatan: number;
    sidanum: number;
  };
  total_out: {
    tarian: number;
    sidyasa: number;
    sidatan: number;
    sidanum: number;
  };
  closing_balance: {
    tarian: number;
    sidyasa: number;
    sidatan: number;
    sidanum: number;
  };
  status: 'OPEN' | 'CLOSED';
  closed_at?: string;
  closed_by?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  activity: string;
  data_before?: any;
  data_after?: any;
  reason?: string;
}

export interface Settings {
  appName: string;
  schoolName: string;
  school_name?: string;
  npsn?: string;
  address?: string;
  kepsekName?: string;
  kepsek_name?: string;
  kepsekNip?: string;
  kepsek_nip?: string;
  activePeriod?: string;
  active_period?: string;
  logoUrl?: string;
  developerName: string;
  developerNip: string;
  developerWa: string;
}

export interface AccessCode {
  role: Role;
  label: string;
  code: string;
  classAccess?: number;
}

export interface Denominations {
  d100000: number;
  d50000: number;
  d20000: number;
  d10000: number;
  d5000: number;
  d2000: number;
  d1000: number;
  c1000: number;
  c500: number;
  c200: number;
  c100: number;
}

export interface Reconciliation {
  id: string;
  date: string;
  time?: string;
  user?: string;
  created_by?: string;
  role?: string;
  context?: string;
  class_id?: number;
  system_balance: number;
  physical_balance: number;
  difference: number;
  status: 'SESUAI' | 'SELISIH' | 'KLOP';
  denominations?: Denominations;
  notes: string;
  created_at: string;
}

export interface AuthSession {
  role: Role;
  name: string;
  classAccess?: number;
  studentData?: Student;
}

export interface DatabaseSchema {
  settings: Settings;
  accessCodes: AccessCode[];
  students: Student[];
  transactions: Transaction[];
  loans: Loan[];
  ledgers: Ledger[];
  periods: Period[];
  auditLogs: AuditLog[];
  reconciliations: Reconciliation[];
}
