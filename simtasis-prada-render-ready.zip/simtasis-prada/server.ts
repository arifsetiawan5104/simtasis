import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { initialDatabase } from './src/initialData';
import { DatabaseSchema, Transaction, AuditLog, Role, Student } from './src/types';

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Persistent DB via Supabase (free tier compatible).
// The whole application state is stored as one JSON document so the existing
// application logic can remain largely unchanged.
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const SUPABASE_TABLE = process.env.SUPABASE_TABLE || 'simtasis_state';
const SUPABASE_ROW_ID = process.env.SUPABASE_ROW_ID || 'main';

// In-memory cache. Persistent writes are serialized to avoid overlapping updates.
let db: DatabaseSchema = JSON.parse(JSON.stringify(initialDatabase));
let saveQueue: Promise<void> = Promise.resolve();

function supabaseHeaders() {
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('SUPABASE_URL dan SUPABASE_SERVICE_ROLE_KEY belum dikonfigurasi');
  }
  return {
    apikey: SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
    'Content-Type': 'application/json',
  };
}

async function loadDatabase(): Promise<DatabaseSchema> {
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    console.warn('[SIMTASIS] Supabase belum dikonfigurasi; menggunakan initial data sementara.');
    return JSON.parse(JSON.stringify(initialDatabase));
  }

  try {
    const url = `${SUPABASE_URL}/rest/v1/${SUPABASE_TABLE}?id=eq.${encodeURIComponent(SUPABASE_ROW_ID)}&select=state`;
    const response = await fetch(url, { headers: supabaseHeaders() });
    if (!response.ok) throw new Error(`Supabase GET ${response.status}: ${await response.text()}`);
    const rows = await response.json() as Array<{ state: DatabaseSchema }>;
    if (rows.length && rows[0]?.state?.students && rows[0]?.state?.transactions && rows[0]?.state?.settings) {
      return rows[0].state;
    }

    // First deployment: seed the database.
    const seed = JSON.parse(JSON.stringify(initialDatabase));
    await persistDatabase(seed);
    return seed;
  } catch (err) {
    console.error('[SIMTASIS] Gagal memuat database Supabase:', err);
    console.warn('[SIMTASIS] Server tetap berjalan menggunakan initial data di memori.');
    return JSON.parse(JSON.stringify(initialDatabase));
  }
}

async function persistDatabase(data: DatabaseSchema): Promise<void> {
  const url = `${SUPABASE_URL}/rest/v1/${SUPABASE_TABLE}`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { ...supabaseHeaders(), Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify({ id: SUPABASE_ROW_ID, state: data, updated_at: new Date().toISOString() }),
  });
  if (!response.ok) throw new Error(`Supabase UPSERT ${response.status}: ${await response.text()}`);
}

function saveDatabase(data: DatabaseSchema) {
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) return;
  // Snapshot at call time, then serialize writes.
  const snapshot = JSON.parse(JSON.stringify(data)) as DatabaseSchema;
  saveQueue = saveQueue
    .then(() => persistDatabase(snapshot))
    .catch(err => console.error('[SIMTASIS] Gagal menyimpan database:', err));
}

// Helper to log audit trail
function addAudit(user: string, role: string, activity: string, reason?: string, dataBefore?: any, dataAfter?: any) {
  const newLog: AuditLog = {
    id: `aud-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toISOString(),
    user,
    role,
    activity,
    reason,
    data_before: dataBefore,
    data_after: dataAfter,
  };
  db.auditLogs.unshift(newLog);
}

// Balance calculation helpers
function calculateStudentBalance(studentId: string, module: 'TARIAN' | 'SIDYASA'): number {
  return db.transactions
    .filter(t => t.student_id === studentId && t.module === module && t.status === 'VALID')
    .reduce((acc, t) => {
      if (t.type === 'SETORAN') return acc + t.amount;
      if (t.type === 'PENARIKAN') return acc - t.amount;
      return acc;
    }, 0);
}

function calculateTeacherCash(classId: number): number {
  // Cash held by teacher = (all valid SETORAN accepted by teacher in this class)
  // - (all valid PENARIKAN paid by teacher in this class)
  // - (all SETORAN_GURU_KE_BENDAHARA that are VALID or PENDING)
  const classTxs = db.transactions.filter(t => t.class_id === classId && t.module === 'TARIAN');
  const validSetoran = classTxs
    .filter(t => t.type === 'SETORAN' && t.status === 'VALID')
    .reduce((s, t) => s + t.amount, 0);
  const validPenarikan = classTxs
    .filter(t => t.type === 'PENARIKAN' && t.status === 'VALID')
    .reduce((s, t) => s + t.amount, 0);
  const handedOrPendingToBendahara = classTxs
    .filter(t => t.type === 'SETORAN_GURU_KE_BENDAHARA' && (t.status === 'VALID' || t.status === 'PENDING'))
    .reduce((s, t) => s + t.amount, 0);

  return Math.max(0, validSetoran - validPenarikan - handedOrPendingToBendahara);
}

// -------------------------------------------------------------
// API ROUTES
// -------------------------------------------------------------

// 1. Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// 2. Fetch entire DB state
app.get('/api/db', (req, res) => {
  res.json(db);
});

// 3. Login verification
app.post('/api/auth/login', (req, res) => {
  const { code } = req.body;
  if (!code || typeof code !== 'string') {
    return res.status(400).json({ error: 'Kode akses atau NIS harus diisi' });
  }

  const trimmed = code.trim();

  // Check role access codes
  const matchedAccess = db.accessCodes.find(a => a.code.toLowerCase() === trimmed.toLowerCase());
  if (matchedAccess) {
    addAudit(matchedAccess.label, matchedAccess.role, 'LOGIN', 'Berhasil login dengan kode akses');
    saveDatabase(db);
    return res.json({
      role: matchedAccess.role,
      name: matchedAccess.label,
      classAccess: matchedAccess.classAccess,
    });
  }

  // Check if it's a student NIS for Orang Tua
  const matchedStudent = db.students.find(s => s.nis === trimmed);
  if (matchedStudent) {
    addAudit(`Orang Tua (${matchedStudent.name})`, 'ortu', 'LOGIN_ORTU', `Login menggunakan NIS ${matchedStudent.nis}`);
    saveDatabase(db);
    return res.json({
      role: 'ortu' as Role,
      name: `Orang Tua: ${matchedStudent.name}`,
      studentData: matchedStudent,
    });
  }

  return res.status(401).json({ error: 'Kode akses atau NIS tidak terdaftar / salah' });
});

// 4. Students
app.post('/api/students', (req, res) => {
  const { nis, name, classNumber, userRole, userName } = req.body;

  if (!nis || !name || !classNumber) {
    return res.status(400).json({ error: 'NIS, Nama Siswa, dan Kelas wajib diisi' });
  }

  const cleanNis = String(nis).trim();
  const cleanName = String(name).trim();
  const cNum = Number(classNumber);

  if (cNum < 1 || cNum > 6) {
    return res.status(400).json({ error: 'Kelas harus antara 1 sampai 6' });
  }

  // Check NIS uniqueness
  const exists = db.students.some(s => s.nis.toLowerCase() === cleanNis.toLowerCase());
  if (exists) {
    return res.status(400).json({ error: `Siswa dengan NIS ${cleanNis} sudah terdaftar. NIS harus unik.` });
  }

  const newStudent: Student = {
    id: `std-${cNum}-${Date.now()}`,
    nis: cleanNis,
    name: cleanName,
    class: cNum,
    status: 'AKTIF',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  db.students.push(newStudent);
  addAudit(userName || 'Guru', userRole || 'guru', 'TAMBAH_SISWA', `Menambahkan siswa baru ${cleanName} (NIS: ${cleanNis}, Kelas: ${cNum})`, null, newStudent);
  saveDatabase(db);

  return res.json({ success: true, student: newStudent });
});

app.put('/api/students/:id', (req, res) => {
  const { id } = req.params;
  const { name, status, userRole, userName } = req.body;

  const idx = db.students.findIndex(s => s.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Siswa tidak ditemukan' });
  }

  const prev = { ...db.students[idx] };
  if (name) db.students[idx].name = String(name).trim();
  if (status && ['AKTIF', 'PINDAH', 'LULUS', 'NONAKTIF'].includes(status)) {
    db.students[idx].status = status;
  }
  db.students[idx].updated_at = new Date().toISOString();

  addAudit(userName || 'Guru', userRole || 'guru', 'EDIT_SISWA', `Mengubah data siswa NIS ${prev.nis} (${prev.name} -> ${db.students[idx].name}, Status: ${db.students[idx].status})`, prev, db.students[idx]);
  saveDatabase(db);

  return res.json({ success: true, student: db.students[idx] });
});

// 5. Transactions
app.post('/api/transactions', (req, res) => {
  const {
    module,
    type,
    student_id,
    class_id,
    ledger_id,
    amount,
    date,
    time,
    description,
    userRole,
    userName,
  } = req.body;

  const parsedAmount = Number(amount);
  if (!parsedAmount || parsedAmount <= 0) {
    return res.status(400).json({ error: 'Nominal transaksi harus lebih besar dari 0' });
  }

  if (!date) {
    return res.status(400).json({ error: 'Tanggal transaksi wajib diisi' });
  }

  // Check closed periods
  const txMonth = date.substring(0, 7);
  const closedPeriod = db.periods.find(p => p.month === txMonth && p.status === 'CLOSED');
  if (closedPeriod && userRole !== 'admin') {
    return res.status(400).json({ error: `Periode bulan ${closedPeriod.name} telah DITUTUP. Hanya Administrator yang dapat membuka kembali periode.` });
  }

  // VALIDATION: ORANG TUA TIDAK BISA INPUT TRANSAKSI
  if (userRole === 'ortu') {
    return res.status(403).json({
      error: 'Akses Ditolak: Orang tua hanya memiliki hak akses melihat data dan riwayat mutasi tabungan anaknya.',
    });
  }

  // VALIDATION: INPUT TRANSAKSI/SETORAN TABUNGAN HARIAN HANYA BISA OLEH GURU KELAS ATAU ADMINISTRATOR
  if (module === 'TARIAN' && (type === 'SETORAN' || type === 'PENARIKAN')) {
    if (userRole !== 'admin') {
      if (!userRole || !userRole.startsWith('guru')) {
        return res.status(403).json({
          error: 'Input transaksi/setoran tabungan harian hanya bisa dilakukan oleh guru kelas atau Administrator.',
        });
      }

      const teacherClassNum = parseInt(userRole.replace('guru', ''), 10);
      if (student_id) {
        const targetStudent = db.students.find(s => s.id === student_id);
        if (targetStudent && targetStudent.class !== teacherClassNum) {
          return res.status(403).json({
            error: `Akses Ditolak: Input transaksi tabungan harian hanya bisa dilakukan oleh Guru Kelas ${targetStudent.class} atau Administrator. Anda terdaftar sebagai Guru Kelas ${teacherClassNum}.`,
          });
        }
      }
    }
  }

  // Validate according to module & type
  let student: Student | undefined;
  let ledgerName: string | undefined;

  if (student_id) {
    student = db.students.find(s => s.id === student_id);
    if (!student) return res.status(404).json({ error: 'Siswa tidak ditemukan' });
  }

  if (ledger_id) {
    const led = db.ledgers.find(l => l.id === ledger_id);
    if (led) ledgerName = led.name;
  }

  // VALIDATION: PENARIKAN SISWA TARIAN
  if (module === 'TARIAN' && type === 'PENARIKAN') {
    if (!student) return res.status(400).json({ error: 'Data siswa wajib disertakan untuk penarikan' });
    const currentBalance = calculateStudentBalance(student.id, 'TARIAN');
    if (parsedAmount > currentBalance) {
      return res.status(400).json({
        error: `Saldo siswa tidak mencukupi. Saldo saat ini: Rp ${currentBalance.toLocaleString('id-ID')}, penarikan: Rp ${parsedAmount.toLocaleString('id-ID')}`,
      });
    }
  }

  // VALIDATION: SETORAN GURU KE BENDAHARA TARIAN
  if (module === 'TARIAN' && type === 'SETORAN_GURU_KE_BENDAHARA') {
    const cId = Number(class_id);
    const teacherCash = calculateTeacherCash(cId);
    if (parsedAmount > teacherCash) {
      return res.status(400).json({
        error: `Nominal setoran (Rp ${parsedAmount.toLocaleString('id-ID')}) melebihi saldo kas yang Anda pegang (Rp ${teacherCash.toLocaleString('id-ID')})`,
      });
    }
  }

  // VALIDATION: SIDYASA PENARIKAN & PENGELUARAN
  if (module === 'SIDYASA' && type === 'PENARIKAN') {
    if (!student) return res.status(400).json({ error: 'Data siswa wajib disertakan' });
    const currentBalance = calculateStudentBalance(student.id, 'SIDYASA');
    if (parsedAmount > currentBalance) {
      return res.status(400).json({
        error: `Saldo simpanan widyawisata siswa tidak mencukupi (Rp ${currentBalance.toLocaleString('id-ID')})`,
      });
    }
  }

  if (module === 'SIDYASA' && type === 'PENGELUARAN_WIDYAWISATA') {
    const totalSidyasa = db.transactions
      .filter(t => t.module === 'SIDYASA' && t.status === 'VALID')
      .reduce((s, t) => (t.type === 'SETORAN' ? s + t.amount : s - t.amount), 0);
    if (parsedAmount > totalSidyasa) {
      return res.status(400).json({
        error: `Pengeluaran widyawisata melebihi total kas SIDYASA (Rp ${totalSidyasa.toLocaleString('id-ID')})`,
      });
    }
  }

  // Prefix generation
  const prefixMap: Record<string, string> = {
    TARIAN: 'TAR',
    SIDYASA: 'SID',
    SIDATAN: 'DKG',
    SIDANUM: 'DUM',
  };
  const prefix = prefixMap[module] || 'TRN';
  const ym = date.replace(/-/g, '').substring(0, 6);
  const count = db.transactions.filter(t => t.module === module).length + 1;
  const txId = `${prefix}-${ym}-${String(count).padStart(4, '0')}`;

  const nowTime = time || new Date().toTimeString().split(' ')[0];

  const initialStatus = type === 'SETORAN_GURU_KE_BENDAHARA' ? 'PENDING' : 'VALID';

  const newTx: Transaction = {
    id: txId,
    module,
    type,
    student_id: student?.id,
    student_nis: student?.nis,
    student_name: student?.name,
    class_id: class_id ? Number(class_id) : student?.class,
    ledger_id,
    ledger_name: ledgerName,
    amount: parsedAmount,
    date,
    time: nowTime,
    description: description || '-',
    status: initialStatus,
    created_by: userName || 'Petugas',
    created_by_role: userRole || 'guru',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  db.transactions.unshift(newTx);
  addAudit(
    userName || 'Petugas',
    userRole || 'petugas',
    'TRANSAKSI_BARU',
    `Mencatat transaksi ${type} ${module} sebesar Rp ${parsedAmount.toLocaleString('id-ID')} (${newTx.id})`,
    null,
    newTx
  );
  saveDatabase(db);

  return res.json({ success: true, transaction: newTx });
});

// 6. Verify teacher setoran (Bendahara TARIAN)
app.post('/api/transactions/:id/verify', (req, res) => {
  const { id } = req.params;
  const { action, rejection_reason, userName, userRole } = req.body; // action: 'ACCEPT' or 'REJECT'

  const tx = db.transactions.find(t => t.id === id);
  if (!tx) return res.status(404).json({ error: 'Transaksi tidak ditemukan' });

  if (tx.type !== 'SETORAN_GURU_KE_BENDAHARA' || tx.status !== 'PENDING') {
    return res.status(400).json({ error: 'Hanya transaksi setoran guru yang berstatus PENDING yang dapat diverifikasi' });
  }

  const prev = { ...tx };
  if (action === 'ACCEPT') {
    tx.status = 'VALID';
    tx.verified_by = userName || 'Bendahara TARIAN';
    tx.verified_at = new Date().toISOString();
    tx.updated_at = new Date().toISOString();
    addAudit(userName || 'Bendahara TARIAN', userRole || 'bendhar', 'VERIFIKASI_SETORAN', `Menerima dan memverifikasi setoran kas Kelas ${tx.class_id} Rp ${tx.amount.toLocaleString('id-ID')} (${tx.id})`, prev, tx);
  } else {
    tx.status = 'DITOLAK';
    tx.rejection_reason = rejection_reason || 'Ditolak oleh Bendahara';
    tx.updated_at = new Date().toISOString();
    addAudit(userName || 'Bendahara TARIAN', userRole || 'bendhar', 'PENOLAKAN_SETORAN', `Menolak setoran kas Kelas ${tx.class_id} Rp ${tx.amount.toLocaleString('id-ID')}. Alasan: ${tx.rejection_reason}`, prev, tx);
  }

  saveDatabase(db);
  return res.json({ success: true, transaction: tx });
});

// 7. Transaction Correction (Original + Correction Record, no hard delete)
app.post('/api/transactions/:id/correct', (req, res) => {
  const { id } = req.params;
  const { newAmount, newDescription, reason, userName, userRole } = req.body;

  const originalTx = db.transactions.find(t => t.id === id);
  if (!originalTx) return res.status(404).json({ error: 'Transaksi tidak ditemukan' });

  if (!reason || reason.trim().length === 0) {
    return res.status(400).json({ error: 'Alasan koreksi wajib diisi untuk keperluan audit' });
  }

  const prev = { ...originalTx };

  // Mark original as VOID or DIPERBAIKI
  originalTx.status = 'DIPERBAIKI';
  originalTx.correction_reason = reason;
  originalTx.updated_at = new Date().toISOString();

  // Create correction record
  const ym = originalTx.date.replace(/-/g, '').substring(0, 6);
  const count = db.transactions.length + 1;
  const corrTxId = `CORR-${ym}-${String(count).padStart(4, '0')}`;

  const correctedTx: Transaction = {
    ...originalTx,
    id: corrTxId,
    amount: Number(newAmount) || originalTx.amount,
    description: `[KOREKSI dari ${originalTx.id}]: ${newDescription || originalTx.description} (Alasan: ${reason})`,
    status: 'VALID',
    created_by: userName || 'Petugas Koreksi',
    created_by_role: userRole || 'admin',
    original_transaction_id: originalTx.id,
    correction_reason: reason,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  db.transactions.unshift(correctedTx);

  addAudit(
    userName || 'Petugas',
    userRole || 'petugas',
    'KOREKSI_TRANSAKSI',
    `Mengoreksi transaksi ${originalTx.id} menjadi ${corrTxId}. Nominal: Rp ${originalTx.amount.toLocaleString('id-ID')} -> Rp ${correctedTx.amount.toLocaleString('id-ID')}. Alasan: ${reason}`,
    prev,
    correctedTx
  );

  saveDatabase(db);
  return res.json({ success: true, original: originalTx, corrected: correctedTx });
});

// 8. Loans to Bendahara BOS
app.post('/api/loans', (req, res) => {
  const { date, borrow_date, expected_return_date, approver, source_module, borrower, amount, purpose, userName, userRole } = req.body;
  const parsedAmount = Number(amount);
  const effectiveDate = borrow_date || date || new Date().toISOString().split('T')[0];

  if (!parsedAmount || parsedAmount <= 0) {
    return res.status(400).json({ error: 'Nominal pinjaman harus lebih dari 0' });
  }

  // Verify source balance
  if (source_module === 'TARIAN') {
    // Total Bendahara TARIAN balance
    const verifiedGuruHandover = db.transactions
      .filter(t => t.module === 'TARIAN' && t.type === 'SETORAN_GURU_KE_BENDAHARA' && t.status === 'VALID')
      .reduce((s, t) => s + t.amount, 0);
    const loansFromTarian = db.loans
      .filter(l => l.source_module === 'TARIAN' && l.status !== 'LUNAS')
      .reduce((s, l) => s + l.remaining, 0);
    const available = verifiedGuruHandover - loansFromTarian;

    if (parsedAmount > available) {
      return res.status(400).json({
        error: `Saldo kas Bendahara TARIAN yang tersedia (Rp ${available.toLocaleString('id-ID')}) tidak mencukupi untuk pinjaman Rp ${parsedAmount.toLocaleString('id-ID')}`,
      });
    }
  } else if (source_module === 'SIDANUM') {
    const totalSidanum = db.transactions
      .filter(t => t.module === 'SIDANUM' && t.status === 'VALID')
      .reduce((s, t) => (t.type === 'PEMASUKAN_BUKU' ? s + t.amount : s - t.amount), 0);
    const loansFromSidanum = db.loans
      .filter(l => l.source_module === 'SIDANUM' && l.status !== 'LUNAS')
      .reduce((s, l) => s + l.remaining, 0);
    const available = totalSidanum - loansFromSidanum;

    if (parsedAmount > available) {
      return res.status(400).json({
        error: `Saldo global SIDANUM yang tersedia (Rp ${available.toLocaleString('id-ID')}) tidak mencukupi untuk pinjaman Rp ${parsedAmount.toLocaleString('id-ID')}`,
      });
    }
  }

  const ym = effectiveDate.replace(/-/g, '').substring(0, 6);
  const count = db.loans.length + 1;
  const loanId = `PINJ-${ym}-${String(count).padStart(4, '0')}`;

  const newLoan = {
    id: loanId,
    date: effectiveDate,
    borrow_date: effectiveDate,
    expected_return_date: expected_return_date || '',
    approver: approver || 'Kepala Sekolah SDN Pruwatan 02',
    source_module,
    borrower: borrower || 'Bendahara BOS',
    amount: parsedAmount,
    returned: 0,
    remaining: parsedAmount,
    purpose: purpose || '-',
    status: 'AKTIF' as const,
    created_by: userName || 'Bendahara',
    created_at: new Date().toISOString(),
    repayments: [],
  };

  db.loans.unshift(newLoan);
  addAudit(
    userName || 'Bendahara',
    userRole || 'bendhar',
    'PINJAMAN_BOS_BARU',
    `Memberikan pinjaman kepada ${newLoan.borrower} sebesar Rp ${parsedAmount.toLocaleString('id-ID')} dari ${source_module}. Tujuan: ${purpose}`,
    null,
    newLoan
  );

  saveDatabase(db);
  return res.json({ success: true, loan: newLoan });
});

// Repay loan
app.post('/api/loans/:id/repay', (req, res) => {
  const { id } = req.params;
  const { amount, date, note, userName, userRole } = req.body;
  const parsedAmount = Number(amount);

  const loan = db.loans.find(l => l.id === id);
  if (!loan) return res.status(404).json({ error: 'Data pinjaman tidak ditemukan' });

  if (loan.status === 'LUNAS') {
    return res.status(400).json({ error: 'Pinjaman ini sudah lunas' });
  }

  if (parsedAmount <= 0) {
    return res.status(400).json({ error: 'Nominal pengembalian harus lebih dari 0' });
  }

  if (parsedAmount > loan.remaining) {
    return res.status(400).json({
      error: `Nominal pengembalian (Rp ${parsedAmount.toLocaleString('id-ID')}) tidak boleh melebihi sisa pinjaman (Rp ${loan.remaining.toLocaleString('id-ID')})`,
    });
  }

  const repayment = {
    id: `REP-${Date.now()}`,
    date: date || new Date().toISOString().split('T')[0],
    amount: parsedAmount,
    note: note || 'Setoran balik pinjaman',
    created_by: userName || 'Bendahara BOS',
    created_at: new Date().toISOString(),
  };

  loan.repayments.push(repayment);
  loan.returned += parsedAmount;
  loan.remaining -= parsedAmount;
  loan.status = loan.remaining === 0 ? 'LUNAS' : 'SEBAGIAN_DIKEMBALIKAN';

  addAudit(
    userName || 'Bendahara BOS',
    userRole || 'bendhar',
    'PENGEMBALIAN_PINJAMAN',
    `Pengembalian pinjaman ${loan.id} sebesar Rp ${parsedAmount.toLocaleString('id-ID')} (Sisa: Rp ${loan.remaining.toLocaleString('id-ID')})`,
    null,
    repayment
  );

  saveDatabase(db);
  return res.json({ success: true, loan });
});

// 9. SIDANUM Ledgers
app.post('/api/ledgers', (req, res) => {
  const { name, source, userName, userRole } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Nama buku wajib diisi' });

  const newLedger = {
    id: `led-${Date.now()}`,
    name: name.trim(),
    source: source ? source.trim() : '-',
    status: 'AKTIF' as const,
    created_at: new Date().toISOString(),
  };

  db.ledgers.push(newLedger);
  addAudit(userName || 'Admin', userRole || 'admin', 'BUAT_BUKU_SIDANUM', `Membuat buku dana SIDANUM baru: ${newLedger.name}`, null, newLedger);
  saveDatabase(db);
  return res.json({ success: true, ledger: newLedger });
});

app.put('/api/ledgers/:id', (req, res) => {
  const { id } = req.params;
  const { name, source, status, userName, userRole } = req.body;
  const led = db.ledgers.find(l => l.id === id);
  if (!led) return res.status(404).json({ error: 'Buku tidak ditemukan' });

  const prev = { ...led };
  if (name) led.name = name.trim();
  if (source) led.source = source.trim();
  if (status && ['AKTIF', 'NONAKTIF'].includes(status)) led.status = status;

  addAudit(userName || 'Admin', userRole || 'admin', 'EDIT_BUKU_SIDANUM', `Memperbarui buku SIDANUM: ${led.name}`, prev, led);
  saveDatabase(db);
  return res.json({ success: true, ledger: led });
});

// 10. Reconciliations
app.post('/api/reconciliations', (req, res) => {
  const { date, physical_balance, system_balance, class_id, notes, userName, userRole } = req.body;

  const phys = Number(physical_balance);
  const sys = Number(system_balance);
  const diff = phys - sys;
  const status = diff === 0 ? 'SESUAI' : 'SELISIH';

  const newRec = {
    id: `rec-${Date.now()}`,
    date: date || new Date().toISOString().split('T')[0],
    user: userName || 'Petugas',
    role: userRole || 'guru',
    class_id: class_id ? Number(class_id) : undefined,
    system_balance: sys,
    physical_balance: phys,
    difference: diff,
    status: status as 'SESUAI' | 'SELISIH',
    notes: notes || '-',
    created_at: new Date().toISOString(),
  };

  db.reconciliations.unshift(newRec);
  addAudit(
    userName || 'Petugas',
    userRole || 'guru',
    'REKONSILIASI_FISIK',
    `Rekonsiliasi saldo fisik: Fisik Rp ${phys.toLocaleString('id-ID')} vs Sistem Rp ${sys.toLocaleString('id-ID')} (${status})`,
    null,
    newRec
  );

  saveDatabase(db);
  return res.json({ success: true, reconciliation: newRec });
});

// 11. Periods / Tutup Buku
app.post('/api/periods/close', (req, res) => {
  const { month, name, userName, userRole } = req.body;
  if (!month) return res.status(400).json({ error: 'Bulan periode wajib diisi' });

  let period = db.periods.find(p => p.month === month);
  if (!period) {
    period = {
      id: `per-${month.replace('-', '')}`,
      month,
      name: name || month,
      opening_balance: { tarian: 0, sidyasa: 0, sidatan: 0, sidanum: 0 },
      total_in: { tarian: 0, sidyasa: 0, sidatan: 0, sidanum: 0 },
      total_out: { tarian: 0, sidyasa: 0, sidatan: 0, sidanum: 0 },
      closing_balance: { tarian: 0, sidyasa: 0, sidatan: 0, sidanum: 0 },
      status: 'OPEN',
    };
    db.periods.push(period);
  }

  // Calculate snapshot of transactions up to this month
  const txs = db.transactions.filter(t => t.date.startsWith(month) && t.status === 'VALID');

  const tarianIn = txs.filter(t => t.module === 'TARIAN' && t.type === 'SETORAN').reduce((s, t) => s + t.amount, 0);
  const tarianOut = txs.filter(t => t.module === 'TARIAN' && t.type === 'PENARIKAN').reduce((s, t) => s + t.amount, 0);

  const sidyasaIn = txs.filter(t => t.module === 'SIDYASA' && t.type === 'SETORAN').reduce((s, t) => s + t.amount, 0);
  const sidyasaOut = txs.filter(t => t.module === 'SIDYASA' && (t.type === 'PENARIKAN' || t.type === 'PENGELUARAN_WIDYAWISATA')).reduce((s, t) => s + t.amount, 0);

  const sidatanIn = txs.filter(t => t.module === 'SIDATAN' && t.type === 'SETORAN_KELAS').reduce((s, t) => s + t.amount, 0);
  const sidatanOut = txs.filter(t => t.module === 'SIDATAN' && t.type === 'PENGELUARAN_KEGIATAN').reduce((s, t) => s + t.amount, 0);

  const sidanumIn = txs.filter(t => t.module === 'SIDANUM' && t.type === 'PEMASUKAN_BUKU').reduce((s, t) => s + t.amount, 0);
  const sidanumOut = txs.filter(t => t.module === 'SIDANUM' && t.type === 'PENGELUARAN_BUKU').reduce((s, t) => s + t.amount, 0);

  period.total_in = { tarian: tarianIn, sidyasa: sidyasaIn, sidatan: sidatanIn, sidanum: sidanumIn };
  period.total_out = { tarian: tarianOut, sidyasa: sidyasaOut, sidatan: sidatanOut, sidanum: sidanumOut };
  period.closing_balance = {
    tarian: period.opening_balance.tarian + tarianIn - tarianOut,
    sidyasa: period.opening_balance.sidyasa + sidyasaIn - sidyasaOut,
    sidatan: period.opening_balance.sidatan + sidatanIn - sidatanOut,
    sidanum: period.opening_balance.sidanum + sidanumIn - sidanumOut,
  };
  period.status = 'CLOSED';
  period.closed_at = new Date().toISOString();
  period.closed_by = userName || 'Petugas';

  addAudit(userName || 'Petugas', userRole || 'admin', 'TUTUP_BUKU', `Menutup buku periode ${period.name} (${period.month})`, null, period);
  saveDatabase(db);
  return res.json({ success: true, period });
});

app.post('/api/periods/open', (req, res) => {
  const { month, reason, userName, userRole } = req.body;
  if (userRole !== 'admin') {
    return res.status(403).json({ error: 'Hanya Administrator yang memiliki wewenang membuka kembali periode yang ditutup.' });
  }

  const period = db.periods.find(p => p.month === month);
  if (!period) return res.status(404).json({ error: 'Periode tidak ditemukan' });

  const prev = { ...period };
  period.status = 'OPEN';
  delete period.closed_at;
  delete period.closed_by;

  addAudit(
    userName || 'Administrator',
    'admin',
    'BUKA_KEMBALI_BUKU',
    `Membuka kembali buku periode ${period.name}. Alasan: ${reason || 'Pembukaan kembali oleh admin'}`,
    prev,
    period
  );

  saveDatabase(db);
  return res.json({ success: true, period });
});

// 12. Settings & Access Codes (Administrator)
app.post('/api/settings', (req, res) => {
  const { settings, accessCodes, userName, userRole } = req.body;
  if (userRole !== 'admin') {
    return res.status(403).json({ error: 'Hanya Administrator yang dapat mengubah pengaturan aplikasi' });
  }

  const prev = { settings: db.settings, accessCodes: db.accessCodes };
  if (settings) {
    db.settings = { ...db.settings, ...settings };
  }
  if (accessCodes && Array.isArray(accessCodes)) {
    db.accessCodes = accessCodes;
  }

  addAudit(userName || 'Administrator', 'admin', 'UBAH_PENGATURAN', 'Mengubah pengaturan identitas aplikasi dan/atau kode akses', prev, { settings: db.settings, accessCodes: db.accessCodes });
  saveDatabase(db);
  return res.json({ success: true, settings: db.settings, accessCodes: db.accessCodes });
});

// Update all access codes (Administrator)
app.post('/api/admin/access-codes', (req, res) => {
  const { accessCodes, userName, userRole } = req.body;
  if (userRole !== 'admin') {
    return res.status(403).json({ error: 'Hanya Administrator yang berwenang mengubah kode akses peran.' });
  }

  if (!accessCodes || !Array.isArray(accessCodes)) {
    return res.status(400).json({ error: 'Data kode akses tidak valid' });
  }

  const prev = [...db.accessCodes];
  db.accessCodes = accessCodes;

  addAudit(
    userName || 'Administrator',
    'admin',
    'UPDATE_KODE_AKSES_PERAN',
    'Administrator memperbarui daftar kode akses seluruh peran',
    prev,
    db.accessCodes
  );

  saveDatabase(db);
  return res.json({ success: true, accessCodes: db.accessCodes });
});

// Reset single role access code / password (Administrator)
app.post('/api/admin/reset-access-code', (req, res) => {
  const { role, newCode, userName, userRole } = req.body;
  if (userRole !== 'admin') {
    return res.status(403).json({ error: 'Hanya Administrator yang berwenang mereset kode akses peran.' });
  }

  if (!role) {
    return res.status(400).json({ error: 'Peran wajib ditentukan' });
  }

  const target = db.accessCodes.find(a => a.role === role);
  if (!target) {
    return res.status(404).json({ error: `Peran ${role} tidak ditemukan` });
  }

  const codeToSet = newCode ? String(newCode).trim() : String(role);
  if (!codeToSet) {
    return res.status(400).json({ error: 'Kode akses baru tidak boleh kosong' });
  }

  const prevCode = target.code;
  target.code = codeToSet;

  addAudit(
    userName || 'Administrator',
    'admin',
    'RESET_KODE_AKSES',
    `Administrator mereset kode akses/password peran ${target.label} (${role})`,
    { role, oldCode: prevCode },
    { role, newCode: codeToSet }
  );

  saveDatabase(db);
  return res.json({ success: true, role, code: codeToSet, accessCodes: db.accessCodes });
});

// 13. Backup & Restore
app.get('/api/admin/backup', (req, res) => {
  const filename = `SIMTASIS_PRADA_BACKUP_${new Date().toISOString().split('T')[0]}.json`;
  res.setHeader('Content-disposition', `attachment; filename=${filename}`);
  res.setHeader('Content-type', 'application/json');
  res.send(JSON.stringify(db, null, 2));
});

app.post('/api/admin/restore', (req, res) => {
  const { backupData, userName, userRole } = req.body;
  if (userRole !== 'admin') {
    return res.status(403).json({ error: 'Hanya Administrator yang dapat melakukan restore data' });
  }

  if (!backupData || !backupData.students || !backupData.transactions || !backupData.settings) {
    return res.status(400).json({ error: 'Format file backup tidak valid. Struktur database tidak lengkap.' });
  }

  const prev = { ...db };
  db = backupData;
  addAudit(userName || 'Administrator', 'admin', 'RESTORE_DATABASE', 'Memulihkan database dari file backup', { studentsCount: prev.students?.length }, { studentsCount: db.students?.length });
  saveDatabase(db);
  return res.json({ success: true, message: 'Database berhasil dipulihkan dari backup' });
});

// 14. Reset Demo Data
app.post('/api/admin/reset-demo', (req, res) => {
  const { userName, userRole } = req.body;
  if (userRole !== 'admin') {
    return res.status(403).json({ error: 'Hanya Administrator yang dapat mereset data' });
  }

  db = JSON.parse(JSON.stringify(initialDatabase));
  addAudit(userName || 'Administrator', 'admin', 'RESET_DEMO_DATA', 'Mereset database kembali ke Data Demo default');
  saveDatabase(db);
  return res.json({ success: true, message: 'Data demo berhasil direset' });
});

// Clean demo students & demo transactions (leave empty for real production use)
app.post('/api/admin/clean-demo', (req, res) => {
  const { userName, userRole } = req.body;
  if (userRole !== 'admin') {
    return res.status(403).json({ error: 'Hanya Administrator yang dapat membersihkan data demo' });
  }

  const prevStudents = db.students.length;
  // Keep non-demo students or wipe demo-tagged ones
  db.students = db.students.filter(s => !s.name.includes('(DEMO)'));
  db.transactions = db.transactions.filter(t => !t.student_name?.includes('(DEMO)'));
  db.loans = [];
  db.reconciliations = [];

  addAudit(userName || 'Administrator', 'admin', 'BERSIHKAN_DATA_DEMO', `Menghapus ${prevStudents - db.students.length} siswa demo dan transaksinya untuk persiapan data riil sekolah.`);
  saveDatabase(db);
  return res.json({ success: true, message: 'Data demo telah dibersihkan. Sistem siap digunakan untuk data riil.' });
});

// 15. Student Promotion & Graduation
app.post('/api/admin/promote', (req, res) => {
  const { newPeriod, retainedStudentIds = [], userName, userRole } = req.body;
  if (userRole !== 'admin') {
    return res.status(403).json({ error: 'Hanya Administrator yang dapat memproses kenaikan kelas' });
  }

  const prev = db.students.map(s => ({ id: s.id, name: s.name, class: s.class, status: s.status }));

  db.students.forEach(s => {
    if (retainedStudentIds.includes(s.id)) {
      return; // Siswa tinggal kelas
    }
    if (s.status === 'AKTIF') {
      if (s.class === 6) {
        s.status = 'LULUS';
      } else {
        s.class = s.class + 1;
      }
      s.updated_at = new Date().toISOString();
    }
  });

  if (newPeriod) {
    db.settings.activePeriod = newPeriod;
    db.settings.active_period = newPeriod;
  }

  addAudit(
    userName || 'Administrator',
    'admin',
    'KENAIKAN_KELAS_KOLEKTIF',
    `Memproses kenaikan kelas kolektif untuk periode baru ${newPeriod || ''}. Siswa kelas 6 dinyatakan lulus.`,
    prev,
    db.students.map(s => ({ id: s.id, name: s.name, class: s.class, status: s.status }))
  );

  saveDatabase(db);
  return res.json({ success: true, message: 'Kenaikan kelas berhasil diproses' });
});

// -------------------------------------------------------------
// Vite Middleware / Static Serve
// -------------------------------------------------------------
async function startServer() {
  db = await loadDatabase();

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[SIMTASIS PRADA] Server aktif di port ${PORT} (0.0.0.0:${PORT})`);
  });
}

startServer();
