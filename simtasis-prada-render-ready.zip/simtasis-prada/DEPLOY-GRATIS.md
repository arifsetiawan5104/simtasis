# Deploy SIMTASIS PRADA gratis

Arsitektur:

APK / Browser -> Render Free (Express + React) -> Supabase Free (PostgreSQL)

## 1. Buat database Supabase

1. Buat project Free di Supabase.
2. Buka SQL Editor.
3. Jalankan isi `supabase.sql`.
4. Buka Project Settings -> API.
5. Salin `Project URL` dan `service_role` key.

**Jangan memasukkan service_role key ke frontend atau APK.** Key tersebut hanya untuk environment variable server Render.

## 2. Deploy ke Render

1. Upload/push folder ini ke GitHub.
2. Di Render pilih New -> Blueprint dan pilih repository tersebut.
3. Render akan membaca `render.yaml`.
4. Isi `SUPABASE_URL` dan `SUPABASE_SERVICE_ROLE_KEY` pada environment variables.
5. Deploy.

Setelah deploy, uji:
`https://NAMA-SERVICE.onrender.com/api/health`

## 3. Data

Aplikasi menyimpan seluruh state SIMTASIS dalam satu baris JSONB di Supabase. Ini mempertahankan struktur aplikasi yang sudah ada tanpa perlu mengubah seluruh API menjadi query SQL individual.

Pada deployment pertama, jika baris `main` belum ada, server akan memasukkan `initialData` sebagai data awal.

## Catatan Free Tier

Render Free dapat tidur setelah sekitar 15 menit tanpa trafik dan perlu waktu sekitar satu menit untuk bangun kembali. Filesystem lokal Render bersifat sementara, sehingga aplikasi ini **tidak lagi menyimpan database ke file lokal**.

Supabase Free menyediakan 500 MB database per project, tetapi project Free dapat dipause setelah periode aktivitas rendah.
