-- SIMTASIS PRADA: persistent application state
-- Run this once in Supabase SQL Editor.

create table if not exists public.simtasis_state (
  id text primary key,
  state jsonb not null,
  updated_at timestamptz not null default now()
);

-- The Express server uses the Supabase service-role key, so browser users
-- never access this table directly. Keep RLS enabled as a safety boundary.
alter table public.simtasis_state enable row level security;

-- No public/anon policies are created intentionally.
